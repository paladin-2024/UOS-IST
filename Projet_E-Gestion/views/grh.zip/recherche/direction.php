<?php
include "./views/include/header.php";
$universite = new Universite();
$etudiantModel = new Etudiant();
$agentModel = new Agent();

$search = isset($_GET['search']) ? $_GET['search'] : '';
$enseignants = $agentModel->getAgentsByType('Enseignant', $search);

$academicYears = $universite->getAcademicYears();
$currentYear = $universite->getCurrentAcademicYear();

// Fonction pour regrouper les sujets par promotion
function groupByPromotion($sujets) {
    $grouped = [];
    foreach ($sujets as $sujet) {
        $promotion = $sujet['promotion'] ?? 'Non définie';
        if (!isset($grouped[$promotion])) {
            $grouped[$promotion] = [];
        }
        $grouped[$promotion][] = $sujet;
    }
    return $grouped;
}
?>

<style>
    .accordion-header {
        position: relative;
        background-color: #fff;
    }
    
    .accordion-header .btn-success {
        position: absolute;
        right: 50px; /* Ajustez selon vos besoins */
        top: 50%;
        transform: translateY(-50%);
    }

    .accordion-button::after {
        margin-right: 60px; /* Pour éviter que la flèche ne chevauche le bouton */
    }

    /* Pour gérer l'espacement sur mobile */
    @media (max-width: 768px) {
        .accordion-header .btn-success {
            right: 40px;
        }
        .accordion-button::after {
            margin-right: 50px;
        }
        .accordion-button .badge.bg-info {
        position: static;
        margin-left: 10px;
    }
    }

    .badge.bg-secondary {
    font-size: 0.9em;
    padding: 0.4em 0.6em;
}

.badge.bg-info {
    font-size: 0.8em;
    white-space: nowrap;
}

.accordion-button {
    padding-right: 4rem; /* Pour laisser de l'espace pour le bouton d'exportation */
}
</style>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>TRAVAUX PAR ENSEIGNANT</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Travaux par Enseignant</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Liste des Travaux par Enseignant</h5>

                        <!-- Formulaire de recherche -->
                        <form method="GET" action="" class="mb-4">
                            <div class="input-group">
                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher un enseignant...">
                                <button type="submit" class="btn btn-primary">Rechercher</button>
                            </div>
                        </form>

                        <!-- Accordéon des enseignants -->
                        <div class="accordion" id="enseignantsAccordion">
                            <?php 
                            $numeroEnseignant = 1;
                            foreach ($enseignants as $index => $enseignant): 
                                // Récupérer les sujets où l'agent est directeur ou encadreur
                                $sujetsDirecteur = $universite->getSujetsByDirecteurOrEncadreur($enseignant['idAgent']);
                                $sujetsByPromotion = groupByPromotion($sujetsDirecteur);

                                // Compter les travaux de l'année en cours
                                $travauxAnneeEnCours = array_reduce($sujetsDirecteur, function($count, $sujet) use ($currentYear) {
                                    return $count + ($sujet['annee'] === $currentYear['designation'] ? 1 : 0);
                                }, 0);
                            ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header d-flex justify-content-between align-items-center" id="heading<?= $index ?>">
                                        <button class="accordion-button collapsed flex-grow-1" type="button" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target="#collapse<?= $index ?>" 
                                                aria-expanded="false" 
                                                aria-controls="collapse<?= $index ?>">
                                            <div class="d-flex align-items-center w-100">
                                                <span class="badge bg-secondary me-2"><?= $numeroEnseignant ?></span>
                                                <div class="d-flex justify-content-between w-100 align-items-center">
                                                    <div>
                                                        <strong><?= htmlspecialchars($enseignant['noms']) ?></strong>
                                                        <?php if (!empty($enseignant['gradeDesignation'])): ?>
                                                            - <?= htmlspecialchars($enseignant['gradeDesignation']) ?>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="ms-3 badge bg-info">
                                                        <?= $travauxAnneeEnCours ?> travail(s) en <?= $currentYear['designation'] ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-success btn-sm me-2" 
                                                style="z-index: 100;"
                                                onclick="exportEnseignantTravaux(event, <?= $enseignant['idAgent'] ?>, '<?= htmlspecialchars($enseignant['noms'], ENT_QUOTES) ?>')">
                                            <i class="bi bi-file-excel"></i> Exporter
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $index ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $index ?>" data-bs-parent="#enseignantsAccordion">
                                        <div class="accordion-body">
                                            <?php if (empty($sujetsByPromotion)): ?>
                                                <p class="text-muted">Aucun travail assigné à cet enseignant.</p>
                                            <?php else: ?>
                                                <?php foreach ($sujetsByPromotion as $promotion => $sujets): ?>
                                                    <div class="promotion-section mb-4">
                                                        <h6 class="promotion-title bg-light p-2 rounded">Promotion: <?= $promotion ?></h6>
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered table-hover">
                                                                <thead class="table-light">
                                                                    <tr>
                                                                        <th>Sujet</th>
                                                                        <th>Étudiant</th>
                                                                        <th>Rôle</th>
                                                                        <th>État</th>
                                                                        <th>Année</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php foreach ($sujets as $sujet): 
                                                                        $role = [];
                                                                        if ($sujet['idDirecteur'] == $enseignant['idAgent']) {
                                                                            $role[] = 'Directeur';
                                                                        }
                                                                        if ($sujet['idEncadreur'] == $enseignant['idAgent']) {
                                                                            $role[] = 'Encadreur';
                                                                        }
                                                                        $roleText = implode(' & ', $role);
                                                                        
                                                                        // Définir la classe pour l'état
                                                                        $etatClass = '';
                                                                        switch($sujet['etatSujet']) {
                                                                            case 'En attente':
                                                                                $etatClass = 'text-warning';
                                                                                break;
                                                                            case 'Validé':
                                                                                $etatClass = 'text-success';
                                                                                break;
                                                                            case 'Rejeté':
                                                                                $etatClass = 'text-danger';
                                                                                break;
                                                                        }

                                                                        // Récupérer les informations de l'étudiant
                                                                        $etudiantInfo = '';
                                                                        if (!empty($sujet['etudiant_idetudiant'])) {
                                                                            $etudiant = $etudiantModel->getEtudiantById($sujet['etudiant_idetudiant']);
                                                                            $etudiantInfo = $etudiant ? htmlspecialchars($etudiant['noms']) : 'Non défini';
                                                                        } else {
                                                                            $etudiantInfo = 'Non assigné';
                                                                        }
                                                                    ?>
                                                                        <tr>
                                                                            <td><?= htmlspecialchars($sujet['intitule']) ?></td>
                                                                            <td><?= $etudiantInfo ?></td>
                                                                            <td><span class="badge bg-primary"><?= $roleText ?></span></td>
                                                                            <td><span class="<?= $etatClass ?>"><?= $sujet['etatSujet'] ?></span></td>
                                                                            <td><?= $sujet['annee'] ?></td>
                                                                        </tr>
                                                                    <?php endforeach; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php 
                            $numeroEnseignant++;
                            endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal pour l'exportation -->
<div class="modal fade" id="exportModal" tabindex="-1" aria-labelledby="exportModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
                <h5 class="modal-title" id="exportModalLabel">Exporter les travaux</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="exportForm" method="POST" action="controller/export_travaux_enseignant.php">
                    <input type="hidden" name="enseignant_id" id="export_enseignant_id">
                    <input type="hidden" name="enseignant_nom" id="export_enseignant_nom">
                    
                    <div class="mb-3">
                        <label for="annee_academique" class="form-label">Année Académique</label>
                        <select class="form-select" id="annee_academique" name="annee_academique" required>
                            <option value="">Sélectionner une année académique</option>
                            <?php foreach ($academicYears as $year): ?>
                                <option value="<?= $year['idannee_acad'] ?>"><?= $year['designation'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                <button type="submit" form="exportForm" class="btn btn-success">
                    <i class="bi bi-file-excel"></i> Exporter
                </button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Ajouter des animations ou des comportements personnalisés si nécessaire
    $('.accordion-button').on('click', function() {
        $(this).toggleClass('active');
    });
});

function exportEnseignantTravaux(event, enseignantId, enseignantNom) {
    // Empêcher la propagation de l'événement
    event.preventDefault();
    event.stopPropagation();
    
    // Remplir les champs cachés
    document.getElementById('export_enseignant_id').value = enseignantId;
    document.getElementById('export_enseignant_nom').value = enseignantNom;
    
    // Afficher le modal
    var modal = new bootstrap.Modal(document.getElementById('exportModal'));
    modal.show();
}
</script>

<?php include "./views/include/footer_file.php"; ?>

