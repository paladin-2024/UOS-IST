<?php
include "./views/include/header.php";
$universite = new Universite();
$etudiantModel = new Etudiant();
$agentModel = new Agent();

$search = isset($_GET['search']) ? $_GET['search'] : '';
$userId = $_SESSION['id'];

// Récupérer l'ID de l'agent enseignant associé à l'utilisateur connecté
$idAgent = $agentModel->getAgentIdByUserId($userId);

if (!$idAgent) {
    echo "<div class='alert alert-danger'>
            <i class='bi bi-exclamation-triangle'></i> 
            Vous n'êtes pas enregistré comme enseignant dans le système.
          </div>";
    echo "<meta http-equiv='refresh' content='3;URL=index'>";
    exit();
}

// Récupérer les sujets où l'agent est directeur ou encadreur
$sujets = $universite->getSujetsByDirecteurOrEncadreur($idAgent, $search);
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Supervision des Travaux</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item active">Travaux à superviser</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Travaux à Superviser</h5>

                        <!-- Formulaire de recherche -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <form action="" method="GET" class="d-flex">
                                    <input type="text" name="search" class="form-control me-2" 
                                           placeholder="Rechercher un sujet ou un étudiant..." 
                                           value="<?= htmlspecialchars($search) ?>">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <?php if (empty($sujets)): ?>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle"></i> Aucun travail à superviser trouvé.
                            </div>
                        <?php else: ?>
                            <!-- Liste des sujets et leurs tâches -->
                            <div class="accordion" id="accordionSujets">
                                <?php 
                                $numeroSujet = 1; // Initialiser le compteur
                                foreach ($sujets as $index => $sujet): 
                                    $role = ($sujet['idDirecteur'] == $idAgent) ? 'Directeur' : 'Encadreur';
                                    $taches = $etudiantModel->getTaches($sujet['idsujets']);
                                ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button <?= $index !== 0 ? 'collapsed' : '' ?>" 
                                                    type="button" 
                                                    data-bs-toggle="collapse" 
                                                    data-bs-target="#collapse<?= $sujet['idsujets'] ?>">
                                                <div class="d-flex justify-content-between align-items-center w-100 me-3">
                                                    <span class="badge bg-secondary me-2"><?= $numeroSujet ?></span>
                                                    <span>
                                                        <strong>Sujet:</strong> <?= htmlspecialchars($sujet['intitule']) ?>
                                                    </span>
                                                    <span class="badge bg-primary ms-2">
                                                        <?= count($taches) ?> tâche(s)
                                                    </span>
                                                </div>
                                            </button>
                                        </h2>

                                        <div id="collapse<?= $sujet['idsujets'] ?>" 
                                             class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>">
                                            <div class="accordion-body">
                                                <!-- Informations du sujet et de l'étudiant -->
                                                <div class="mb-4">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">Informations du sujet</h6>
                                                            <p><strong>Cycle:</strong> <?= $sujet['cycle'] ?></p>
                                                            <p><strong>Spécialisation:</strong> <?= $sujet['specialisation'] ?></p>
                                                            <p><strong>Votre rôle:</strong> 
                                                                <span class="badge bg-<?= strtolower($role) === 'directeur' ? 'primary' : 'success' ?>">
                                                                    <?= $role ?>
                                                                </span>
                                                            </p>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <h6 class="fw-bold">Informations de l'étudiant</h6>
                                                            <?php 
                                                                // Récupérer les informations de l'étudiant
                                                                $etudiantInfo = $etudiantModel->getEtudiantById($sujet['etudiant_idetudiant']);
                                                                if ($etudiantInfo):
                                                            ?>
                                                                <p><strong>Nom:</strong> <?= htmlspecialchars($etudiantInfo['noms']) ?></p>
                                                                <p><strong>Matricule:</strong> <?= htmlspecialchars($etudiantInfo['matricule']) ?></p>
                                                                <p><strong>Email:</strong> <?= htmlspecialchars($etudiantInfo['adressemail']) ?></p>
                                                            <?php else: ?>
                                                                <p class="text-muted">Informations de l'étudiant non disponibles</p>
                                                            <?php endif; ?>
                                                            <p><strong>Année académique:</strong> <?= $sujet['annee'] ?></p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Liste des tâches -->
                                                <?php if (empty($taches)): ?>
                                                    <div class="alert alert-info">
                                                        Aucune tâche soumise pour le moment.
                                                    </div>
                                                <?php else: ?>
                                                    <?php foreach ($taches as $tache): 
                                                        $echanges = $etudiantModel->getEchangesTache($tache['idtaches']);
                                                    ?>
                                                        <div class="card mb-3">
                                                            <div class="card-body">
                                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                                    <h6 class="card-title">
                                                                        <?= htmlspecialchars($tache['description']) ?>
                                                                    </h6>
                                                                    <span class="badge <?= getBadgeClass($tache['validation']) ?>">
                                                                        <?= $tache['validation'] ?>
                                                                    </span>
                                                                </div>
                                                                
                                                                <p class="text-muted small">
                                                                    Soumis le: <?= date('d/m/Y', strtotime($tache['dateTache'])) ?>
                                                                </p>

                                                                <?php if ($tache['fichierTache']): ?>
                                                                    <a href="uploads/<?= $tache['fichierTache'] ?>" 
                                                                       class="btn btn-sm btn-outline-primary mb-2" 
                                                                       target="_blank">
                                                                        <i class="bi bi-download"></i> 
                                                                        Fichier initial
                                                                    </a>
                                                                <?php endif; ?>

                                                                <!-- Historique des échanges -->
                                                                <?php if (!empty($echanges)): ?>
                                                                    <div class="mt-3">
                                                                        <h6>Historique des échanges</h6>
                                                                        <div class="timeline">
                                                                            <?php foreach ($echanges as $echange): ?>
                                                                                <?php 
                                                                                // Vérifie si l'auteur du message est l'utilisateur actuel
                                                                                $isCurrentUser = ($echange['type_auteur'] === $role);
                                                                                $typeClass = getTypeAuteurClass($echange['type_auteur'], $isCurrentUser);
                                                                                $auteurLabel = $isCurrentUser ? 'Vous' : $echange['type_auteur'];
                                                                                ?>
                                                                                <div class="timeline-item">
                                                                                    <div class="timeline-marker bg-<?= getTypeAuteurClass($echange['type_auteur']) ?>"></div>
                                                                                    <div class="timeline-content">
                                                                                        <div class="d-flex justify-content-between">
                                                                                            <strong><?= htmlspecialchars($auteurLabel) ?></strong>
                                                                                            <small class="text-muted">
                                                                                                <?= date('d/m/Y H:i', strtotime($echange['dateEchange'])) ?>
                                                                                            </small>
                                                                                        </div>
                                                                                        <p class="mb-2">
                                                                                            <?= nl2br(htmlspecialchars($echange['commentaire'])) ?>
                                                                                        </p>
                                                                                        <?php if ($echange['fichierJoint']): ?>
                                                                                            <a href="uploads/<?= $echange['fichierJoint'] ?>" 
                                                                                               class="btn btn-sm btn-outline-secondary" 
                                                                                               target="_blank">
                                                                                                <i class="bi bi-file-earmark"></i> 
                                                                                                Voir le fichier joint
                                                                                            </a>
                                                                                        <?php endif; ?>
                                                                                    </div>
                                                                                </div>
                                                                            <?php endforeach; ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>

                                                                <!-- Bouton pour ajouter un commentaire -->
                                                                <button class="btn btn-primary btn-sm mt-3" 
                                                                        onclick="showCommentModal(<?= $tache['idtaches'] ?>, 
                                                                                '<?= $role ?>', 
                                                                                '<?= $tache['validation'] ?>')">
                                                                    <i class="bi bi-chat-dots"></i> 
                                                                    Ajouter un commentaire
                                                                </button>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php 
                                $numeroSujet++; 
                                endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal pour les commentaires -->
    <div class="modal fade" id="commentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ajouter un commentaire</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="controller/comment_tache.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="tache_id" id="tache_id">
                        <input type="hidden" name="role" id="role">
                        
                        <div class="mb-3">
                            <label for="commentaire" class="form-label">Commentaire</label>
                            <textarea class="form-control" id="commentaire" name="commentaire" 
                                      rows="4" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="fichier" class="form-label">Fichier (optionnel)</label>
                            <input type="file" class="form-control" id="fichier" name="fichier">
                        </div>

                        <div class="mb-3">
                            <label for="validation" class="form-label">État de la tâche</label>
                            <select class="form-select" id="validation" name="validation" required>
                                <option value="En cours">En cours</option>
                                <option value="À revoir">À revoir</option>
                                <option value="Validé">Validé</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<style>
.timeline {
    position: relative;
    padding: 20px 0;
    list-style: none;
    max-height: 300px;
    overflow-y: auto;
}

.timeline-item {
    position: relative;
    padding-left: 24px;
    margin-bottom: 20px;
}

.timeline-marker {
    position: absolute;
    left: 0;
    top: 0;
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

.timeline-content {
    background: #f8f9fa;
    padding: 10px;
    border-radius: 4px;
}

.timeline:before {
    content: '';
    position: absolute;
    left: 5px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #dee2e6;
}

.badge.bg-secondary {
    font-size: 0.9em;
    padding: 0.4em 0.6em;
}

/* Ajuster l'espacement */
.accordion-button {
    padding: 1rem;
}

.accordion-button .badge {
    margin-right: 10px;
}
</style>

<script>
function showCommentModal(tacheId, role, currentValidation) {
    document.getElementById('tache_id').value = tacheId;
    document.getElementById('role').value = role;
    
    document.getElementById('commentaire').value = '';
    document.getElementById('fichier').value = '';
    
    if (currentValidation) {
        document.getElementById('validation').value = currentValidation;
    }
    
    new bootstrap.Modal(document.getElementById('commentModal')).show();
}

<?php
function getBadgeClass($etat) {
    return match ($etat) {
        'En attente' => 'bg-warning',
        'Validé' => 'bg-success',
        'À revoir' => 'bg-danger',
        'En cours' => 'bg-info',
        default => 'bg-secondary',
    };
}

function getTypeAuteurClass($type, $isCurrentUser = false) {
    if ($isCurrentUser) {
        return 'warning'; // Utilisation de la classe 'warning' pour mettre en évidence "Vous"
    }
    
    return match ($type) {
        'Directeur' => 'primary',
        'Encadreur' => 'success',
        'Etudiant' => 'info',
        default => 'secondary',
    };
}

// Fonction helper pour obtenir le libellé de l'auteur
function getTypeAuteurLabel($type, $isCurrentUser = false) {
    if ($isCurrentUser) {
        return 'Vous';
    }
    
    return $type;
}
?>
</script>

<?php include "./views/include/footer_file.php"; ?>

