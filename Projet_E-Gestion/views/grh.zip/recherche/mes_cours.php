<?php
include "./views/include/header.php";
$universite = new Universite();
$ecue = new Ecue();
$agent = new Agent();
$enseignant = new Enseignant();

// Vérifier que l'utilisateur est connecté
$userId = $_SESSION['id'] ?? 0;

// Vérifier si l'utilisateur est un enseignant
if (!$userId || !$enseignant->isUserEnseignant($userId)) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Accès refusé',
            text: 'Vous devez être connecté en tant qu\'enseignant pour accéder à cette page.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

// Récupérer l'ID de l'agent (enseignant)
$idEnseignant = $enseignant->getAgentIdByUserId($userId);
if (!$idEnseignant) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'Impossible de récupérer les informations de l\'enseignant.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

$enseignants = $enseignant->getEnseignantByUserId($userId);
// Récupérer l'ID de l'enseignant connecté
$idEnseignant = $enseignants['idAgent'];

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Récupérer les ECUE affectés à cet enseignant pour l'année en cours
$coursEnseignant = $enseignant->getCoursAffectesEnseignant($idEnseignant, $currentYear['idannee_acad']);
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>MES COURS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?view=dashboard">Accueil</a></li>
                <li class="breadcrumb-item active">Mes Cours</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Année académique: <?= htmlspecialchars($currentYear['designation']) ?></h5>
                        <p>Vous trouverez ci-dessous la liste des cours qui vous sont affectés pour l'année académique en cours.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table des ECUE -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">Mes cours affectés</h5>

                                <?php if (empty($coursEnseignant)): ?>
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-1"></i>
                                        Aucun cours ne vous a été affecté pour cette année académique.
                                    </div>
                                <?php else: ?>
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Désignation</th>
                                                <th scope="col">Unité d'enseignement</th>
                                                <th scope="col">Semestre</th>
                                                <th scope="col">Promotion</th>
                                                <th scope="col">Volume horaire</th>
                                                <th scope="col">Rôle</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($coursEnseignant as $cours) {
                                                echo "
                                                <tr>
                                                    <td>{$i}</td>
                                                    <td>{$cours['designationECUE']}</td>
                                                    <td>{$cours['designationUE']}</td>
                                                    <td>{$cours['numeroSemestre']}</td>
                                                    <td>{$cours['designationPromotion']}</td>
                                                    <td>
                                                        CMI: {$cours['CMI']}h<br>
                                                        TD: {$cours['TD']}h<br>
                                                        TP: {$cours['TP']}h
                                                    </td>
                                                    <td><span class='badge bg-primary'>{$cours['poste']}</span></td>
                                                    <td>
                                                        <button class='btn btn-sm btn-primary' onclick='window.location.href=\"?view=enseignement/cours.details&id={$cours['idECUE']}\"'>
                                                            <i class='bi bi-book'></i> Contenu
                                                        </button>
                                                        <button class='btn btn-sm btn-info' onclick='window.location.href=\"?view=enseignement/evaluations&ecue={$cours['idECUE']}\"'>
                                                            <i class='bi bi-clipboard-check'></i> Évaluations
                                                        </button>
                                                    </td>
                                                </tr>";
                                                $i++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
// Script pour gérer la navigation
document.addEventListener('DOMContentLoaded', function() {
    console.log('Page des cours chargée');
});
</script>

<?php include "./views/include/footer.php"; ?>
