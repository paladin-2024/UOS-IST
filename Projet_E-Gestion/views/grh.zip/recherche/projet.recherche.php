<?php
include "./views/include/header.php";
$enseignantModel = new Enseignant();
$universite = new Universite();

// Récupérer l'ID utilisateur de la session
$userId = $_SESSION['id'] ?? 0;

// Vérifier si l'utilisateur est un enseignant
if (!$userId || !$enseignantModel->isUserEnseignant($userId)) {
    echo "<meta http-equiv='refresh' content='0;URL=index'>";
    exit();
}

// Récupérer l'ID de l'agent (enseignant)
$idEnseignant = $enseignantModel->getAgentIdByUserId($userId);
if (!$idEnseignant) {
    echo "<meta http-equiv='refresh' content='0;URL=index'>";
    exit();
}

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Récupérer les informations de l'enseignant
$enseignant = $enseignantModel->getEnseignantByUserId($userId);
if (!$enseignant) {
    echo "<meta http-equiv='refresh' content='0;URL=index'>";
    exit();
}

$idEnseignant = $enseignant['idAgent'];

// Récupérer les spécialisations pour le formulaire de modification
$specialisations = $universite->getAllSpecialisations();

// Récupérer l'année académique en cours
$anneeEnCours = $universite->getCurrentAcademicYear();
$anneeId = $anneeEnCours['idannee_acad'];

// Récupérer les statistiques pour l'année en cours
$stats = $enseignantModel->getStatistiquesSujetsParAnnee($idEnseignant, $anneeId);

// Récupérer les sujets validés par la commission où l'enseignant est directeur ou encadreur
$sujets = $enseignantModel->getSujetsSupervisesParEnseignant($idEnseignant, $search);

// Récupérer la liste des enseignants pour le choix d'encadreur
$enseignants = $enseignantModel->getAllEnseignants();

// Récupérer les soutenances programmées
$soutenances = $enseignantModel->getSoutenancesBySujets($idEnseignant);

// Fonction pour obtenir la classe de badge pour le statut de soutenance
function getSoutenanceStatusClass($statut) {
    switch ($statut) {
        case 'Programmée':
            return 'bg-info';
        case 'Terminée':
            return 'bg-success';
        case 'Reportée':
            return 'bg-warning';
        case 'Annulée':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>SUPERVISION DES TRAVAUX DE RECHERCHE</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index">Accueil</a></li>
                <li class="breadcrumb-item active">Travaux à Superviser</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <!-- Statistiques -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statistiques pour l'année académique <?= $anneeEnCours['designation'] ?></h5>
                        
                        <div class="row">
                            <!-- Statistique Directeur -->
                            <div class="col-md-3">
                                <div class="card info-card sales-card">
                                    <div class="card-body">
                                        <h5 class="card-title">Directeur</h5>
                                        <div class="d-flex align-items-center">
                                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-person-check-fill"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6><?= $stats['directeur'] ?? 0 ?></h6>
                                                <span class="text-success small pt-1 fw-bold">
                                                    <?= ($stats['total'] > 0) ? round(($stats['directeur']/$stats['total'])*100, 1) : 0 ?>%
                                                </span> 
                                                <span class="text-muted small pt-2 ps-1">des projets</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Statistique Encadreur -->
                            <div class="col-md-3">
                                <div class="card info-card revenue-card">
                                    <div class="card-body">
                                        <h5 class="card-title">Encadreur</h5>
                                        <div class="d-flex align-items-center">
                                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-person-lines-fill"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6><?= $stats['encadreur'] ?? 0 ?></h6>
                                                <span class="text-success small pt-1 fw-bold">
                                                    <?= ($stats['total'] > 0) ? round(($stats['encadreur']/$stats['total'])*100, 1) : 0 ?>%
                                                </span> 
                                                <span class="text-muted small pt-2 ps-1">des projets</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Statistique Validés -->
                            <div class="col-md-3">
                                <div class="card info-card customers-card">
                                    <div class="card-body">
                                        <h5 class="card-title">Validés</h5>
                                        <div class="d-flex align-items-center">
                                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-check-circle"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6><?= $stats['valide'] ?? 0 ?></h6>
                                                <span class="text-success small pt-1 fw-bold">
                                                    <?= ($stats['total'] > 0) ? round(($stats['valide']/$stats['total'])*100, 1) : 0 ?>%
                                                </span> 
                                                <span class="text-muted small pt-2 ps-1">des projets</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Statistique Total -->
                            <div class="col-md-3">
                                <div class="card info-card customers-card">
                                    <div class="card-body">
                                        <h5 class="card-title">Total</h5>
                                        <div class="d-flex align-items-center">
                                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                <i class="bi bi-file-earmark-text"></i>
                                            </div>
                                            <div class="ps-3">
                                                <h6><?= $stats['total'] ?? 0 ?></h6>
                                                <span class="text-muted small pt-2 ps-1">projets supervisés</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Liste des sujets -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card overflow-auto">
                    <div class="card-body">
                        <h5 class="card-title">Travaux de Recherche à Superviser</h5>

                        <form method="GET" action="" class="mb-3">
                            <div class="input-group">
                                <input type="hidden" name="view" value="recherche/projet.recherche">
                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher un sujet ou un étudiant...">
                                <button type="submit" class="btn btn-primary">Rechercher</button>
                            </div>
                        </form>

                        <table class="table table-striped table-bordered datatable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Intitulé</th>
                                    <th>Cycle</th>
                                    <th>Spécialisation</th>
                                    <th>État</th>
                                    <th>Étudiant</th>
                                    <th>Rôle</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $i = 1;
                                foreach ($sujets as $sujet) {
                                    $role = ($sujet['idDirecteur'] == $idEnseignant) ? 'Directeur' : 'Encadreur';
                                    $canValidate = ($role == 'Directeur');
                                    $intituleJS = addslashes($sujet['intitule']);
                                    
                                    echo "<tr>
                                        <td>{$i}</td>
                                        <td>{$sujet['intitule']}</td>
                                        <td>{$sujet['cycle']}</td>
                                        <td>{$sujet['specialisation']}</td>
                                        <td><span class='badge " . getBadgeClass($sujet['etatSujet']) . "'>{$sujet['etatSujet']}</span></td>
                                        <td>{$sujet['etudiant']}</td>
                                        <td><span class='badge " . ($role == 'Directeur' ? 'bg-primary' : 'bg-success') . "'>{$role}</span></td>
                                        <td>";
                                    
                                    // Actions disponibles selon le rôle et l'état du sujet
                                    if ($canValidate) {
                                        // Préparer les données du sujet pour JavaScript
                                        $sujetData = htmlspecialchars(json_encode([
                                            'idsujets' => $sujet['idsujets'],
                                            'intitule' => $sujet['intitule'],
                                            'idSpecialisation' => $sujet['idSpecialisation'],
                                            'idEncadreur' => $sujet['idEncadreur'],
                                        ]), ENT_QUOTES);
                                        
                                        echo "<button class='btn btn-sm btn-primary mb-1' onclick='editSujet($sujetData)'>
                                                <i class='bi bi-pencil'></i> Modifier
                                            </button><br>";
                                        
                                        // Boutons de validation/rejet si l'état est "En attente"
                                        if ($sujet['etatSujet'] == 'En attente') {
                                            echo "<button class='btn btn-sm btn-success mb-1' onclick='validateSujet({$sujet['idsujets']})'>
                                                    <i class='bi bi-check-circle'></i> Valider
                                                </button><br>
                                                <button class='btn btn-sm btn-danger' onclick='rejectSujet({$sujet['idsujets']})'>
                                                    <i class='bi bi-x-circle'></i> Rejeter
                                                </button>";
                                        }
                                    }
                                    
                                    echo "</td></tr>";
                                    $i++;
                                }

                                function getBadgeClass($etat) {
                                    switch ($etat) {
                                        case 'En attente':
                                            return 'bg-warning';
                                        case 'Validé':
                                            return 'bg-success';
                                        case 'Rejeté':
                                            return 'bg-danger';
                                        default:
                                            return 'bg-secondary';
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Soutenances programmées -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Soutenances Programmées</h5>
                        
                        <?php if (empty($soutenances)): ?>
                            <div class="alert alert-info">
                                <i class="bi bi-info-circle me-1"></i>
                                Aucune soutenance programmée pour le moment.
                            </div>
                        <?php else: ?>
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Lieu</th>
                                        <th>Sujet</th>
                                        <th>Étudiant</th>
                                        <th>Statut</th>
                                        <th>Rôle</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $i = 1;
                                    foreach ($soutenances as $soutenance): 
                                    ?>
                                        <tr>
                                            <td><?= $i ?></td>
                                            <td><?= date('d/m/Y H:i', strtotime($soutenance['date_soutenance'])) ?></td>
                                            <td><?= $soutenance['lieu'] ?></td>
                                            <td><?= $soutenance['intitule'] ?></td>
                                            <td><?= $soutenance['etudiant'] ?></td>
                                            <td>
                                                <span class="badge <?= getSoutenanceStatusClass($soutenance['statut']) ?>">
                                                    <?= $soutenance['statut'] ?>
                                                </span>
                                            </td>
                                            <td><?= $soutenance['role'] ?></td>
                                        </tr>
                                    <?php 
                                    $i++;
                                    endforeach; 
                                    ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal de modification du sujet -->
<div class="modal fade" id="editSujetModal" tabindex="-1" role="dialog" aria-labelledby="editSujetModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier le Sujet</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editSujetForm" method="POST" action="controller/sujet_controller.php">
                    <input type="hidden" name="action" value="update2">
                    <input type="hidden" name="idsujets" id="edit_idsujets">
                    
                    <div class="mb-3">
                        <label for="edit_intitule" class="form-label">Intitulé du sujet</label>
                        <textarea class="form-control" 
                                id="edit_intitule" 
                                name="intitule" 
                                rows="3" 
                                required
                                style="resize: vertical;"
                                placeholder="Saisissez l'intitulé du sujet..."></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="edit_specialisation" class="form-label">Spécialisation</label>
                        <select class="form-select" id="edit_specialisation" name="idSpecialisation" required>
                            <?php foreach ($specialisations as $specialisation): ?>
                                <option value="<?= $specialisation['idSpecialisation'] ?>">
                                    <?= htmlspecialchars($specialisation['designation']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="edit_encadreur" class="form-label">Encadreur</label>
                        <select class="form-select" id="edit_encadreur" name="encadreur">
                            <option value="">Sélectionner un encadreur</option>
                            <?php foreach ($enseignants as $enseignant): ?>
                                <?php if ($enseignant['idAgent'] != $idEnseignant): // Ne pas s'afficher soi-même ?>
                                <option value="<?= $enseignant['idAgent'] ?>">
                                    <?= htmlspecialchars($enseignant['noms']) ?> (<?= htmlspecialchars($enseignant['grade']) ?>)
                                </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Fonction pour valider un sujet
function validateSujet(idSujet) {
    Swal.fire({
        title: 'Valider le sujet',
        text: "Êtes-vous sûr de vouloir valider ce sujet ? Cette action indique que le travail est terminé et approuvé.",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, valider',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'controller/validate_sujet.php?idsujets=' + idSujet + '&action=validate';
        }
    });
}

// Fonction pour rejeter un sujet
function rejectSujet(idSujet) {
    Swal.fire({
        title: 'Rejeter le sujet',
        text: "Êtes-vous sûr de vouloir rejeter ce sujet ? Cette action indique que le travail n'est pas approuvé.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, rejeter',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'controller/validate_sujet.php?idsujets=' + idSujet + '&action=reject';
        }
    });
}

// Fonction pour éditer un sujet
function editSujet(sujet) {
    // Remplir le formulaire avec les données du sujet
    document.getElementById('edit_idsujets').value = sujet.idsujets;
    document.getElementById('edit_intitule').value = sujet.intitule;
    document.getElementById('edit_specialisation').value = sujet.idSpecialisation;
    
    // Sélectionner l'encadreur si présent
    const encadreurSelect = document.getElementById('edit_encadreur');
    if (sujet.idEncadreur) {
        // Vérifier si l'option existe
        const options = Array.from(encadreurSelect.options);
        const option = options.find(opt => opt.value == sujet.idEncadreur);
        if (option) {
            encadreurSelect.value = sujet.idEncadreur;
        }
    } else {
        encadreurSelect.value = '';
    }

    // Afficher le modal
    var editModal = new bootstrap.Modal(document.getElementById('editSujetModal'));
    editModal.show();
}

// Validation du formulaire
document.getElementById('editSujetForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    Swal.fire({
        title: 'Confirmer la modification',
        text: "Voulez-vous enregistrer ces modifications ?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, modifier',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            this.submit();
        }
    });
});


</script>

<?php include "./views/include/footer_file.php"; ?>

