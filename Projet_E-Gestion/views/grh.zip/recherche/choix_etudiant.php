<?php
include "./views/include/header.php";
$universite = new Universite();
$enseignantModel = new Enseignant();

// Vérification des responsabilités de l'utilisateur connecté
$userSections = [];
$isResponsableSection = false;
$currentUserId = $_SESSION['id']; // Supposons que l'ID de l'utilisateur est stocké dans la session

// Récupérer les sections dont l'utilisateur est responsable pour l'année académique en cours
$currentYear = $universite->getCurrentAcademicYear();
$query = "SELECT section_idsection 
          FROM responsable_section 
          WHERE idUser = :userId 
          AND annee_acad_idannee_acad = :anneeId";

$stmt = Connexion::getInstance()->getPDO()->prepare($query);
$stmt->bindParam(':userId', $currentUserId);
$stmt->bindParam(':anneeId', $currentYear['idannee_acad']);
$stmt->execute();
$userSections = $stmt->fetchAll(PDO::FETCH_COLUMN);

$isResponsableSection = !empty($userSections);

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Récupérer tous les paramètres de filtrage
$status = isset($_GET['status']) ? $_GET['status'] : '';
$cycle = isset($_GET['cycle']) ? $_GET['cycle'] : '';
$specialisation = isset($_GET['specialisation']) ? $_GET['specialisation'] : '';
$anneeId = isset($_GET['annee']) ? intval($_GET['annee']) : 0;
$hasStudent = isset($_GET['has_student']) ? $_GET['has_student'] : null;
$sectionFilter = isset($_GET['section']) ? intval($_GET['section']) : 0;

// Créer un tableau de filtres
$filters = [
    'status' => $status,
    'cycle' => $cycle,
    'specialisation' => $specialisation,
    'annee' => $anneeId,
    'has_student' => $hasStudent
];


// Si l'utilisateur est responsable de section, filtrer les sujets par ses sections
if ($isResponsableSection) {
    // Si une section spécifique est sélectionnée et que l'utilisateur y a accès
    if ($sectionFilter > 0 && in_array($sectionFilter, $userSections)) {
        $sujets = $enseignantModel->getSujetsForCommissionValidationBySections($search, [$sectionFilter], $filters);
    } else {
        // Toutes les sections de l'utilisateur
        $sujets = $enseignantModel->getSujetsForCommissionValidationBySections($search, $userSections, $filters);
    }
} else {
    // Vérifier si l'utilisateur a le droit d'accéder à toutes les données
    // Par exemple, vérifier s'il a un rôle administrateur ou autre rôle avec accès global
    $hasFullAccess = $_SESSION['idRole'] == 1; // Supposons que le rôle 1 est administrateur

    if ($hasFullAccess) {
        // Appliquer les filtres même pour l'administrateur
        $sujets = $enseignantModel->getSujetsForCommissionValidation($search, $filters);
        
        // Si un filtre de section est appliqué spécifiquement
        if ($sectionFilter > 0) {
            $sectionsForFilter = [$sectionFilter];
            $sujets = $enseignantModel->getSujetsForCommissionValidationBySections($search, $sectionsForFilter, $filters);
        }
    } else {
        // Rediriger l'utilisateur sans accès
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Accès refusé',
                text: 'Vous n\'avez pas les droits pour accéder à cette page.'
            }).then(() => {
                window.location.href = 'index';
            });
        </script>";
        include "./views/include/footer.php"; 
        exit;
    }
}




// Récupérer les statistiques filtrées par les sections de l'utilisateur si nécessaire
if ($isResponsableSection) {
    $statsAttente = $enseignantModel->countSujetsByValidationStatusAndSections('En attente', $userSections);
    $statsValides = $enseignantModel->countSujetsByValidationStatusAndSections('Validé', $userSections);
    $statsRejetes = $enseignantModel->countSujetsByValidationStatusAndSections('Rejeté', $userSections);
    $statsModifies = $enseignantModel->countSujetsByValidationStatusAndSections('Modifié', $userSections);
} else {
    $statsAttente = $enseignantModel->countSujetsByValidationStatus('En attente');
    $statsValides = $enseignantModel->countSujetsByValidationStatus('Validé');
    $statsRejetes = $enseignantModel->countSujetsByValidationStatus('Rejeté');
    $statsModifies = $enseignantModel->countSujetsByValidationStatus('Modifié');
}

$totalSujets = $statsAttente + $statsValides + $statsRejetes + $statsModifies;

// Récupérer les données nécessaires
$academicYears = $universite->getAcademicYears();
$specialisations = $universite->getAllSpecialisations();

// Si l'utilisateur est responsable de section, limiter les sections disponibles
if ($isResponsableSection) {
    $sections = [];
    foreach ($userSections as $sectionId) {
        $sectionData = $universite->getSectionById($sectionId);
        if ($sectionData) {
            $sections[] = $sectionData;
        }
    }
} else {
    $sections = $universite->getSections();
}
?>

<!-- Le reste du code HTML reste identique -->

<!-- Après la récupération des données -->

<main id="main" class="main">
    <div class="pagetitle">
        <h1>VALIDATION DES SUJETS PAR LA COMMISSION</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Validation des Sujets</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <!-- Informations sur les sections gérées -->
        <?php if ($isResponsableSection): ?>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-2"></i>
            Vous visualisez uniquement les sujets des étudiants relevant de votre responsabilité.
            <?php if (count($userSections) > 0): ?>
                <strong>Sections:</strong> 
                <?php 
                $sectionNames = [];
                foreach ($userSections as $sectionId) {
                    $sectionData = $universite->getSectionById($sectionId);
                    if ($sectionData) {
                        $sectionNames[] = $sectionData['designationSection'];
                    }
                }
                echo implode(', ', $sectionNames);
                ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <!-- Statistiques des sujets -->
                    <div class="col-xxl-3 col-md-3">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title">En attente</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-hourglass-split text-warning"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?= $statsAttente ?></h6>
                                        <span class="text-muted small pt-1"><?= round(($statsAttente / max(1, $totalSujets)) * 100) ?>% des sujets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-3">
                        <div class="card info-card revenue-card">
                            <div class="card-body">
                                <h5 class="card-title">Validés</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-check-circle text-success"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?= $statsValides ?></h6>
                                        <span class="text-muted small pt-1"><?= round(($statsValides / max(1, $totalSujets)) * 100) ?>% des sujets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-3">
                        <div class="card info-card customers-card">
                            <div class="card-body">
                                <h5 class="card-title">Rejetés</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-x-circle text-danger"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?= $statsRejetes ?></h6>
                                        <span class="text-muted small pt-1"><?= round(($statsRejetes / max(1, $totalSujets)) * 100) ?>% des sujets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xxl-3 col-md-3">
                        <div class="card info-card sales-card">
                            <div class="card-body">
                                <h5 class="card-title">Modifiés</h5>
                                <div class="d-flex align-items-center">
                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                        <i class="bi bi-pencil-square text-primary"></i>
                                    </div>
                                    <div class="ps-3">
                                        <h6><?= $statsModifies ?></h6>
                                        <span class="text-muted small pt-1"><?= round(($statsModifies / max(1, $totalSujets)) * 100) ?>% des sujets</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Liste des Sujets à Valider par la Commission
                                    <div class="float-end">
                                        <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#exportModal">
                                            <i class="bi bi-file-excel"></i> Exporter
                                        </button>
                                        <?php if (!$isResponsableSection || count($userSections) > 1): ?>
                                        <button type="button" class="btn btn-primary me-2" data-bs-toggle="modal" data-bs-target="#filterModal">
                                            <i class="bi bi-funnel"></i> Filtres avancés
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </h5>

                                <!-- Formulaire de recherche simple -->
                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="recherche/choix_etudiant">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher un sujet...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                        <?php if (!empty($search)): ?>
                                        <a href="?view=recherche/choix_etudiant" class="btn btn-secondary">Réinitialiser</a>
                                        <?php endif; ?>
                                    </div>
                                </form>

                                <!-- Modal pour les filtres avancés -->
                                <div class="modal fade" id="filterModal" tabindex="-1" aria-labelledby="filterModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="filterModalLabel">Filtres avancés</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form method="GET" action="">
                                                <div class="modal-body">
                                                    <input type="hidden" name="view" value="recherche/choix_etudiant">
                                                    
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <label for="filter_status" class="form-label">Statut de validation</label>
                                                            <select name="status" id="filter_status" class="form-select">
                                                                <option value="">Tous les statuts</option>
                                                                <option value="En attente" <?= isset($_GET['status']) && $_GET['status'] === 'En attente' ? 'selected' : '' ?>>En attente</option>
                                                                <option value="Validé" <?= isset($_GET['status']) && $_GET['status'] === 'Validé' ? 'selected' : '' ?>>Validé</option>
                                                                <option value="Rejeté" <?= isset($_GET['status']) && $_GET['status'] === 'Rejeté' ? 'selected' : '' ?>>Rejeté</option>
                                                                <option value="Modifié" <?= isset($_GET['status']) && $_GET['status'] === 'Modifié' ? 'selected' : '' ?>>Modifié</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="filter_cycle" class="form-label">Cycle</label>
                                                            <select name="cycle" id="filter_cycle" class="form-select">
                                                                <option value="">Tous les cycles</option>
                                                                <option value="Premier" <?= isset($_GET['cycle']) && $_GET['cycle'] === 'Premier' ? 'selected' : '' ?>>Licence</option>
                                                                <option value="Deuxieme" <?= isset($_GET['cycle']) && $_GET['cycle'] === 'Deuxieme' ? 'selected' : '' ?>>Master</option>
                                                                <option value="Troisieme" <?= isset($_GET['cycle']) && $_GET['cycle'] === 'Troisieme' ? 'selected' : '' ?>>Doctorat</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <label for="filter_specialisation" class="form-label">Spécialisation</label>
                                                            <select name="specialisation" id="filter_specialisation" class="form-select">
                                                                <option value="">Toutes les spécialisations</option>
                                                                <?php foreach ($specialisations as $spec): ?>
                                                                <option value="<?= $spec['idSpecialisation'] ?>" <?= isset($_GET['specialisation']) && $_GET['specialisation'] == $spec['idSpecialisation'] ? 'selected' : '' ?>>
                                                                    <?= htmlspecialchars($spec['designation']) ?> (<?= htmlspecialchars($spec['unite_recherche']) ?>)
                                                                </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        
                                                        <?php if (!$isResponsableSection || count($userSections) > 1): ?>
                                                        <div class="col-md-6">
                                                            <label for="filter_section" class="form-label">Section</label>
                                                            <select name="section" id="filter_section" class="form-select">
                                                                <option value="">Toutes mes sections</option>
                                                                <?php foreach ($sections as $section): ?>
                                                                <option value="<?= $section['idsection'] ?>" <?= isset($_GET['section']) && $_GET['section'] == $section['idsection'] ? 'selected' : '' ?>>
                                                                    <?= htmlspecialchars($section['designationSection']) ?>
                                                                </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    
                                                    <div class="row mb-3">
                                                        <div class="col-md-6">
                                                            <label for="filter_annee" class="form-label">Année académique</label>
                                                            <select name="annee" id="filter_annee" class="form-select">
                                                                <option value="">Toutes les années</option>
                                                                <?php foreach ($academicYears as $year): ?>
                                                                <option value="<?= $year['idannee_acad'] ?>" <?= isset($_GET['annee']) && $_GET['annee'] == $year['idannee_acad'] ? 'selected' : '' ?>>
                                                                    <?= htmlspecialchars($year['designation']) ?>
                                                                </option>
                                                                <?php endforeach; ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label for="filter_student" class="form-label">État d'affectation</label>
                                                            <select name="has_student" id="filter_student" class="form-select">
                                                                <option value="">Tous les sujets</option>
                                                                <option value="1" <?= isset($_GET['has_student']) && $_GET['has_student'] === '1' ? 'selected' : '' ?>>Avec étudiant</option>
                                                                <option value="0" <?= isset($_GET['has_student']) && $_GET['has_student'] === '0' ? 'selected' : '' ?>>Sans étudiant</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                                                    <a href="?view=recherche/choix_etudiant" class="btn btn-warning">Réinitialiser</a>
                                                    <button type="submit" class="btn btn-primary">Appliquer les filtres</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Modal pour l'exportation -->
                                <div class="modal fade" id="exportModal" tabindex="-1" role="dialog" aria-labelledby="exportModalLabel" aria-hidden="true" data-bs-backdrop="static">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Exporter les Sujets de Recherche</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <form method="POST" action="controller/export_sujets.php">
                                                    <div class="mb-3">
                                                        <label for="annee_export" class="form-label">Sélectionner l'année académique</label>
                                                        <select name="annee_export" id="annee_export" class="form-control" required>
                                                            <option value="">Sélectionner une année académique</option>
                                                            <?php foreach ($academicYears as $year): ?>
                                                                <option value="<?= $year['idannee_acad'] ?>"><?= $year['designation'] ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    
                                                    <?php if ($isResponsableSection && count($userSections) > 1): ?>
                                                    <div class="mb-3">
                                                        <label for="section_export" class="form-label">Section (optionnel)</label>
                                                        <select name="section_export" id="section_export" class="form-control">
                                                            <option value="">Toutes mes sections</option>
                                                            <?php foreach ($sections as $section): ?>
                                                                <option value="<?= $section['idsection'] ?>"><?= $section['designationSection'] ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <?php elseif ($isResponsableSection): ?>
                                                        <input type="hidden" name="section_export" value="<?= $userSections[0] ?>">
                                                    <?php endif; ?>
                                                    
                                                    <div class="mb-3">
                                                        <label for="status_export" class="form-label">Statut (optionnel)</label>
                                                        <select name="status_export" id="status_export" class="form-control">
                                                            <option value="">Tous les statuts</option>
                                                            <option value="En attente">En attente</option>
                                                            <option value="Validé">Validé</option>
                                                            <option value="Rejeté">Rejeté</option>
                                                            <option value="Modifié">Modifié</option>
                                                        </select>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                                                        <button type="submit" class="btn btn-success">
                                                            <i class="bi bi-file-excel"></i> Exporter
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Affichage des filtres actifs -->
                                <?php if (isset($_GET['status']) || isset($_GET['cycle']) || isset($_GET['specialisation']) || 
                                         isset($_GET['section']) || isset($_GET['annee']) || isset($_GET['has_student'])): ?>
                                <div class="mb-3">
                                    <div class="alert alert-info">
                                        <h6 class="mb-2"><i class="bi bi-funnel-fill me-2"></i>Filtres actifs:</h6>
                                        <div class="d-flex flex-wrap gap-2">
                                            <?php if (isset($_GET['status']) && !empty($_GET['status'])): ?>
                                                <span class="badge bg-secondary p-2">Statut: <?= htmlspecialchars($_GET['status']) ?></span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_GET['cycle']) && !empty($_GET['cycle'])): ?>
                                                <span class="badge bg-secondary p-2">Cycle: 
                                                    <?= $_GET['cycle'] === 'Premier' ? 'Licence' : 
                                                       ($_GET['cycle'] === 'Deuxieme' ? 'Master' : 'Doctorat') ?>
                                                </span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_GET['specialisation']) && !empty($_GET['specialisation'])): 
                                                $specName = '';
                                                foreach ($specialisations as $spec) {
                                                    if ($spec['idSpecialisation'] == $_GET['specialisation']) {
                                                        $specName = $spec['designation'];
                                                        break;
                                                    }
                                                }
                                            ?>
                                                <span class="badge bg-secondary p-2">Spécialisation: <?= htmlspecialchars($specName) ?></span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_GET['section']) && !empty($_GET['section'])): 
                                                $sectionName = '';
                                                foreach ($sections as $section) {
                                                    if ($section['idsection'] == $_GET['section']) {
                                                        $sectionName = $section['designationSection'];
                                                        break;
                                                    }
                                                }
                                            ?>
                                                <span class="badge bg-secondary p-2">Section: <?= htmlspecialchars($sectionName) ?></span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_GET['annee']) && !empty($_GET['annee'])): 
                                                $yearName = '';
                                                foreach ($academicYears as $year) {
                                                    if ($year['idannee_acad'] == $_GET['annee']) {
                                                        $yearName = $year['designation'];
                                                        break;
                                                    }
                                                }
                                            ?>
                                                <span class="badge bg-secondary p-2">Année: <?= htmlspecialchars($yearName) ?></span>
                                            <?php endif; ?>
                                            
                                            <?php if (isset($_GET['has_student'])): ?>
                                                <span class="badge bg-secondary p-2">
                                                    <?= $_GET['has_student'] === '1' ? 'Avec étudiant' : 'Sans étudiant' ?>
                                                </span>
                                            <?php endif; ?>
                                            
                                            <a href="?view=recherche/choix_etudiant" class="badge bg-danger p-2 text-decoration-none">
                                                <i class="bi bi-x-circle me-1"></i>Effacer tous les filtres
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Intitulé</th>
                                            <th scope="col">Cycle</th>
                                            <th scope="col">Spécialisation</th>
                                            <th scope="col">État</th>
                                            <th scope="col">Statut Validation</th>
                                            <th scope="col">Étudiant</th>
                                            <th scope="col">Directeur</th>
                                            <th scope="col">Encadreur</th>
                                            <th scope="col">Année</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($sujets as $sujet) {
                                            $intituleJS = htmlspecialchars(json_encode($sujet['intitule']), ENT_QUOTES, 'UTF-8');
                                            $etudiantInfo = !empty($sujet['etudiant']) ? $sujet['etudiant'] : '<span class="text-muted">Non assigné</span>';
                                            $directeurInfo = !empty($sujet['directeur']) ? $sujet['directeur'] : '<span class="text-muted">Non assigné</span>';
                                            $encadreurInfo = !empty($sujet['encadreur']) ? $sujet['encadreur'] : '<span class="text-muted">Non assigné</span>';
                                            $commentaireJS = !empty($sujet['commentaire_commission']) ? 
                                            htmlspecialchars(json_encode($sujet['commentaire_commission']), ENT_QUOTES, 'UTF-8') : 
                                            "null"; // Utiliser null en JavaScript est plus propre pour une valeur inexistante

                                            // Définir la classe de la cellule État selon le statut
                                            $etatClass = '';
                                            switch($sujet['etatSujet']) {
                                                case 'En attente':
                                                    $etatClass = 'text-warning';
                                                    break;
                                                case 'Validé':
                                                    $etatClass = 'text-success';
                                                    break;
                                                case 'Rejeté':
                                                    $etatClass = 'text-danger';
                                                    break;
                                            }
                                            
                                            // Définir la classe pour le statut de validation
                                            $validationClass = '';
                                            switch($sujet['statut_validation']) {
                                                case 'En attente':
                                                    $validationClass = 'text-warning';
                                                    break;
                                                case 'Validé':
                                                    $validationClass = 'text-success';
                                                    break;
                                                case 'Rejeté':
                                                    $validationClass = 'text-danger';
                                                    break;
                                                case 'Modifié':
                                                    $validationClass = 'text-primary';
                                                    break;
                                            }

                                            $etudiantId = !empty($sujet['etudiant_idetudiant']) ? $sujet['etudiant_idetudiant'] : 'null';
                                            $directeurId = !empty($sujet['idDirecteur']) ? $sujet['idDirecteur'] : 'null';
                                            $encadreurId = !empty($sujet['idEncadreur']) ? $sujet['idEncadreur'] : 'null';
                                            $etatSujet = htmlspecialchars(addslashes($sujet['etatSujet']), ENT_QUOTES);
                                            $statutValidation = htmlspecialchars(addslashes($sujet['statut_validation']), ENT_QUOTES);

                                            echo "<tr>
                                                <td>{$i}</td>
                                                <td>{$sujet['intitule']}</td>
                                                <td>{$sujet['cycle']}</td>
                                                <td>{$sujet['specialisation']}</td>
                                                <td class='{$etatClass}'>{$sujet['etatSujet']}</td>
                                                <td class='{$validationClass}'>{$sujet['statut_validation']}</td>
                                                <td>{$etudiantInfo}</td>
                                                <td>{$directeurInfo}</td>
                                                <td>{$encadreurInfo}</td>
                                                <td>{$sujet['annee']}</td>
                                                <td>
                                                    <div class='btn-group'>
                                                        <button class='btn btn-sm btn-primary' onclick='openCommissionModal({$sujet['idsujets']}, 
                                                            {$intituleJS}, 
                                                            \"{$sujet['cycle']}\", 
                                                            {$sujet['idSpecialisation']}, 
                                                            {$sujet['annee_acad_idannee_acad']},
                                                            {$etudiantId},
                                                            {$directeurId},
                                                            {$encadreurId},
                                                            \"{$etatSujet}\",
                                                            \"{$statutValidation}\",
                                                            {$commentaireJS})'>
                                                            <i class='bi bi-pencil'></i> Évaluer
                                                        </button>
                                                        <div class='btn-group ms-1'>
                                                            <button type='button' class='btn btn-sm btn-secondary dropdown-toggle' data-bs-toggle='dropdown' aria-expanded='false'>
                                                                Actions <i class='bi bi-caret-down-fill'></i>
                                                            </button>
                                                            <ul class='dropdown-menu'>
                                                                <li>
                                                                    <button class='dropdown-item text-success' onclick='validateSujet({$sujet['idsujets']})'>
                                                                        <i class='bi bi-check-circle'></i> Valider
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    <button class='dropdown-item text-danger' onclick='rejectSujet({$sujet['idsujets']})'>
                                                                        <i class='bi bi-x-circle'></i> Rejeter
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    <button class='dropdown-item text-warning' onclick='modifySujet({$sujet['idsujets']})'>
                                                                        <i class='bi bi-pencil-square'></i> Modifier
                                                                    </button>
                                                                </li>
                                                                <li><hr class='dropdown-divider'></li>
                                                                <li>
                                                                    <button class='dropdown-item' onclick='viewSujetHistory({$sujet['idsujets']})'>
                                                                        <i class='bi bi-clock-history'></i> Historique
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>                                            
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                
                                <?php if (empty($sujets)): ?>
                                <div class="alert alert-info text-center">
                                    <i class="bi bi-info-circle me-2"></i>
                                    Aucun sujet ne correspond aux critères de recherche ou aux filtres appliqués.
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal d'historique de validation -->
<div class="modal fade" id="historyModal" tabindex="-1" role="dialog" aria-labelledby="historyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="historyModalLabel">Historique des validations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <div id="historyContent" class="timeline-container">
                    <!-- L'historique sera chargé ici via AJAX -->
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Chargement...</span>
                        </div>
                        <p class="mt-2">Chargement de l'historique...</p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Évaluation de la Commission -->
<div class="modal fade" id="commissionModal" tabindex="-1" role="dialog" aria-labelledby="commissionModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="commissionModalLabel">Évaluation du sujet par la Commission</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="commissionForm" method="POST" action="controller/sujet_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="idsujets" id="commission_idsujets">
                    <input type="hidden" name="action" value="commission_validation">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label class="form-label">Intitulé du sujet</label>
                            <input type="text" name="intitule" id="commission_intitule" class="form-control" readonly>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Cycle</label>
                            <input type="text" name="cycle" id="commission_cycle" class="form-control" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Année académique</label>
                            <input type="text" name="annee_acad" id="commission_annee" class="form-control" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Spécialisation</label>
                            <select name="idSpecialisation" id="commission_specialisation" class="form-select" required>
                                <option value="">Sélectionner une spécialisation</option>
                                <?php foreach ($specialisations as $spec): ?>
                                <option value="<?= $spec['idSpecialisation'] ?>"><?= htmlspecialchars($spec['designation']) ?> (<?= htmlspecialchars($spec['unite_recherche']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une spécialisation.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">État actuel</label>
                            <input type="text" id="commission_etat" class="form-control" readonly>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Statut de validation</label>
                            <input type="text" name="statut_validation" id="commission_statut" class="form-control" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="commission_decision" class="form-label">Décision de la commission</label>
                            <select name="decision" id="commission_decision" class="form-select" required>
                                <option value="">Sélectionner une décision</option>
                                <option value="validate">Valider le sujet</option>
                                <option value="reject">Rejeter le sujet</option>
                                <option value="modify">Demander des modifications</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une décision.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="commission_commentaire" class="form-label">Commentaire de la commission</label>
                            <textarea name="commentaire_commission" id="commission_commentaire" class="form-control" rows="4" placeholder="Entrez votre commentaire ici..."></textarea>
                            <small class="form-text text-muted">Obligatoire en cas de rejet ou de demande de modification.</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3 assignation-section">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header bg-light">
                                    <h6 class="mb-0">Assignation des encadrants et étudiant</h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="commission_directeur" class="form-label">Directeur</label>
                                            <select name="directeur" id="commission_directeur" class="form-select">
                                                <option value="">Sélectionner un directeur</option>
                                                <!-- Options à charger dynamiquement via AJAX -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="commission_encadreur" class="form-label">Encadreur</label>
                                            <select name="encadreur" id="commission_encadreur" class="form-select">
                                                <option value="">Sélectionner un encadreur</option>
                                                <!-- Options à charger dynamiquement via AJAX -->
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label for="commission_etudiant" class="form-label">Étudiant</label>
                                            <select name="etudiant" id="commission_etudiant" class="form-select">
                                                <option value="">Sélectionner un étudiant</option>
                                                <!-- Options à charger dynamiquement via AJAX -->
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer l'évaluation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialisation des select2 pour une meilleure expérience utilisateur
    if (typeof $.fn.select2 !== 'undefined') {
        $('.form-select').select2({
            theme: 'bootstrap-5',
            width: '100%'
        });
    }
    
    // Préparation de l'URL avec les filtres pour l'export
    document.querySelector('#exportModal form').addEventListener('submit', function(e) {
        const form = this;
        const searchParams = new URLSearchParams(window.location.search);
        
        // Ajouter les filtres actuels comme champs cachés pour l'export
        if (searchParams.has('status')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'filter_status';
            input.value = searchParams.get('status');
            form.appendChild(input);
        }
        
        if (searchParams.has('cycle')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'filter_cycle';
            input.value = searchParams.get('cycle');
            form.appendChild(input);
        }
        
        if (searchParams.has('specialisation')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'filter_specialisation';
            input.value = searchParams.get('specialisation');
            form.appendChild(input);
        }
        
        if (searchParams.has('search')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'filter_search';
            input.value = searchParams.get('search');
            form.appendChild(input);
        }
    });
});



function validateSujet(idSujet) {
    Swal.fire({
        title: 'Valider le sujet',
        text: "Êtes-vous sûr de vouloir valider ce sujet par la commission ?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, valider',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'controller/validate_commission.php?idsujets=' + idSujet + '&action=validate';
        }
    });
}

function rejectSujet(idSujet) {
    Swal.fire({
        title: 'Rejeter le sujet',
        text: "Êtes-vous sûr de vouloir rejeter ce sujet ?",
        icon: 'warning',
        input: 'textarea',
        inputPlaceholder: 'Commentaire de rejet...',
        inputAttributes: {
            'aria-label': 'Commentaire de rejet'
        },
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, rejeter',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            const commentaire = result.value || '';
            window.location.href = 'controller/validate_commission.php?idsujets=' + idSujet + '&action=reject&commentaire=' + encodeURIComponent(commentaire);
        }
    });
}

function modifySujet(idSujet) {
    Swal.fire({
        title: 'Demander une modification',
        text: "Veuillez préciser les modifications demandées",
        icon: 'info',
        input: 'textarea',
        inputPlaceholder: 'Commentaire sur les modifications demandées...',
        inputAttributes: {
            'aria-label': 'Commentaire sur les modifications'
        },
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Demander modification',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            const commentaire = result.value || '';
            window.location.href = 'controller/validate_commission.php?idsujets=' + idSujet + '&action=modify&commentaire=' + encodeURIComponent(commentaire);
        }
    });
}

function viewSujetHistory(idSujet) {
    // Afficher le modal d'historique
    const historyModal = new bootstrap.Modal(document.getElementById('historyModal'));
    historyModal.show();
    
    // Réinitialiser le contenu
    const historyContent = document.getElementById('historyContent');
    historyContent.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Chargement...</span>
            </div>
            <p class="mt-2">Chargement de l'historique...</p>
        </div>
    `;
    
    // Charger l'historique via AJAX
    fetch(`controller/get_sujet_history.php?id=${idSujet}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur réseau');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Si aucun historique n'est disponible
            if (!data.history || data.history.length === 0) {
                historyContent.innerHTML = `
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Aucun historique de validation disponible pour ce sujet.
                    </div>
                `;
                return;
            }
            
            // Construire la timeline d'historique
            let timelineHTML = '<ul class="timeline">';
            
            data.history.forEach(item => {
                timelineHTML += `
                    <li class="timeline-item mb-5">
                        <span class="timeline-badge bg-${getStatusColor(item.status)}">
                            <i class="bi ${getStatusIcon(item.status)}"></i>
                        </span>
                        <div class="timeline-item-content">
                            <h6 class="fw-bold mb-1">${item.status}</h6>
                            <p class="text-muted mb-2">
                                <small>${formatDate(item.date)}</small>
                            </p>
                            <p>${item.comment || 'Aucun commentaire'}</p>
                            <p>
                                <small class="text-muted">Par: ${item.user}</small>
                            </p>
                        </div>
                    </li>
                `;
            });
            
            timelineHTML += '</ul>';
            historyContent.innerHTML = timelineHTML;
        })
        .catch(error => {
            historyContent.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle me-2"></i>
                    Erreur lors du chargement de l'historique: ${error.message}
                </div>
            `;
        });
}

// Fonctions utilitaires pour l'historique
function getStatusColor(status) {
    switch(status) {
        case 'Validé': return 'success';
        case 'Rejeté': return 'danger';
        case 'Modifié': return 'warning';
        case 'En attente': return 'info';
        default: return 'secondary';
    }
}

function getStatusIcon(status) {
    switch(status) {
        case 'Validé': return 'bi-check-circle';
        case 'Rejeté': return 'bi-x-circle';
        case 'Modifié': return 'bi-pencil-square';
        case 'En attente': return 'bi-hourglass-split';
        default: return 'bi-circle';
    }
}

function formatDate(dateString) {
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}



// Compléter la fonction existante openCommissionModal
function openCommissionModal(id, intitule, cycle, idSpecialisation, anneeAcad, etudiantId, directeurId, encadreurId, etatSujet, statutValidation, commentaire) {
    // Remplir les champs du formulaire
    document.getElementById('commission_idsujets').value = id;
    document.getElementById('commission_intitule').value = intitule;
    document.getElementById('commission_cycle').value = cycle;
    document.getElementById('commission_etat').value = etatSujet;
    document.getElementById('commission_statut').value = statutValidation;
    document.getElementById('commission_annee').value = anneeAcad;
    // Sélectionner la spécialisation
    const specSelect = document.getElementById('commission_specialisation');
    if (specSelect) {
        specSelect.value = idSpecialisation;
    }
    
    // Réinitialiser et remplir le commentaire s'il existe
    const commentaireField = document.getElementById('commission_commentaire');
    commentaireField.value = commentaire ? commentaire : '';
    
    // Chargement dynamique des enseignants pour directeur et encadreur
    loadEnseignants('commission_directeur', directeurId);
    loadEnseignants('commission_encadreur', encadreurId);
    
    // Chargement dynamique des étudiants
    loadEtudiants('commission_etudiant', etudiantId, anneeAcad, cycle);
    
    // Réinitialiser le formulaire de validation
    document.getElementById('commission_decision').value = '';
    
    // Afficher le modal
    var commissionModal = new bootstrap.Modal(document.getElementById('commissionModal'));
    commissionModal.show();
}

// Fonction pour charger les enseignants
function loadEnseignants(selectId, selectedValue) {
    const select = document.getElementById(selectId);
    
    // Ajouter un spinner pendant le chargement
    select.innerHTML = '<option value="">Chargement...</option>';
    
    fetch('controller/get_enseignants.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur réseau');
            }
            return response.json();
        })
        .then(data => {
            // Réinitialiser le select
            select.innerHTML = '<option value="">Sélectionner un enseignant</option>';
            
            // Ajouter les options
            data.forEach(enseignant => {
                const option = document.createElement('option');
                option.value = enseignant.idAgent;
                option.textContent = enseignant.noms + '('+ enseignant.grade +')';
                select.appendChild(option);
            });
            
            // Sélectionner la valeur si elle existe
            if (selectedValue && selectedValue !== 'null') {
                select.value = selectedValue;
            }
        })
        .catch(error => {
            select.innerHTML = '<option value="">Erreur de chargement</option>';
            console.error('Erreur:', error);
        });
}

// Fonction pour charger les étudiants
function loadEtudiants(selectId, selectedValue, anneeAcad, cycle) {
    const select = document.getElementById(selectId);
    
    // Ajouter un spinner pendant le chargement
    select.innerHTML = '<option value="">Chargement...</option>';
    
    fetch(`controller/get_etudiants.php?annee=${anneeAcad}&cycle=${encodeURIComponent(cycle)}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur réseau');
            }
            return response.json();
        })
        .then(data => {
            // Réinitialiser le select
            select.innerHTML = '<option value="">Sélectionner un étudiant</option>';
            
            // Ajouter les options
            data.forEach(etudiant => {
                const option = document.createElement('option');
                option.value = etudiant.idetudiant;
                option.textContent = etudiant.noms +'('+ etudiant.matricule +')';
                select.appendChild(option);
            });
            
            // Sélectionner la valeur si elle existe
            if (selectedValue && selectedValue !== 'null') {
                select.value = selectedValue;
            }
        })
        .catch(error => {
            select.innerHTML = '<option value="">Erreur de chargement</option>';
            console.error('Erreur:', error);
        });
}

// Validation du formulaire
document.addEventListener('DOMContentLoaded', function() {
    const commissionForm = document.getElementById('commissionForm');
    const decisionSelect = document.getElementById('commission_decision');
    const commentaireField = document.getElementById('commission_commentaire');
    
    if (commissionForm) {
        commissionForm.addEventListener('submit', function(e) {
            const decision = decisionSelect.value;
            const commentaire = commentaireField.value.trim();
            
            // Vérifier si un commentaire est requis
            if ((decision === 'reject' || decision === 'modify') && commentaire === '') {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Commentaire requis',
                    text: 'Veuillez fournir un commentaire pour justifier le rejet ou la demande de modification.'
                });
                commentaireField.classList.add('is-invalid');
            } else {
                commentaireField.classList.remove('is-invalid');
            }
        });
        
        // Mettre à jour la validation du commentaire quand la décision change
        decisionSelect.addEventListener('change', function() {
            const decision = this.value;
            
            if (decision === 'reject' || decision === 'modify') {
                commentaireField.setAttribute('required', 'required');
            } else {
                commentaireField.removeAttribute('required');
            }
        });
    }
});

</script>

<style>
/* Style pour la timeline d'historique */
.timeline-container {
    max-height: 60vh;
    overflow-y: auto;
    padding: 15px;
}

.timeline {
    position: relative;
    list-style: none;
    padding-left: 0;
}

.timeline::before {
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    left: 16px;
    width: 2px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    padding-left: 40px;
}

.timeline-badge {
    position: absolute;
    left: 8px;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    text-align: center;
    color: white;
    z-index: 1;
}

.timeline-badge i {
    font-size: 8px;
    position: relative;
    top: -6px;
}

.timeline-item-content {
    background-color: #f8f9fa;
    border-radius: 4px;
    padding: 15px;
    position: relative;
}
</style>

<?php include "./views/include/footer_file.php"; ?>


