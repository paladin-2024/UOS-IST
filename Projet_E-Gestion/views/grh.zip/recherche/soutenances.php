<?php
include "./views/include/header.php";

// Initialisation des classes
$depotSoutenanceModel = new DepotSoutenance();
$universite = new Universite();

// Récupération de l'année académique actuelle ou sélectionnée
$annees = $universite->getAcademicYears();
$selectedYear = isset($_GET['annee_acad']) && !empty($_GET['annee_acad']) 
    ? intval($_GET['annee_acad']) 
    : $universite->getCurrentAcademicYear()['idannee_acad'];

// Récupérer toutes les sections accessibles à l'utilisateur
$sections = [];
if ($_SESSION['idRole'] == 1) { // Si administrateur
    $sections = $universite->getSections();
    $selectedSection = isset($_GET['section']) ? intval($_GET['section']) : 0;
} else {
    // Pour les autres utilisateurs, vérifier les sections associées
    $userSections = $universite->getUserSections($_SESSION['id']);
    foreach ($userSections as $sectionId) {
        $sectionData = $universite->getSectionById($sectionId);
        if ($sectionData) {
            $sections[] = $sectionData;
        }
    }
    // Sélectionner la première section disponible si pas de sélection
    $selectedSection = isset($_GET['section']) ? intval($_GET['section']) : (count($sections) > 0 ? $sections[0]['idsection'] : 0);
}

// Si l'utilisateur n'est pas admin et n'a aucune section, rediriger
if (empty($sections) && $_SESSION['idRole'] != 1) {
    echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur des Accès système',
                        html: 'Vous n\'avez accès à aucune section'
                    }).then(() => {
                        window.location.href = 'index';
                    });
                </script>";
                include "./views/include/footer.php"; 
                exit;
                
    
}

// Récupérer les statistiques selon le rôle et la section sélectionnée
$statMemoires = $_SESSION['idRole'] == 1 && $selectedSection == 0 
    ? $depotSoutenanceModel->getStatistiquesMemoires($selectedYear) 
    : $depotSoutenanceModel->getStatistiquesMemoires($selectedYear, $selectedSection);
    
$statRapports = $_SESSION['idRole'] == 1 && $selectedSection == 0 
    ? $depotSoutenanceModel->getStatistiquesRapports($selectedYear) 
    : $depotSoutenanceModel->getStatistiquesRapports($selectedYear, $selectedSection);
    
$statSoutenances = $_SESSION['idRole'] == 1 && $selectedSection == 0 
    ? $depotSoutenanceModel->getStatistiquesSoutenances($selectedYear) 
    : $depotSoutenanceModel->getStatistiquesSoutenances($selectedYear, $selectedSection);
    
$statSujets = $_SESSION['idRole'] == 1 && $selectedSection == 0 
    ? $depotSoutenanceModel->getStatistiquesSujets($selectedYear) 
    : $depotSoutenanceModel->getStatistiquesSujets($selectedYear, $selectedSection);

$statEncadrement = $_SESSION['idRole'] == 1 && $selectedSection == 0 
    ? $depotSoutenanceModel->getStatistiquesEncadrement($selectedYear) 
    : $depotSoutenanceModel->getStatistiquesEncadrement($selectedYear, $selectedSection);

// Préparer les données pour les graphiques
$sectionsLabels = [];
$memoires = [];
$rapports = [];
$soutenances = [];

if ($_SESSION['idRole'] == 1 && $selectedSection == 0) {
    // Pour l'admin qui voit toutes les sections
    foreach ($statMemoires as $stat) {
        $sectionsLabels[] = $stat['designationSection'];
        $memoires[] = $stat['nb_total'];
    }
    
    foreach ($statRapports as $stat) {
        $rapports[] = $stat['nb_total'];
    }
    
    foreach ($statSoutenances as $stat) {
        $soutenances[] = $stat['nb_total'];
    }
} else {
    // Pour un utilisateur avec une section spécifique ou admin filtrant par section
    if (!empty($statMemoires)) {
        $sectionsLabels[] = $statMemoires[0]['designationSection'];
        $memoires[] = $statMemoires[0]['nb_total'];
    }
    
    if (!empty($statRapports)) {
        $rapports[] = $statRapports[0]['nb_total'];
    }
    
    if (!empty($statSoutenances)) {
        $soutenances[] = $statSoutenances[0]['nb_total'];
    }
}
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>TABLEAU DE BORD - DÉPÔTS ET SOUTENANCES</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item">Recherche</li>
                <li class="breadcrumb-item active">Tableau de bord</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <!-- Filtres -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" action="" class="row g-3 align-items-center mb-3">
                            <input type="hidden" name="view" value="recherche/soutenances">
                            
                            <div class="col-md-4">
                            <label for="annee_acad" class="form-label">Année académique</label>
                                <select name="annee_acad" id="annee_acad" class="form-select">
                                    <?php foreach ($annees as $annee): ?>
                                        <option value="<?= $annee['idannee_acad'] ?>" <?= $selectedYear == $annee['idannee_acad'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($annee['designation']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <?php if ($_SESSION['idRole'] == 1): ?> <!-- Option Section seulement pour admin -->
                            <div class="col-md-4">
                                <label for="section" class="form-label">Section</label>
                                <select name="section" id="section" class="form-select">
                                    <option value="0">Toutes les sections</option>
                                    <?php foreach ($sections as $section): ?>
                                        <option value="<?= $section['idsection'] ?>" <?= $selectedSection == $section['idsection'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($section['designationSection']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php else: ?>
                            <div class="col-md-4">
                                <label for="section" class="form-label">Section</label>
                                <select name="section" id="section" class="form-select">
                                    <?php foreach ($sections as $section): ?>
                                        <option value="<?= $section['idsection'] ?>" <?= $selectedSection == $section['idsection'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($section['designationSection']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-filter"></i> Filtrer
                                </button>
                                <div class="dropdown ms-2">
                                    <button class="btn btn-success dropdown-toggle" type="button" id="exportDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="bi bi-file-excel"></i> Exporter
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="exportDropdown">
                                        <li>
                                            <a class="dropdown-item" href="controller/export_soutenance_controller.php?type=eligible&section=<?= $selectedSection ?>&annee=<?= $selectedYear ?>">
                                                Étudiants éligibles à la soutenance
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="controller/export_soutenance_controller.php?type=litige&section=<?= $selectedSection ?>&annee=<?= $selectedYear ?>">
                                                Étudiants avec litiges de frais
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        


        <!-- Cartes résumé -->
        <div class="row">
            <!-- Carte mémoires -->
            <div class="col-xxl-4 col-md-4">
                <div class="card info-card sales-card">
                    <div class="card-body">
                        <h5 class="card-title">Mémoires <span>| <?= $_SESSION['idRole'] == 1 && $selectedSection == 0 ? 'Toutes sections' : 'Section sélectionnée' ?></span></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-journal-text"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= array_sum($memoires) ?></h6>
                                <span class="text-success small pt-1 fw-bold">Dépôts</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Carte rapports -->
            <div class="col-xxl-4 col-md-4">
                <div class="card info-card revenue-card">
                    <div class="card-body">
                        <h5 class="card-title">Rapports <span>| <?= $_SESSION['idRole'] == 1 && $selectedSection == 0 ? 'Toutes sections' : 'Section sélectionnée' ?></span></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= array_sum($rapports) ?></h6>
                                <span class="text-success small pt-1 fw-bold">Dépôts</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Carte soutenances -->
            <div class="col-xxl-4 col-md-4">
                <div class="card info-card customers-card">
                    <div class="card-body">
                        <h5 class="card-title">Soutenances <span>| <?= $_SESSION['idRole'] == 1 && $selectedSection == 0 ? 'Toutes sections' : 'Section sélectionnée' ?></span></h5>
                        <div class="d-flex align-items-center">
                            <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                <i class="bi bi-calendar-event"></i>
                            </div>
                            <div class="ps-3">
                                <h6><?= array_sum($soutenances) ?></h6>
                                <span class="text-success small pt-1 fw-bold">Programmées</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Graphiques et tableaux détaillés -->
        <div class="row">
            <!-- Graphique statistiques des mémoires par trimestre -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Dépôts de mémoires par trimestre</h5>
                        <canvas id="memoiresChart" style="max-height: 400px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Graphique statistiques des soutenances par statut -->
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statut des soutenances</h5>
                        <canvas id="soutenancesChart" style="max-height: 400px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tableaux de statistiques détaillées -->
        <div class="row">
            <?php if ($_SESSION['idRole'] == 1 && $selectedSection == 0): ?>
            <!-- Tableau détaillé pour l'admin (toutes les sections) -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statistiques détaillées par section</h5>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Section</th>
                                        <th>Mémoires</th>
                                        <th>Rapports</th>
                                        <th>Soutenances</th>
                                        <th>Soutenances terminées</th>
                                        <th>Taux d'achèvement</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($statMemoires as $index => $statMem): ?>
                                        <?php 
                                        $section = $statMem['designationSection'];
                                        $nbMemoires = $statMem['nb_total'];
                                        $nbRapports = isset($statRapports[$index]) ? $statRapports[$index]['nb_total'] : 0;
                                        $nbSoutenances = isset($statSoutenances[$index]) ? $statSoutenances[$index]['nb_total'] : 0;
                                        $nbTerminees = isset($statSoutenances[$index]) ? $statSoutenances[$index]['terminees'] : 0;
                                        $tauxAchevement = $nbSoutenances > 0 ? round(($nbTerminees / $nbSoutenances) * 100) : 0;
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($section) ?></td>
                                            <td><?= $nbMemoires ?></td>
                                            <td><?= $nbRapports ?></td>
                                            <td><?= $nbSoutenances ?></td>
                                            <td><?= $nbTerminees ?></td>
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= $tauxAchevement ?>%" 
                                                         aria-valuenow="<?= $tauxAchevement ?>" aria-valuemin="0" aria-valuemax="100">
                                                        <?= $tauxAchevement ?>%
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="?view=recherche/depot_soutenance&section=<?= $statMem['idsection'] ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-eye"></i> Détails
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <!-- Statistiques d'encadrement pour une section spécifique -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statistiques d'encadrement</h5>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>Enseignant</th>
                                        <th>Sujets dirigés</th>
                                        <th>Sujets encadrés</th>
                                        <th>Participations au jury</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($statEncadrement as $encadrement): ?>
                                        <?php 
                                        $total = $encadrement['nb_sujets_diriges'] + $encadrement['nb_sujets_encadres'] + $encadrement['nb_jury'];
                                        ?>
                                        <tr>
                                            <td><?= htmlspecialchars($encadrement['noms']) ?></td>
                                            <td><?= $encadrement['nb_sujets_diriges'] ?></td>
                                            <td><?= $encadrement['nb_sujets_encadres'] ?></td>
                                            <td><?= $encadrement['nb_jury'] ?></td>
                                            <td><strong><?= $total ?></strong></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Statistiques des sujets de recherche pour une section spécifique -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Statistiques des sujets de recherche</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <canvas id="sujetsChart" style="max-height: 300px;"></canvas>
                            </div>
                            <div class="col-md-6">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Statut</th>
                                                <th>Nombre</th>
                                                <th>Pourcentage</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            if (!empty($statSujets)) {
                                                $stat = $statSujets[0];
                                                $total = $stat['nb_total'];
                                                $statuts = [
                                                    'En attente' => $stat['en_attente'],
                                                    'Validés' => $stat['valides'],
                                                    'Rejetés' => $stat['rejetes'],
                                                    'Modifiés' => $stat['sujets_modifies']  // Mettre à jour ici
                                                ];
                                                
                                                
                                                foreach ($statuts as $label => $value) {
                                                    $pourcentage = $total > 0 ? round(($value / $total) * 100) : 0;
                                                    echo '<tr>';
                                                    echo '<td>' . $label . '</td>';
                                                    echo '<td>' . $value . '</td>';
                                                    echo '<td>' . $pourcentage . '%</td>';
                                                    echo '</tr>';
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<!-- Scripts pour les graphiques (Chart.js) -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Configuration des graphiques
    
    // Graphique des mémoires par trimestre
    <?php if (!empty($statMemoires)): ?>
    var ctxMemoires = document.getElementById('memoiresChart').getContext('2d');
    var memoiresChart = new Chart(ctxMemoires, {
        type: 'bar',
        data: {
            labels: ['T1 (Jan-Mar)', 'T2 (Avr-Jun)', 'T3 (Jul-Sep)', 'T4 (Oct-Dec)'],
            datasets: [
                <?php if ($_SESSION['idRole'] == 1 && $selectedSection == 0): ?>
                    <?php foreach ($statMemoires as $index => $stat): ?>
                    {
                        label: '<?= addslashes($stat['designationSection']) ?>',
                        data: [<?= $stat['t1'] ?>, <?= $stat['t2'] ?>, <?= $stat['t3'] ?>, <?= $stat['t4'] ?>],
                        backgroundColor: 'rgba(<?= 75 + ($index * 50) % 180 ?>, <?= 192 - ($index * 30) % 150 ?>, <?= 192 + ($index * 40) % 60 ?>, 0.6)'
                    },
                    <?php endforeach; ?>
                <?php else: ?>
                    {
                        label: 'Mémoires déposés',
                        data: [
                            <?= !empty($statMemoires) ? $statMemoires[0]['t1'] : 0 ?>, 
                            <?= !empty($statMemoires) ? $statMemoires[0]['t2'] : 0 ?>, 
                            <?= !empty($statMemoires) ? $statMemoires[0]['t3'] : 0 ?>, 
                            <?= !empty($statMemoires) ? $statMemoires[0]['t4'] : 0 ?>
                        ],
                        backgroundColor: 'rgba(75, 192, 192, 0.6)'
                    }
                <?php endif; ?>
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    precision: 0
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                }
            }
        }
    });
    <?php endif; ?>
    
    // Graphique des soutenances par statut
    <?php if (!empty($statSoutenances)): ?>
    var ctxSoutenances = document.getElementById('soutenancesChart').getContext('2d');
    var soutenancesChart = new Chart(ctxSoutenances, {
        type: 'pie',
        data: {
            labels: ['Programmées', 'Terminées', 'Reportées', 'Annulées'],
            datasets: [{
                data: [
                    <?php 
                    if ($_SESSION['idRole'] == 1 && $selectedSection == 0) {
                        $programmees = $reportees = $terminees = $annulees = 0;
                        foreach ($statSoutenances as $stat) {
                            $programmees += $stat['programmees'];
                            $terminees += $stat['terminees'];
                            $reportees += $stat['reportees'];
                            $annulees += $stat['annulees'];
                        }
                        echo "$programmees, $terminees, $reportees, $annulees";
                    } else {
                        if (!empty($statSoutenances)) {
                            echo $statSoutenances[0]['programmees'] . ', ' . 
                                 $statSoutenances[0]['terminees'] . ', ' . 
                                 $statSoutenances[0]['reportees'] . ', ' . 
                                 $statSoutenances[0]['annulees'];
                        } else {
                            echo "0, 0, 0, 0";
                        }
                    }
                    ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(255, 99, 132, 0.7)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    <?php endif; ?>
    
    // Graphique des sujets par statut (pour section spécifique)
    <?php if (!($_SESSION['idRole'] == 1 && $selectedSection == 0) && !empty($statSujets)): ?>
    var ctxSujets = document.getElementById('sujetsChart').getContext('2d');
    var sujetsChart = new Chart(ctxSujets, {
        type: 'doughnut',
        data: {
            labels: ['En attente', 'Validés', 'Rejetés', 'Modifiés'],
            datasets: [{
                data: [
                    <?= $statSujets[0]['en_attente'] ?>, 
                    <?= $statSujets[0]['valides'] ?>, 
                    <?= $statSujets[0]['rejetes'] ?>, 
                    <?= $statSujets[0]['sujets_modifies'] ?>  // Mettre à jour ici
                ],

                backgroundColor: [
                    'rgba(255, 159, 64, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
    <?php endif; ?>
    
    // Auto-submit du formulaire lors du changement de section ou d'année académique
    document.getElementById('annee_acad').addEventListener('change', function() {
        this.form.submit();
    });
    
    if (document.getElementById('section')) {
        document.getElementById('section').addEventListener('change', function() {
            this.form.submit();
        });
    }
});</script>

<?php include "./views/include/footer.php"; ?>

