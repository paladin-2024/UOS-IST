<?php
include "./views/include/header.php";
$universite = new Universite();
$etudiantModel = new Etudiant();
$agentModel = new Agent();

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Récupérer les données nécessaires
$academicYears = $universite->getAcademicYears();
$specialisations = $universite->getAllSpecialisations();
$sujets = $universite->getSujets($search);
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>SUJETS DE RECHERCHE</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Sujets de Recherche</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-12">
                        <div class="card overflow-auto">

<div class="card-body">
    <h5 class="card-title">
        Liste des Sujets de Recherche
        <div class="float-end">
            <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#exportModal">
                <i class="bi bi-file-excel"></i> Exporter
            </button>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createSujetModal">
                <i class="bi bi-plus-circle"></i> Nouveau Sujet
            </button>
        </div>
    </h5>

    <form method="GET" action="" class="mb-3">
        <div class="input-group">
            <input type="hidden" name="view" value="recherche/affectation">
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher un sujet...">
            <button type="submit" class="btn btn-primary">Rechercher</button>
        </div>
    </form>

    <!-- Modal pour l'exportation -->
    <div class="modal fade" id="exportModal" tabindex="-1" role="dialog" aria-labelledby="exportModalLabel" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Exporter les Sujets de Recherche</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="controller/export_sujets.php">
                        <div class="mb-3">
                            <label for="annee_export" class="form-label">Sélectionner l'année académique</label>
                            <select name="annee_export" id="annee_export" class="form-control" required>
                                <option value="">Sélectionner une année académique</option>
                                <?php foreach ($academicYears as $year): ?>
                                    <option value="<?= $year['idannee_acad'] ?>"><?= $year['designation'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-success">
                                <i class="bi bi-file-excel"></i> Exporter
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Intitulé</th>
                <th scope="col">Cycle</th>
                <th scope="col">Spécialisation</th>
                <th scope="col">État</th>
                <th scope="col">Étudiant</th>
                <th scope="col">Directeur</th>
                <th scope="col">Encadreur</th>
                <th scope="col">Année</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $i = 1;
            foreach ($sujets as $sujet) {
                $intituleJS = htmlspecialchars(addslashes($sujet['intitule']), ENT_QUOTES);
                
                // Récupérer les informations de l'étudiant
                $etudiantInfo = '';
                if (!empty($sujet['etudiant_idetudiant'])) {
                    $etudiant = $etudiantModel->getEtudiantById($sujet['etudiant_idetudiant']);
                    $etudiantInfo = $etudiant ? htmlspecialchars($etudiant['noms']) . ' (' . htmlspecialchars($etudiant['matricule']) . ')' : '<span class="text-muted">Non assigné</span>';
                } else {
                    $etudiantInfo = '<span class="text-muted">Non assigné</span>';
                }
                
                // Récupérer les informations du directeur
                $directeurInfo = '';
                if (!empty($sujet['idDirecteur'])) {
                    $directeur = $agentModel->getAgentById($sujet['idDirecteur']);
                    $directeurInfo = $directeur ? htmlspecialchars($directeur['noms']) : '<span class="text-muted">Non assigné</span>';
                } else {
                    $directeurInfo = '<span class="text-muted">Non assigné</span>';
                }
                
                // Récupérer les informations de l'encadreur
                $encadreurInfo = '';
                if (!empty($sujet['idEncadreur'])) {
                    $encadreur = $agentModel->getAgentById($sujet['idEncadreur']);
                    $encadreurInfo = $encadreur ? htmlspecialchars($encadreur['noms']) : '<span class="text-muted">Non assigné</span>';
                } else {
                    $encadreurInfo = '<span class="text-muted">Non assigné</span>';
                }
                
                // Définir la classe de la cellule État selon le statut
                $etatClass = '';
                switch($sujet['statut_validation']) {
                    case 'En attente':
                        $etatClass = 'text-warning';
                        break;
                    case 'Validé':
                        $etatClass = 'text-success';
                        break;
                    case 'Rejeté':
                        $etatClass = 'text-danger';
                        break;
                }

                $etudiantId = !empty($sujet['etudiant_idetudiant']) ? $sujet['etudiant_idetudiant'] : 'null';
                $directeurId = !empty($sujet['idDirecteur']) ? $sujet['idDirecteur'] : 'null';
                $encadreurId = !empty($sujet['idEncadreur']) ? $sujet['idEncadreur'] : 'null';
                $etatSujet = htmlspecialchars(addslashes($sujet['statut_validation']), ENT_QUOTES);

                echo "<tr>
                    <td>{$i}</td>
                    <td>{$sujet['intitule']}</td>
                    <td>{$sujet['cycle']}</td>
                    <td>{$sujet['specialisation']}</td>
                    <td class='{$etatClass}'>{$sujet['statut_validation']}</td>
                    <td>{$etudiantInfo}</td>
                    <td>{$directeurInfo}</td>
                    <td>{$encadreurInfo}</td>
                    <td>{$sujet['annee']}</td>
                    <td>
                        <button class='btn btn-sm btn-primary' onclick='openEditSujetModal({$sujet['idsujets']}, 
                            \"{$intituleJS}\", 
                            \"{$sujet['cycle']}\", 
                            {$sujet['idSpecialisation']}, 
                            {$sujet['annee_acad_idannee_acad']},
                            {$etudiantId},
                            {$directeurId},
                            {$encadreurId},
                            \"{$etatSujet}\")'>
                            <i class='bi bi-pencil'></i>
                        </button>
                        <button class='btn btn-sm btn-danger' onclick='confirmDeleteSujet({$sujet['idsujets']})'>
                            <i class='bi bi-trash'></i>
                        </button>
                    </td>
                </tr>";
                $i++;
            }
            ?>
        </tbody>
    </table>
</div>
</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal Création Sujet -->
<div class="modal fade" id="createSujetModal" tabindex="-1" role="dialog" aria-labelledby="createSujetModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Nouveau Sujet de Recherche</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="createSujetForm" method="POST" action="controller/sujet_controller.php">
                    <input type="hidden" name="action" value="create">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="intitule" class="form-label">Intitulé du sujet</label>
                            <input type="text" class="form-control" id="intitule" name="intitule" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="cycle" class="form-label">Cycle</label>
                            <select class="form-select" id="cycle" name="cycle" required>
                                <option value="">Sélectionner un cycle</option>
                                <option value="Premier">Licence</option>
                                <option value="Deuxieme">Master</option>
                                <option value="Troisieme">Doctorat</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="idSpecialisation" class="form-label">Spécialisation</label>
                            <select class="form-select" id="idSpecialisation" name="idSpecialisation" required>
                                <option value="">Sélectionner une spécialisation</option>
                                <?php foreach ($specialisations as $specialisation): ?>
                                    <option value="<?= $specialisation['idSpecialisation'] ?>">
                                        <?= $specialisation['designation'] ?> (<?= $specialisation['unite_recherche'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="annee_acad" class="form-label">Année Académique</label>
                            <select class="form-select" id="annee_acad" name="annee_acad" required>
                                <option value="">Sélectionner une année</option>
                                <?php foreach ($academicYears as $year): ?>
                                    <option value="<?= $year['idannee_acad'] ?>"><?= $year['designation'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="etatSujet" class="form-label">État du sujet</label>
                            <select class="form-select" id="etatSujet" name="etatSujet">
                                <option value="En attente">En attente</option>
                                <option value="Validé">Validé</option>
                                <option value="Rejeté">Rejeté</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                    <div class="col-md-12">
                            <label for="etudiant" class="form-label">Étudiant</label>
                            <select class="form-select" id="etudiant" name="etudiant">
                                <option value="">Sélectionner un étudiant</option>
                                <?php 
                                $etudiants = $etudiantModel->getStudents2();
                                foreach ($etudiants as $etudiant): 
                                ?>
                                    <option value="<?= $etudiant['idetudiant'] ?>">
                                        <?= $etudiant['noms'] ?> (<?= $etudiant['matricule'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="directeur" class="form-label">Directeur</label>
                            <select class="form-select" id="directeur" name="directeur">
                                <option value="">Sélectionner un directeur</option>
                                <?php 
                                $enseignants = $agentModel->getAgentsByType('Enseignant');
                                foreach ($enseignants as $enseignant): 
                                ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= $enseignant['gradeDesignation'] ? $enseignant['gradeDesignation'] . ' ' : '' ?><?= $enseignant['noms'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="encadreur" class="form-label">Encadreur</label>
                            <select class="form-select" id="encadreur" name="encadreur">
                                <option value="">Sélectionner un encadreur</option>
                                <?php foreach ($enseignants as $enseignant): ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= $enseignant['gradeDesignation'] ? $enseignant['gradeDesignation'] . ' ' : '' ?><?= $enseignant['noms'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Modification Sujet -->
<div class="modal fade" id="editSujetModal" tabindex="-1" role="dialog" aria-labelledby="editSujetModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier le Sujet de Recherche</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editSujetForm" method="POST" action="controller/sujet_controller.php">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="idsujets" id="edit_idsujets">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_intitule" class="form-label">Intitulé du sujet</label>
                            <input type="text" class="form-control" id="edit_intitule" name="intitule" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_cycle" class="form-label">Cycle</label>
                            <select class="form-select" id="edit_cycle" name="cycle" required>
                                <option value="">Sélectionner un cycle</option>
                                <option value="Premier">Licence</option>
                                <option value="Deuxieme">Master</option>
                                <option value="Troisieme">Doctorat</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_idSpecialisation" class="form-label">Spécialisation</label>
                            <select class="form-select" id="edit_idSpecialisation" name="idSpecialisation" required>
                                <option value="">Sélectionner une spécialisation</option>
                                <?php foreach ($specialisations as $specialisation): ?>
                                    <option value="<?= $specialisation['idSpecialisation'] ?>">
                                        <?= $specialisation['designation'] ?> (<?= $specialisation['unite_recherche'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_annee_acad" class="form-label">Année Académique</label>
                            <select class="form-select" id="edit_annee_acad" name="annee_acad" required>
                                <option value="">Sélectionner une année</option>
                                <?php foreach ($academicYears as $year): ?>
                                    <option value="<?= $year['idannee_acad'] ?>"><?= $year['designation'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_etatSujet" class="form-label">État du sujet</label>
                            <select class="form-select" id="edit_etatSujet" name="etatSujet">
                                <option value="En attente">En attente</option>
                                <option value="Validé">Validé</option>
                                <option value="Rejeté">Rejeté</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_etudiant" class="form-label">Étudiant</label>
                            <select class="form-select" id="edit_etudiant" name="etudiant">
                                <option value="">Sélectionner un étudiant</option>
                                <?php foreach ($etudiants as $etudiant): ?>
                                    <option value="<?= $etudiant['idetudiant'] ?>">
                                        <?= $etudiant['noms'] ?> (<?= $etudiant['matricule'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_directeur" class="form-label">Directeur</label>
                            <select class="form-select" id="edit_directeur" name="directeur">
                                <option value="">Sélectionner un directeur</option>
                                <?php foreach ($enseignants as $enseignant): ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= $enseignant['gradeDesignation'] ? $enseignant['gradeDesignation'] . ' ' : '' ?><?= $enseignant['noms'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_encadreur" class="form-label">Encadreur</label>
                            <select class="form-select" id="edit_encadreur" name="encadreur">
                                <option value="">Sélectionner un encadreur</option>
                                <?php foreach ($enseignants as $enseignant): ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= $enseignant['gradeDesignation'] ? $enseignant['gradeDesignation'] . ' ' : '' ?><?= $enseignant['noms'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function openEditSujetModal(id, intitule, cycle, idSpecialisation, anneeAcad, etudiantId, directeurId, encadreurId, etatSujet) {
    // Remplir les champs du formulaire
    document.getElementById('edit_idsujets').value = id;
    document.getElementById('edit_intitule').value = intitule;
    document.getElementById('edit_cycle').value = cycle;
    document.getElementById('edit_idSpecialisation').value = idSpecialisation;
    document.getElementById('edit_annee_acad').value = anneeAcad;
    document.getElementById('edit_etatSujet').value = etatSujet;

    // Gérer les champs qui peuvent être null
    if (etudiantId && etudiantId !== 'null') {
        document.getElementById('edit_etudiant').value = etudiantId;
    } else {
        document.getElementById('edit_etudiant').value = '';
    }

    if (directeurId && directeurId !== 'null') {
        document.getElementById('edit_directeur').value = directeurId;
    } else {
        document.getElementById('edit_directeur').value = '';
    }

    if (encadreurId && encadreurId !== 'null') {
        document.getElementById('edit_encadreur').value = encadreurId;
    } else {
        document.getElementById('edit_encadreur').value = '';
    }

    // Si vous utilisez Select2, vous devez déclencher un événement change
    // pour mettre à jour l'affichage des select
    $('#edit_etudiant').trigger('change');
    $('#edit_directeur').trigger('change');
    $('#edit_encadreur').trigger('change');
    
    // Afficher le modal
    var editModal = new bootstrap.Modal(document.getElementById('editSujetModal'));
    editModal.show();
}

function confirmDeleteSujet(id) {
    Swal.fire({
        title: 'Êtes-vous sûr ?',
        text: "Cette action est irréversible !",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, supprimer !',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            // Créer un formulaire dynamique pour envoyer l'action en POST
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'controller/sujet_controller.php';

            // Champ caché pour l'action
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';

            // Champ caché pour l'ID
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'idsujets';
            idInput.value = id;

            // Ajouter les champs au formulaire
            form.appendChild(actionInput);
            form.appendChild(idInput);

            // Ajouter le formulaire au document et le soumettre
            document.body.appendChild(form);
            form.submit();
        }
    });
}

// Initialisation des select2 pour une meilleure expérience utilisateur
$(document).ready(function() {
    $('.form-select').select2({
        theme: 'bootstrap-5',
        width: '100%'
    });
});
</script>

<?php include "./views/include/footer_file.php"; ?>

