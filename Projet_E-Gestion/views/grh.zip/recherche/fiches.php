<?php
include "./views/include/header.php";
$universite = new Universite();
$enseignantModel = new Enseignant();

$search = isset($_GET['search']) ? $_GET['search'] : '';
$userId = $_SESSION['id'];

// Récupérer les étudiants avec leurs sujets validés
$etudiants = $enseignantModel->getEtudiantsAvecSujetsValides($search);

// Organiser les données avec les méthodes de la classe Enseignant
$etudiantsSujets = [];
foreach ($etudiants as $etudiant) {
    $etudiantId = $etudiant['idetudiant'];
    if (!isset($etudiantsSujets[$etudiantId])) {
        // Utiliser la méthode getDetailsEtudiantAvecSujets pour obtenir toutes les informations
        $detailsEtudiant = $enseignantModel->getDetailsEtudiantAvecSujets($etudiantId);
        if ($detailsEtudiant) {
            $etudiantsSujets[$etudiantId] = $detailsEtudiant;
        }
    }
}
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Suivi des Étudiants</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Accueil</a></li>
                <li class="breadcrumb-item active">Suivi des étudiants</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            Fiches d'avancement des étudiants
                            <div class="float-end">
                                <button type="button" class="btn btn-success me-2" data-bs-toggle="modal" data-bs-target="#exportModal">
                                    <i class="bi bi-file-excel"></i> Exporter
                                </button>
                            </div>
                        </h5>

                        <!-- Recherche -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <form action="" method="GET" class="d-flex">
                                    <input type="hidden" name="view" value="recherche/fiches">
                                    <input type="text" name="search" class="form-control me-2" 
                                           placeholder="Rechercher un étudiant..." 
                                           value="<?= htmlspecialchars($search) ?>">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <!-- Liste des étudiants -->
                        <div class="accordion" id="accordionEtudiants">
                            <?php 
                            $numeroEtudiant = 1;
                            foreach ($etudiantsSujets as $etudiantId => $etudiant): 
                                // Calculer la progression globale à partir des sujets
                                $rapport = $enseignantModel->genererRapportProgressionEtudiant($etudiantId);
                                $progression = $rapport ? $rapport['pourcentage_global'] : 0;
                            ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target="#collapse<?= $etudiantId ?>">
                                            <div class="d-flex justify-content-between align-items-center w-100 me-3">
                                                <div>
                                                    <span class="badge bg-secondary me-2"><?= $numeroEtudiant ?></span>
                                                    <strong><?= $etudiant['noms'] ?></strong>
                                                    <span class="text-muted ms-2"><?= $etudiant['matricule'] ?></span>
                                                </div>
                                                <div>
                                                    <span class="badge bg-primary me-2"><?= $etudiant['promotion'] ?></span>
                                                    <div class="progress" style="width: 150px; height: 20px;">
                                                        <div class="progress-bar" role="progressbar" 
                                                             style="width: <?= $progression ?>%;" 
                                                             aria-valuenow="<?= $progression ?>" 
                                                             aria-valuemin="0" 
                                                             aria-valuemax="100">
                                                            <?= $progression ?>%
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </button>
                                    </h2>

                                    <div id="collapse<?= $etudiantId ?>" class="accordion-collapse collapse" 
                                         data-bs-parent="#accordionEtudiants">
                                        <div class="accordion-body">
                                            <!-- Informations de l'étudiant -->
                                            <div class="row mb-4">
                                                <div class="col-md-6">
                                                    <h6 class="fw-bold">Informations de l'étudiant</h6>
                                                    <p><strong>Promotion:</strong> <?= $etudiant['promotion'] ?></p>
                                                    <p><strong>Département:</strong> <?= $etudiant['departement'] ?></p>
                                                    <p><strong>Année académique:</strong> <?= $etudiant['annee_academique'] ?></p>
                                                </div>
                                                <div class="col-md-6 text-end">
                                                    <button class="btn btn-primary btn-sm" 
                                                            onclick="exportFicheAvancement(<?= $etudiantId ?>)">
                                                        <i class="bi bi-file-pdf"></i> 
                                                        Exporter la fiche d'avancement
                                                    </button>
                                                </div>
                                            </div>

                                            <!-- Liste des sujets et leurs tâches -->
                                            <?php foreach ($etudiant['sujets'] as $sujet):
                                                // Utiliser la méthode getTachesBySujet pour récupérer les tâches
                                                $taches = $enseignantModel->getTachesBySujet($sujet['idsujets']);
                                            ?>
                                                <div class="card mb-4">
                                                    <div class="card-header">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <h6 class="mb-0">
                                                                <?= htmlspecialchars($sujet['intitule']) ?>
                                                            </h6>
                                                            <div>
                                                                <span class="badge bg-primary me-2" title="Directeur">
                                                                    <i class="bi bi-person-check"></i> 
                                                                    <?= htmlspecialchars($sujet['directeur']) ?>
                                                                    <?php if (isset($sujet['grade_directeur'])): ?>
                                                                        (<?= htmlspecialchars($sujet['grade_directeur']) ?>)
                                                                    <?php endif; ?>
                                                                </span>
                                                                <?php if (!empty($sujet['encadreur'])): ?>
                                                                    <span class="badge bg-success" title="Encadreur">
                                                                        <i class="bi bi-person-check"></i> 
                                                                        <?= htmlspecialchars($sujet['encadreur']) ?>
                                                                        <?php if (isset($sujet['grade_encadreur'])): ?>
                                                                            (<?= htmlspecialchars($sujet['grade_encadreur']) ?>)
                                                                        <?php endif; ?>
                                                                    </span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-body">
                                                        <!-- Statistiques de progression du sujet -->
                                                        <?php 
                                                        $progression = $enseignantModel->calculerProgressionSujet($sujet['idsujets']);
                                                        $pourcentage = $progression['pourcentage_global'];
                                                        ?>
                                                        <div class="mb-3">
                                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                                <h6>Progression globale</h6>
                                                                <span><?= $pourcentage ?>%</span>
                                                            </div>
                                                            <div class="progress">
                                                                <div class="progress-bar" role="progressbar" 
                                                                    style="width: <?= $pourcentage ?>%;" 
                                                                    aria-valuenow="<?= $pourcentage ?>" 
                                                                    aria-valuemin="0" 
                                                                    aria-valuemax="100">
                                                                </div>
                                                            </div>
                                                            <div class="d-flex justify-content-between mt-2 text-muted small">
                                                                <span>Tâches: <?= $progression['total_taches'] ?></span>
                                                                <span>Validées: <?= $progression['taches_validees'] ?></span>
                                                                <span>En cours: <?= $progression['taches_en_cours'] ?></span>
                                                                <span>En attente: <?= $progression['taches_en_attente'] ?></span>
                                                            </div>
                                                        </div>

                                                        <!-- Timeline des tâches -->
                                                        <div class="timeline">
                                                            <?php foreach ($taches as $tache): 
                                                                // Utiliser la méthode getEchangesByTache pour récupérer les échanges
                                                                $echanges = $enseignantModel->getEchangesByTache($tache['idtaches']);
                                                            ?>
                                                                <div class="timeline-item">
                                                                    <div class="timeline-marker <?= getBadgeClass($tache['validation']) ?>"></div>
                                                                    <div class="timeline-content">
                                                                        <div class="d-flex justify-content-between align-items-center">
                                                                            <h6><?= htmlspecialchars($tache['description']) ?></h6>
                                                                            <span class="badge <?= getBadgeClass($tache['validation']) ?>">
                                                                                <?= $tache['validation'] ?>
                                                                            </span>
                                                                        </div>
                                                                        <small class="text-muted">
                                                                            <?= date('d/m/Y', strtotime($tache['dateTache'])) ?>
                                                                            <?php if (isset($tache['pourcentage_avancement'])): ?>
                                                                                - Avancement: <?= $tache['pourcentage_avancement'] ?>%
                                                                            <?php endif; ?>
                                                                        </small>
                                                                        
                                                                        <!-- Échanges -->
                                                                        <?php if (!empty($echanges)): ?>
                                                                            <div class="mt-3">
                                                                                <h6 class="text-muted">Échanges (<?= count($echanges) ?>)</h6>
                                                                                <?php foreach ($echanges as $echange): ?>
                                                                                    <div class="chat-message <?= $echange['type_auteur'] === 'Etudiant' ? 'student' : 'teacher' ?>">
                                                                                        <div class="message-content">
                                                                                            <small class="text-muted">
                                                                                                <?= $echange['nom_auteur'] ?> - 
                                                                                                <?= date('d/m/Y H:i', strtotime($echange['dateEchange'])) ?>
                                                                                            </small>
                                                                                            <p><?= nl2br(htmlspecialchars($echange['commentaire'])) ?></p>
                                                                                            <?php if (isset($echange['fichierJoint']) && $echange['fichierJoint']): ?>
                                                                                                <a href="uploads/<?= $echange['fichierJoint'] ?>" 
                                                                                                   class="btn btn-sm btn-outline-secondary" 
                                                                                                   target="_blank">
                                                                                                    <i class="bi bi-file-earmark"></i> 
                                                                                                    Voir le fichier
                                                                                                </a>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endforeach; ?>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php 
                         $numeroEtudiant++;
                        endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Modal d'exportation -->
    <div class="modal fade" id="exportModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Exporter les fiches d'avancement</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="exportForm" action="controller/export_avancement.php" method="POST">
                        <div class="mb-3">
                            <label for="annee_acad" class="form-label">Année Académique</label>
                            <select class="form-select" id="annee_acad" name="annee_acad" required>
                                <option value="">Sélectionner une année</option>
                                <?php 
                                $annees = $universite->getAcademicYears();
                                foreach ($annees as $annee): 
                                ?>
                                                                        <option value="<?= $annee['idannee_acad'] ?>">
                                        <?= $annee['designation'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="format" class="form-label">Format d'exportation</label>
                            <select class="form-select" id="format" name="format" required>
                                <option value="excel">Excel</option>
                                <option value="pdf">PDF</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="include_echanges" name="include_echanges" value="1">
                                <label class="form-check-label" for="include_echanges">
                                    Inclure les échanges
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    <button type="submit" form="exportForm" class="btn btn-success">
                        <i class="bi bi-file-excel"></i> Exporter
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
.timeline {
    position: relative;
    padding: 20px 0;
    list-style: none;
    max-width: 100%;
}

.timeline:before {
    content: " ";
    position: absolute;
    top: 0;
    bottom: 0;
    left: 20px;
    width: 3px;
    background-color: #e9ecef;
}

.timeline-item {
    position: relative;
    margin-bottom: 25px;
    display: flex;
}

.timeline-marker {
    position: absolute;
    left: 15px;
    width: 15px;
    height: 15px;
    border-radius: 50%;
    transform: translateX(-50%);
    z-index: 1;
}

.timeline-content {
    padding-left: 40px;
    width: 100%;
}

.chat-message {
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 4px;
}

.chat-message.student {
    background-color: #f8f9fa;
    margin-right: 20%;
}

.chat-message.teacher {
    background-color: #e3f2fd;
    margin-left: 20%;
}

.progress {
    background-color: #e9ecef;
    border-radius: 10px;
}

.progress-bar {
    background-color: #0d6efd;
    border-radius: 10px;
}
</style>

<?php

function getBadgeClass($validation) {
    switch ($validation) {
        case 'Validé':
            return 'bg-success';
        case 'En cours':
            return 'bg-warning';
        case 'Rejeté':
            return 'bg-danger';
        case 'En attente':
        default:
            return 'bg-secondary';
    }
}

?>

<script>
function exportFicheAvancement(etudiantId) {
    window.location.href = `controller/export_fiche_avancement.php?etudiant_id=${etudiantId}`;
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les tooltips Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Ajouter une animation lors de l'ouverture des accordéons
    const accordionButtons = document.querySelectorAll('.accordion-button');
    accordionButtons.forEach(button => {
        button.addEventListener('click', function() {
            const content = this.nextElementSibling;
            if (content.classList.contains('show')) {
                content.style.maxHeight = '0px';
            } else {
                content.style.maxHeight = content.scrollHeight + 'px';
            }
        });
    });
});
</script>

<?php include "./views/include/footer_file.php"; ?>

