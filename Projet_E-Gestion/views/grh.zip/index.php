<?php
include "./views/include/header.php";
$structure = new Structure();
$superUser = new SuperUser();

// Vérifier si c'est la première connexion de l'utilisateur
if ($superUser->isFirstLogin($_SESSION['id'])) {
    // Rediriger vers la page de changement de mot de passe
    echo "<meta http-equiv='refresh' content='0;URL=password'>";
    exit();
}

// Get statistics
$statistics = $structure->getStatistics();
?>

<!-- Espace de travail -->
<main id="main" class="main">

    <div class="pagetitle">
        <h1>E-GESTION</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?= mb_strtoupper($nomRole) ?></a></li>
                <li class="breadcrumb-item active">Accueil</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Bienvenu -->
            <div class="col-md-12">
                <div class="card info-card">
                    <div class="card-body">
                        <h5 class="card-title">Bonjour, <strong><?= mb_strtoupper($nomU) ?></strong> <i class="bi bi-emoji-smile-fill"></i></h5>
                        <p class="card-text">Bienvenu dans votre session de travail.</p>
                    </div>
                </div>
            </div><!-- End Bienvenue -->

            <div class="col-lg-12">
                <div class="row">
                    <!-- Statistique 1 -->
                    <div class="col-md-3">
                        <div class="card info-card">
                            <div class="card-body">
                                <h5 class="card-title">Utilisateurs</h5>
                                <div class="d-flex align-items-center">
                                    <div class="icon text-primary"><i class="bi bi-people"></i></div>
                                    <div class="ps-3">
                                        <h6>+<?php echo htmlspecialchars($statistics['users']); ?></h6>
                                        <span class="text-success small">Utilisateurs</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Statistique 1 -->

                    <!-- Statistique 2 -->
                    <div class="col-md-3">
                        <div class="card info-card">
                            <div class="card-body">
                                <h5 class="card-title">Campus</h5>
                                <div class="d-flex align-items-center">
                                    <div class="icon text-success"><i class="bi bi-file-earmark-check"></i></div>
                                    <div class="ps-3">
                                        <h6>+<?php echo htmlspecialchars($statistics['structures']); ?></h6>
                                        <span class="text-success small">Campus</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Statistique 2 -->

                    <!-- Statistique 3 -->
                    <div class="col-md-3">
                        <div class="card info-card">
                            <div class="card-body">
                                <h5 class="card-title">Personnels Actifs</h5>
                                <div class="d-flex align-items-center">
                                    <div class="icon text-warning"><i class="bi bi-person-check"></i></div>
                                    <div class="ps-3">
                                        <h6>+<?php echo htmlspecialchars($statistics['active_personnel']); ?></h6>
                                        <span class="text-warning small">Personnels Actifs</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Statistique 3 -->

                    <!-- Statistique 4 -->
                    <div class="col-md-3">
                        <div class="card info-card">
                            <div class="card-body">
                                <h5 class="card-title">Fonctionnalités</h5>
                                <div class="d-flex align-items-center">
                                    <div class="icon text-warning"><i class="bi bi-window-stack"></i></div>
                                    <div class="ps-3">
                                        <h6>+<?php echo htmlspecialchars($statistics['permissions']); ?></h6>
                                        <span class="text-warning small">Permissions</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- End Statistique 4 -->
                </div>
            </div><!-- End Statistiques rapides -->

            <!-- Section à propos -->
            <div class="col-lg-12 mt-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">À propos de E-GESTION</h5>
                        <p>
                            E-GESTION est un progiciel de gestion générique conçu pour s'adapter à tout type d'organisation, offrant une gestion optimisée des processus administratifs, financiers et logistiques. Notre plateforme allie efficacité et simplicité pour répondre aux besoins variés des professionnels de différents secteurs.
                        </p>
                        <p>
                            Avec E-GESTION, vous pouvez gérer l'ensemble de vos opérations avec des outils avancés, tels que :
                        </p>
                        <ul>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion du Personnel :</strong> Suivi des ressources humaines, gestion des affectations et des horaires de travail.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion Financière :</strong> Gestion des budgets, suivi des dépenses, rapports financiers détaillés et prévisions.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion Logistique :</strong> Optimisation des achats, gestion des équipements, et suivi des livraisons.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion de Stock :</strong> Contrôle de l'inventaire, gestion des commandes et des stocks de produits.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion de la Production :</strong> Suivi des processus de production et gestion des ressources nécessaires.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Gestion des Documents :</strong> Archivage électronique sécurisé des documents administratifs et financiers.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Demande de Correction :</strong> Système de demande de modification et de correction des données en temps réel.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Tableau de Contrôle :</strong> Visualisation en temps réel des indicateurs clés de performance (KPI), alertes, et graphiques de suivi.</li>
                            <li><i class="bi bi-check-circle-fill text-success me-2"></i><strong>Statistiques :</strong> Génération de rapports détaillés, d'analyses statistiques et de prévisions pour une prise de décision éclairée.</li>
                        </ul>
                        <p>
                            Notre objectif est d’offrir une plateforme complète et flexible, capable de s’adapter à l’évolution de vos besoins, afin de garantir une gestion optimale de vos opérations.
                        </p>
                        <p>
                            En intégrant E-GESTION à vos processus, vous bénéficiez non seulement d'une solution robuste, mais aussi d'une équipe dédiée à l'amélioration continue de votre expérience utilisateur.
                        </p>
                    </div>
                </div>
            </div><!-- End Section à propos -->

        </div>
    </section>
</main><!-- End #main -->

<?php include "./views/include/footer.php"; ?>