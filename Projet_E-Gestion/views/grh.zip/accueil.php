<!DOCTYPE html>
<html lang="fr">

<?php
require_once 'config/config.php';
$universite = new Universite();

$configUniversite = $universite->getConfigurationUniversite();
?>
<head>
	<meta charset="UTF-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">

	<title>E-GESTION</title>
	<meta content="E-GESTION est une solution innovante conçue pour la gestion des entreprises et écoles, permettant une gestion optimisée des processus administratifs, financiers et logistiques. Notre plateforme allie efficacité et simplicité pour répondre aux besoins des professionnels du secteur" name="description">
	<meta content="E-GESTION" name="keywords">

	<?php if (!empty($configUniversite['logo'])): ?>
        <!-- Favicons --> 
	<link href="./<?= htmlspecialchars($configUniversite['logo']) ?>" rel="icon">
	<link href="./<?= htmlspecialchars($configUniversite['logo']) ?>" rel="apple-touch-icon">
    <?php endif; ?>

	<!-- Vendor CSS Files -->
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/vendor/icon_bootstrap/bootstrap-icons.css" rel="stylesheet">
	<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
	<link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
	<link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
	<link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
	<link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
	<link href="assets/js/select2.min.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/vendor/spinners/ladda-themeless.min.css">
	<link rel="stylesheet" href="assets/vendor/select2/select2.min.css">
	<link rel="stylesheet" href="assets/vendor/select2-bootstrap-theme/select2-bootstrap.min.css">

	<!-- Initialisation de la configuration -->
	<script>
        const APP_CONFIG = <?php echo json_encode(AppConfig::getJsConfig()); ?>;
    </script>

	<script src="assets/js/DataLoader.js"></script>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>

	<link href="assets/DataTables/datatables.min.css" rel="stylesheet">
 
	<script src="assets/DataTables/datatables.min.js"></script>

	

	<!-- Template Main CSS File -->
	<link href="assets/css/style.css" rel="stylesheet">
	<style>
		/* Style du conteneur de préchargement */
		#preloader {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(255, 255, 255, 0.8); /* Fond blanc semi-transparent */
			z-index: 9999; /* Toujours au-dessus */
			display: flex;
			justify-content: center;
			align-items: center;
		}

		/* Style du spinner */
		.spinner {
			width: 50px;
			height: 50px;
			border: 5px solid #f3f3f3; /* Couleur de l'anneau externe */
			border-top: 5px solid #007bff; /* Couleur de l'anneau supérieur */
			border-radius: 50%;
			animation: spin 1s linear infinite; /* Animation de rotation */
		}

		/* Animation de rotation */
		@keyframes spin {
			0% {
				transform: rotate(0deg);
			}
			100% {
				transform: rotate(360deg);
			}
		}
	</style>
</head>
<div id="preloader">
    <div class="spinner"></div>
</div>


<body>

  <!-- principal -->
  <main>
    <div class="back">

      <div class="container">

        <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">

          <div class="container">
            <div class="row justify-content-center">
              <div class="col-lg-5 col-md-5 d-flex flex-column align-items-center justify-content-center">
                <div class="card">
                  <div class="card-body">
                    <div class="pt-4">
                      <div class="text-center">
						<?php
							if (!empty($configUniversite['logo'])) {
								$logoPath = './' . $configUniversite['logo'];
								if (file_exists($logoPath)) {
									$logoData = base64_encode(file_get_contents($logoPath));
									$logoMime = mime_content_type($logoPath);
									echo '<img src="'.$logoPath.'" alt="Logo" width="80" height="120">';
								}else{
									echo 'Configurer le logo une fois connecté';
								}
							}
						?>
                      </div>
                      <h4 class="card-title pb-0 fs-4">E-GESTION</h4>
                      <h6 class="font-weight-light">Connectez-vous pour continuer</h6>
                    </div>

                    <form method="post" action="controller/loginAdmin.php" class="row g-3 needs-validation ladda-form" novalidate>
                      

                      <div class="col-12 loginUtilisateur">
                        <label for="yourUsername" class="form-label">Login</label>
                        <div class="input-group has-validation">
                          <span class="input-group-text" id="inputGroupPrepend"><i class="bi bi-key"></i></span>
                          <input type="text" name="login" class="form-control" id="yourUsername" required>
                          <div class="invalid-feedback">Veillez saisir votre Login SVP !</div>
                        </div>
                      </div>

                      <div class="col-12">
                        <label for="yourPassword" class="form-label">Password</label>
                        <div class="input-group has-validation">
                          <span class="input-group-text"><i class="bi bi-lock"></i></span>
                          <input type="password" name="pwd" class="form-control" id="yourPassword" required>

                          <div class="invalid-feedback">Veillez saisir votre Password SVP !</div>

                        </div>
                      </div>

                      <div class="col-12">
                        <div class="form-check iconePass">
                          <input class="form-check-input" type="checkbox" onclick="changer()" name="remember" id="rememberMe">
                          <label class="form-check-label" for="rememberMe">Afficher mot de passe</label>
                        </div>
                      </div>

                      <div class="col-12 text-center">
                        <button type="submit" name="con" class="btnModSaveLogin ladda-button" data-style="zoom-out">
                          <i class="bi bi-box-arrow-in-right"></i> SE CONNECTER
                        </button>
                      </div>
                    </form>

                  </div>

                </div>
              </div>

            </div>
          </div>

        </section>

      </div>
    </div>

  </main><!-- End #main -->

  <!-- Footer et importation JavaScript -->
  <?php include("include/footer_2.php"); ?>

</body>

</html>