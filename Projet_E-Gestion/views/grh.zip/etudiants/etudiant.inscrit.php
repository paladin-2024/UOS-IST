<?php
include "./views/include/header.php";
$universite = new Universite();

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Function to generate the next matricule
function generateNextMatricule($universite) {
    $students = $universite->getStudents2();
    $count = count($students) + 1; // Get the next order number
    $prefix = "ET-A";
    $matricule = $prefix . str_pad($count, 8, '0', STR_PAD_LEFT);
    return $matricule;
}

$nextMatricule = generateNextMatricule($universite);

// Récupérer toutes les orientations pour les formulaires
$orientations = $universite->getOrientations();
?>
<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>ÉTUDIANTS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Étudiants</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table students -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Gestion des étudiants
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createStudentModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter
                                        </a>
                                        | <a data-bs-toggle="modal" data-bs-target="#importStudentModal" class="btnPage">
                                            <i class="bi bi-file-earmark-excel-fill"></i> Importer
                                        </a>
                                        | <a data-bs-toggle="modal" data-bs-target="#exportStudentModal" class="btnPage">
                                            <i class="bi bi-file-earmark-excel-fill"></i> Exporter
                                        </a>
                                    </span>
                                </h5>

                                <iframe id="downloadFrame" name="downloadFrame" style="display:none;"></iframe>

                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="etudiants/etudiant.inscrit">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par nom...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Matricule</th>
                                            <th scope="col">Noms</th>
                                            <th scope="col">Promotion</th>
                                            <th scope="col">Année</th>
                                            <th scope="col">Téléphone</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $listeEtudiants = $universite->getStudents($search);
                                        $i = 1;

                                        foreach ($listeEtudiants as $etudiant){
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$etudiant['matricule']}</td>
                                                <td>{$etudiant['noms']}</td>
                                                <td>{$etudiant['designationPromotion']}</td>
                                                <td>{$etudiant['annee']}</td>
                                                <td>{$etudiant['telephone']}</td>
                                                
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editStudent(
                                                        {$etudiant['idetudiant']}, 
                                                        \"{$etudiant['matricule']}\",
                                                        \"{$etudiant['noms']}\",
                                                        \"{$etudiant['lieuNaissance']}\",
                                                        \"{$etudiant['dateNaissance']}\",
                                                        \"{$etudiant['adressemail']}\",
                                                        \"{$etudiant['telephone']}\",
                                                        \"{$etudiant['sexe']}\",
                                                        \"{$etudiant['nationalite']}\",
                                                        \"{$etudiant['annee_acad_idannee_acad']}\",
                                                        \"{$etudiant['promotion_idpromotion']}\"
                                                    )'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDelete({$etudiant['idetudiant']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour ajouter un étudiant -->
<div class="modal fade" id="createStudentModal" tabindex="-1" role="dialog" aria-labelledby="createStudentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un Étudiant</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="studentForm" method="POST" action="controller/create_etudiant.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                    <div class="col-md-6">
                            <label for="matricule" class="form-label">Matricule <span class="text-danger">*</span></label>
                            <input type="text" name="matricule" class="form-control" value="<?= $nextMatricule ?>">
                            <div class="invalid-feedback">Veuillez saisir un matricule.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="noms" class="form-label">Nom <span class="text-danger">*</span></label>
                            <input type="text" name="noms" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir un nom.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="lieuNaissance" class="form-label">Lieu de Naissance</label>
                            <input type="text" name="lieuNaissance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="dateNaissance" class="form-label">Date de Naissance</label>
                            <input type="date" name="dateNaissance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="adressemail" class="form-label">Email</label>
                            <input type="email" name="adressemail" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="telephone" class="form-label">Téléphone</label>
                            <input type="text" name="telephone" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="sexe" class="form-label">Sexe <span class="text-danger">*</span></label>
                            <select name="sexe" class="form-control" required>
                                <option value="Masculin">Masculin</option>
                                <option value="Feminin">Féminin</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner le sexe.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="nationalite" class="form-label">Nationalité <span class="text-danger">*</span></label>
                            <input type="text" name="nationalite" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir la nationalité.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="orientationId" class="form-label">Orientation <span class="text-danger">*</span></label>
                            <select id="orientationId" class="form-control" required>
                                <option value="">Sélectionner une orientation</option>
                                <?php
                                foreach ($orientations as $orientation) {
                                    echo "<option value='{$orientation['idorientation']}'>{$orientation['designationOrientation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une orientation.</div>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="promotionId" class="form-label">Promotion <span class="text-danger">*</span></label>
                            <select name="promotionId" id="promotionId" class="form-control" required>
                                <option value="">Sélectionner d'abord une orientation</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addStudentBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal for exporting students by promotion -->
<div class="modal fade" id="exportStudentModal" tabindex="-1" role="dialog" aria-labelledby="exportStudentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Exporter les Étudiants par Promotion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form  id="downloadForm" method="POST" action="controller/export_etudiants.php" class="needs-validation" target="downloadFrame">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="exportPromotionId" class="form-label">Promotion <span class="text-danger">*</span></label>
                            <select name="promotionId" id="exportPromotionId" class="form-control" required>
                                <!-- Populate with promotions -->
                                <?php
                                $promotions = $universite->getPromotions();
                                foreach ($promotions as $promotion) {
                                    echo "<option value='{$promotion['idpromotion']}'>{$promotion['designationPromotion']} - {$promotion['anneeDesignation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="exportStudentBtn" class="btn btn-primary">
                            <i class="bi bi-download"></i> Exporter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour importer des étudiants -->
<div class="modal fade" id="importStudentModal" tabindex="-1" role="dialog" aria-labelledby="importStudentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des Étudiants</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/import_etudiant.php" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="importFile" class="form-label">Fichier Excel <span class="text-danger">*</span></label>
                            <input type="file" name="importFile" class="form-control" accept=".xls,.xlsx" required>
                            <div class="invalid-feedback">Veuillez sélectionner un fichier Excel.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="importIdAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="importIdAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="importPromotionId" class="form-label">Promotion <span class="text-danger">*</span></label>
                            <select name="importPromotionId" class="form-control" required>
                                <!-- Populate with promotions -->
                                <?php
                                $promotions = $universite->getPromotions();
                                foreach ($promotions as $promotion) {
                                    echo "<option value='{$promotion['idpromotion']}'>{$promotion['designationPromotion']} - {$promotion['anneeDesignation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="startRow" class="form-label">Ligne de départ <span class="text-danger">*</span></label>
                            <input type="number" name="startRow" class="form-control" min="1" required>
                            <div class="invalid-feedback">Veuillez indiquer la ligne de départ.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="matriculeColumn" class="form-label">Colonne Matricule</label>
                            <input type="number" name="matriculeColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="nomsColumn" class="form-label">Colonne Noms <span class="text-danger">*</span></label>
                            <input type="number" name="nomsColumn" class="form-control" min="1" required>
                            <div class="invalid-feedback">Veuillez indiquer la colonne des noms.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="lieuNaissanceColumn" class="form-label">Colonne Lieu de Naissance</label>
                            <input type="number" name="lieuNaissanceColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="dateNaissanceColumn" class="form-label">Colonne Date de Naissance</label>
                            <input type="number" name="dateNaissanceColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="adressemailColumn" class="form-label">Colonne Email</label>
                            <input type="number" name="adressemailColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="telephoneColumn" class="form-label">Colonne Téléphone</label>
                            <input type="number" name="telephoneColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="sexeColumn" class="form-label">Colonne Sexe</label>
                            <input type="number" name="sexeColumn" class="form-control" min="1">
                        </div>
                        <div class="col-md-6">
                            <label for="nationaliteColumn" class="form-label">Colonne Nationalité</label>
                            <input type="number" name="nationaliteColumn" class="form-control" min="1">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="importStudentBtn" class="btn btn-primary">
                            <i class="bi bi-upload"></i> Importer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier un étudiant -->
<div class="modal fade" id="editStudentModal" tabindex="-1" role="dialog" aria-labelledby="editStudentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un Étudiant</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editStudentForm" method="POST" action="controller/update_etudiant.php" class="needs-validation" novalidate>
                    <input type="hidden" id="editStudentId" name="id">
                    <div class="row mb-3">
                    <div class="col-md-6">
                            <label for="editMatricule" class="form-label">Matricule <span class="text-danger">*</span></label>
                            <input type="text" id="editMatricule" name="matricule" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir un matricule.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="editNoms" class="form-label">Nom <span class="text-danger">*</span></label>
                            <input type="text" id="editNoms" name="noms" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir un nom.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="editLieuNaissance" class="form-label">Lieu de Naissance</label>
                            <input type="text" id="editLieuNaissance" name="lieuNaissance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="editDateNaissance" class="form-label">Date de Naissance</label>
                            <input type="date" id="editDateNaissance" name="dateNaissance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="editAdressemail" class="form-label">Email</label>
                            <input type="email" id="editAdressemail" name="adressemail" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="editTelephone" class="form-label">Téléphone</label>
                            <input type="text" id="editTelephone" name="telephone" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="editSexe" class="form-label">Sexe <span class="text-danger">*</span></label>
                            <select id="editSexe" name="sexe" class="form-control" required>
                                <option value="Masculin">Masculin</option>
                                <option value="Feminin">Féminin</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner le sexe.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="editNationalite" class="form-label">Nationalité <span class="text-danger">*</span></label>
                            <input type="text" id="editNationalite" name="nationalite" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir la nationalité.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="editIdAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select id="editIdAnnee" name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="editOrientationId" class="form-label">Orientation <span class="text-danger">*</span></label>
                            <select id="editOrientationId" class="form-control" required>
                                <option value="">Sélectionner une orientation</option>
                                <?php
                                foreach ($orientations as $orientation) {
                                    echo "<option value='{$orientation['idorientation']}'>{$orientation['designationOrientation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une orientation.</div>
                        </div>
                        
                        <div class="col-md-6">
                            <label for="editPromotionId" class="form-label">Promotion <span class="text-danger">*</span></label>
                            <select id="editPromotionId" name="promotionId" class="form-control" required>
                                <option value="">Sélectionner d'abord une orientation</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editStudentBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
  <script>
      function editStudent(id, matricule, noms, lieuNaissance, dateNaissance, adressemail, telephone, sexe, nationalite, annee, promotion) {
          $('#editStudentId').val(id);
          $('#editMatricule').val(matricule);
          $('#editNoms').val(noms);
          $('#editLieuNaissance').val(lieuNaissance);
          $('#editDateNaissance').val(dateNaissance);
          $('#editAdressemail').val(adressemail);
          $('#editTelephone').val(telephone);
          $('#editSexe').val(sexe);
          $('#editNationalite').val(nationalite);
          $('#editIdAnnee').val(annee);
        
          // Récupérer l'orientation de la promotion sélectionnée
          $.ajax({
              url: 'controller/get_promotion_orientation.php',
              type: 'GET',
              data: { promotionId: promotion },
              dataType: 'json',
              success: function(data) {
                  $('#editOrientationId').val(data.orientationId).trigger('change');
                
                  // Attendre que le changement d'orientation soit traité
                  setTimeout(function() {
                      loadPromotionsWithjQuery('editOrientationId', 'editPromotionId', promotion);
                  }, 500);
              },
              error: function(xhr, status, error) {
                  console.error('Erreur lors de la récupération de l\'orientation:', error);
              }
          });
        
          new bootstrap.Modal(document.getElementById('editStudentModal')).show();
      }
      // Fonction pour récupérer l'orientation d'une promotion
      async function fetchPromotionOrientation(promotionId) {
          try {
              const response = await fetch(`controller/get_promotion_orientation.php?promotionId=${promotionId}`);
              if (!response.ok) {
                  throw new Error(`Erreur HTTP: ${response.status}`);
              }
              const data = await response.json();
              console.log('Orientation récupérée:', data); // Débogage
              return data.orientationId;
          } catch (error) {
              console.error('Erreur lors de la récupération de l\'orientation:', error);
              return null;
          }
      }
    
      // Fonction pour charger les promotions en fonction de l'orientation sélectionnée
      function loadPromotions(orientationSelectId, promotionSelectId, selectedPromotionId = null) {
          const orientationSelect = document.getElementById(orientationSelectId);
          const promotionSelect = document.getElementById(promotionSelectId);
          const orientationId = orientationSelect.value;
    
          if (!orientationId) {
              promotionSelect.innerHTML = '<option value="">Sélectionner d\'abord une orientation</option>';
              return;
          }
    
          // Vider la liste des promotions
          promotionSelect.innerHTML = '<option value="">Chargement...</option>';
    
          // Utiliser un chemin absolu depuis la racine du site
          fetch(`controller/get_promotions_by_orientation.php?orientationId=${orientationId}`)
              .then(response => {
                  if (!response.ok) {
                      throw new Error(`Erreur HTTP: ${response.status}`);
                  }
                  return response.json();
              })
              .then(data => {
                  console.log('Données reçues:', data); // Débogage
            
                  promotionSelect.innerHTML = '';
            
                  if (!Array.isArray(data) || data.length === 0) {
                      promotionSelect.innerHTML = '<option value="">Aucune promotion disponible</option>';
                      return;
                  }
            
                  // Ajouter les options
                  data.forEach(promotion => {
                      const option = document.createElement('option');
                      option.value = promotion.idpromotion;
                      option.textContent = `${promotion.designationPromotion} - ${promotion.anneeDesignation}`;
                
                      // Sélectionner la promotion si elle correspond
                      if (selectedPromotionId && promotion.idpromotion == selectedPromotionId) {
                          option.selected = true;
                      }
                
                      promotionSelect.appendChild(option);
                  });
              })
              .catch(error => {
                  console.error('Erreur lors du chargement des promotions:', error);
                  promotionSelect.innerHTML = '<option value="">Erreur de chargement</option>';
              });
      }
    document.addEventListener('DOMContentLoaded', function() {
        // Pour le formulaire d'ajout
        $('#orientationId').on('change', function() {
            const orientationId = $(this).val();
            loadPromotionsWithjQuery('orientationId', 'promotionId');
        });
        
        // Pour le formulaire de modification
        $('#editOrientationId').on('change', function() {
            loadPromotionsWithjQuery('editOrientationId', 'editPromotionId');
        });
        
        // Fonction pour charger les promotions avec jQuery
        function loadPromotionsWithjQuery(orientationSelectId, promotionSelectId, selectedPromotionId = null) {
            const orientationId = $('#' + orientationSelectId).val();
            const $promotionSelect = $('#' + promotionSelectId);
            
            if (!orientationId) {
                $promotionSelect.html('<option value="">Sélectionner d\'abord une orientation</option>');
                $promotionSelect.trigger('change'); // Important pour Select2
                return;
            }
            
            $promotionSelect.html('<option value="">Chargement...</option>');
            $promotionSelect.trigger('change'); // Important pour Select2
            
            $.ajax({
                url: 'controller/get_promotions_by_orientation.php',
                type: 'GET',
                data: { orientationId: orientationId },
                dataType: 'json',
                success: function(data) {
                    $promotionSelect.empty();
                    
                    if (!Array.isArray(data) || data.length === 0) {
                        $promotionSelect.html('<option value="">Aucune promotion disponible</option>');
                    } else {
                        data.forEach(function(promotion) {
                            const selected = (selectedPromotionId && promotion.idpromotion == selectedPromotionId) ? 'selected' : '';
                            $promotionSelect.append(`<option value="${promotion.idpromotion}" ${selected}>${promotion.designationPromotion} - ${promotion.anneeDesignation}</option>`);
                        });
                    }
                    
                    $promotionSelect.trigger('change'); // Important pour Select2
                },
                error: function(xhr, status, error) {
                    console.error('Erreur AJAX:', error);
                    $promotionSelect.html('<option value="">Erreur de chargement</option>');
                    $promotionSelect.trigger('change'); // Important pour Select2
                }
            });
        }
    });
    function confirmDelete(idEtudiant) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_etudiant.php?idetudiant=' + idEtudiant;
            }
        });
    }
</script>

<script>
document.getElementById('downloadForm').onsubmit = function() {
    setTimeout(function() {
        window.location.href = 'etudiants/etudiant.inscrit';
    }, 1000); // Adjust the timeout as needed
};
</script>

<?php include "./views/include/footer.php"; ?>