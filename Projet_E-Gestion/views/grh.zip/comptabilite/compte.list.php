<?php
include "./views/include/header.php";

$structureModel = new Structure();
$search = isset($_GET['search']) ? $_GET['search'] : '';
$structures = $structureModel->getStructures($search);
?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Liste des Comptes</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Comptes</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card overflow-auto">
                    <div class="card-body">
                        <h5 class="card-title">Liste des Comptes</h5>

                        <!-- Search Form -->
                        <form method="GET" action="" class="mb-3">
                            <div class="input-group">
                                <input type="hidden" name="view" value="comptabilite/compte.edit">
                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher une structure...">
                                <button type="submit" class="btn btn-primary">Rechercher</button>
                            </div>
                        </form>

                        <table class="table table-striped table-bordered" id="structureTable">
                            <thead>
                                <tr>
                                    <th>Structure</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $userId = $_SESSION['id'];
                                $hasResults = false;

                                foreach ($structures as $structure) {
                                    $ver1 = $structureModel->getUserPermissionStructure($userId, $structure['idStructure']);
                                    if ($ver1->fetch()) {
                                        $hasResults = true;
                                        echo "
                                            <tr>
                                                <td>{$structure['designation']}</td>
                                                <td>
                                                    <button type='button' class='btn btn-secondary btn-sm' data-bs-toggle='collapse' data-bs-target='#accounts{$structure['idStructure']}'>
                                                        <i class='bi bi-eye-fill'></i> Afficher les Comptes
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='accounts{$structure['idStructure']}'>
                                                <td colspan='2'>
                                                    <table class='table table-sm'>
                                                        <thead>
                                                            <tr>
                                                                <th>Type de Compte</th>
                                                                <th>Numéro de Compte</th>
                                                                <th>Intitulé</th>
                                                                <th>Classe</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                        ";

                                        $accounts = $structureModel->getComptes();
                                        usort($accounts, function($a, $b) {
                                            return strcmp($a['typeCompte'], $b['typeCompte']);
                                        });

                                        $currentType = '';
                                        foreach ($accounts as $account) {
                                            if ($account['Structure_idStructure'] == $structure['idStructure']) {
                                                if ($currentType !== $account['typeCompte']) {
                                                    $currentType = $account['typeCompte'];
                                                    echo "<tr><td colspan='4' class='font-weight-bold'>{$currentType}</td></tr>";
                                                }
                                                echo "
                                                    <tr>
                                                        <td></td>
                                                        <td>{$account['numeroCompte']}</td>
                                                        <td>{$account['intituleCompte']}</td>
                                                        <td>{$account['classeCompte']}</td>
                                                    </tr>
                                                ";
                                            }
                                        }

                                        echo "
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        ";
                                    }
                                }

                                if (!$hasResults) {
                                    echo "<tr><td colspan='2' class='text-center'>Aucun résultat trouvé</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<?php include "./views/include/footer.php"; ?>