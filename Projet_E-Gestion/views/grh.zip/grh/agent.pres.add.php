<?php
include "./views/include/header.php";

$agentModel = new Agent();
$structure = new Structure();
$serviceModel = new Service();
$search = isset($_GET['search']) ? $_GET['search'] : '';
$agents = $agentModel->getAgents($search);

?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Ajouter Présences Mensuelles</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Présences</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="card overflow-auto">
                    <div class="card-body">
                        <h5 class="card-title">Gestion des présences
                            <span>
                                | <a data-bs-toggle="modal" data-bs-target="#importExcelModal" class="btnPage">
                                    <i class="bi bi-upload"></i> Importer un Fichier Excel
                                </a>
                            </span>
                        </h5>

                        <!-- Search Form -->
                        <form method="GET" action="" class="mb-3">
                            <div class="input-group">
                                <input type="hidden" name="view" value="grh/agent.pres.add">
                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par nom...">
                                <button type="submit" class="btn btn-primary">Rechercher</button>
                            </div>
                        </form>

                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nom</th>
                                    <th>Lieu de Naissance</th>
                                    <th>Date de Naissance</th>
                                    <th>Sexe</th>
                                    <th>Structure</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $userId = $_SESSION['id'];
                                $hasResults = false;
                                $i=1;

                                foreach ($agents as $agent) {
                                    $ver1 = $structure->getUserPermissionStructure($userId, $agent['idStructure']);
                                    $structureData = $structure->getStructureById($agent['idStructure']);
                                    $joursOuvrables = $structureData['joursOuvrables'];

                                    $dateNaiss=date('d-m-Y',strtotime($agent['dateNaissance']));

                                    if ($ver1->fetch()) {
                                        $hasResults = true;
                                        echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$agent['noms']}</td>
                                                <td>{$agent['lieuNaissance']}</td>
                                                <td>{$dateNaiss}</td>
                                                <td>{$agent['sexe']}</td>
                                                <td>{$agent['designationStructure']}</td>
                                                <td>
                                                    <button type='button' class='btn btn-info btn-sm add-presence-btn' data-agent-id='{$agent['idAgent']}' data-jours-ouvrables='{$joursOuvrables}' data-bs-toggle='modal' data-bs-target='#addPresenceModal'>
                                                        <i class='bi bi-calendar-plus'></i>
                                                    </button>
                                                    <button type='button' class='btn btn-secondary btn-sm' data-bs-toggle='collapse' data-bs-target='#presences{$agent['idAgent']}'>
                                                        <i class='bi bi-eye-fill'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='presences{$agent['idAgent']}'>
                                                <td colspan='7'>
                                                    <table class='table table-sm'>
                                                        <thead>
                                                            <tr>
                                                                <th>Année</th>
                                                                <th>Mois</th>
                                                                <th>Jours de Présence</th>
                                                                <th>Jours d'Absence</th>
                                                                <th>Retards</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                        ";

                                        $presences = $agentModel->getPresenceByAgent($agent['idAgent']);
                                        foreach ($presences as $presence) {
                                            echo "
                                                <tr>
                                                    <td>{$presence['annee']}</td>
                                                    <td>{$presence['mois']}</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>
                                                        
                                                        <form action='controller/delete_presence.php' method='POST' class='delete-presence-form' style='display:inline;'>
                                                            <input type='hidden' name='idPresence' value='{$presence['idPresence_agent']}'>
                                                            <button type='button' class='btn btn-danger btn-sm delete-presence-btn'>Supprimer</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            ";
                                        }

                                        echo "
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        ";
                                        $i++;
                                    }
                                }
                                if (!$hasResults) {
                                    echo "<tr><td colspan='7' class='text-center'>Aucun résultat trouvé</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>

                        <!-- Modal for importing Excel -->
                        <div class="modal fade" id="importExcelModal" tabindex="-1" aria-labelledby="importExcelModalLabel" aria-hidden="true" data-bs-backdrop="static">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="importExcelModalLabel">Importer un Fichier Excel</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="importExcelForm" action="controller/import_excel.php" method="POST" enctype="multipart/form-data">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="annee" class="form-label">Année <span class="text-danger">*</span></label>
                                                    <select class="form-select" id="annee" name="annee" required>
                                                        <?php
                                                        $currentYear = date('Y');
                                                        for ($year = $currentYear; $year <= $currentYear + 5; $year++) {
                                                            echo "<option value='$year'>$year</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="mois" class="form-label">Mois <span class="text-danger">*</span></label>
                                                    <select class="form-select" id="mois" name="mois" required>
                                                        <?php
                                                        $months = [
                                                            '01' => 'Janvier', '02' => 'Fevrier', '03' => 'Mars', '04' => 'Avril',
                                                            '05' => 'Mai', '06' => 'Juin', '07' => 'Juillet', '08' => 'Aout',
                                                            '09' => 'Septembre', '10' => 'Octobre', '11' => 'Novembre', '12' => 'Decembre'
                                                        ];
                                                        foreach ($months as $num => $name) {
                                                            echo "<option value='$name'>$name</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="annee" class="form-label">Jours Ouvrables <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" name="jours" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="heure" class="form-label">Heure d'arrivée <span class="text-danger">*</span></label>
                                                    <input type="time" class="form-control" name="heure" required>
                                                </div>

                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="annee" class="form-label">Colonne des Codes</label>
                                                    <input type="number" class="form-control" name="agentCodeColumn">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="heure" class="form-label">Colonne Heure</label>
                                                    <input type="number" class="form-control" name="dateTimeColumn">
                                                </div>

                                            </div>
                                            <div class="mb-3">
                                                <label for="excelFile" class="form-label">Fichier Excel/CSV <span class="text-danger">*</span></label>
                                                <input type="file" class="form-control" id="excelFile" name="excelFile" accept=".xls,.xlsx,.csv" required>
                                            </div>
                                            <button type="submit" class="btnModSave" data-style="zoom-out">
                                                <i class="bi bi-upload"></i> Importer
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for adding presence -->
                        <div class="modal fade" id="addPresenceModal" tabindex="-1" aria-labelledby="addPresenceModalLabel" aria-hidden="true" data-bs-backdrop="static">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="addPresenceModalLabel">Ajouter Présence Mensuelle</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="addPresenceForm" action="controller/create_presence.php" method="POST">
                                            <input type="hidden" name="agentId" id="presenceAgentId">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="annee" class="form-label">Année <span class="text-danger">*</span></label>
                                                    <select class="form-select" id="annee" name="annee" required>
                                                        <?php
                                                        $currentYear = date('Y');
                                                        for ($year = $currentYear; $year <= $currentYear + 5; $year++) {
                                                            echo "<option value='$year'>$year</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="mois" class="form-label">Mois <span class="text-danger">*</span></label>
                                                    <select class="form-select" id="mois" name="mois" required>
                                                        <?php
                                                        $months = [
                                                            '01' => 'Janvier', '02' => 'Fevrier', '03' => 'Mars', '04' => 'Avril',
                                                            '05' => 'Mai', '06' => 'Juin', '07' => 'Juillet', '08' => 'Aout',
                                                            '09' => 'Septembre', '10' => 'Octobre', '11' => 'Novembre', '12' => 'Décembre'
                                                        ];
                                                        foreach ($months as $num => $name) {
                                                            echo "<option value='$name'>$name</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="joursPresence" class="form-label">Jours de Présence <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" id="joursPresence" name="joursPresence" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="joursAbsence" class="form-label">Jours d'Absence <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" id="joursAbsence" name="joursAbsence" required>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="joursRetard" class="form-label">Jours de Retard <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control" id="joursRetard" name="joursRetard" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="bi bi-save"></i> Ajouter
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Modal for editing presence -->
                        <div class="modal fade" id="editPresenceModal" tabindex="-1" aria-labelledby="editPresenceModalLabel" aria-hidden="true" data-bs-backdrop="static">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editPresenceModalLabel">Modifier Présence Mensuelle</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form id="editPresenceForm" action="controller/update_presence.php" method="POST">
                                            <input type="hidden" name="idPresence" id="editIdPresence">
                                            <input type="hidden" name="agentId" id="editAgentId">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="editAnnee" class="form-label">Année <span class="text-danger">*</span></label>
                                                    <select class="form-control" id="editAnnee" name="annee" required>
                                                        <?php
                                                        $currentYear = date('Y');
                                                        for ($year = $currentYear; $year <= $currentYear + 5; $year++) {
                                                            echo "<option value='$year'>$year</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="editMois" class="form-label">Mois <span class="text-danger">*</span></label>
                                                    <select class="form-control" id="editMois" name="mois" required>
                                                        <?php
                                                        $months = [
                                                            '01' => 'Janvier', '02' => 'Fevrier', '03' => 'Mars', '04' => 'Avril',
                                                            '05' => 'Mai', '06' => 'Juin', '07' => 'Juillet', '08' => 'Aout',
                                                            '09' => 'Septembre', '10' => 'Octobre', '11' => 'Novembre', '12' => 'Décembre'
                                                        ];
                                                        foreach ($months as $num => $name) {
                                                            echo "<option value='$name'>$name</option>";
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label for="editJoursPresence" class="form-label">Jours de Présence <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" id="editJoursPresence" name="joursPresence" required>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="editJoursAbsence" class="form-label">Jours d'Absence <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" id="editJoursAbsence" name="joursAbsence" required>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="editJoursRetard" class="form-label">Jours de Retard <span class="text-danger">*</span></label>
                                                <input type="number" class="form-control" id="editJoursRetard" name="joursRetard" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="bi bi-save"></i> Enregistrer
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <script>
                            document.addEventListener('DOMContentLoaded', function () {
                                // Add presence button click event
                                document.querySelectorAll('.add-presence-btn').forEach(button => {
                                    button.addEventListener('click', function () {
                                        const agentId = this.getAttribute('data-agent-id');
                                        const joursOuvrables = parseInt(this.getAttribute('data-jours-ouvrables')) || 0;
                                        document.getElementById('presenceAgentId').value = agentId;
                                        document.getElementById('joursPresence').max = joursOuvrables;
                                        document.getElementById('joursAbsence').max = joursOuvrables;
                                        document.getElementById('joursRetard').max = joursOuvrables;

                                        // Set initial absence days
                                        document.getElementById('joursAbsence').value = joursOuvrables;

                                        // Add event listener for presence days input
                                        document.getElementById('joursPresence').addEventListener('input', function () {
                                            const joursPresence = parseInt(this.value) || 0;
                                            const joursAbsence = joursOuvrables - joursPresence;
                                            const joursRetard = joursOuvrables - (joursPresence + joursAbsence);
                                            document.getElementById('joursAbsence').value = joursAbsence;
                                            document.getElementById('joursRetard').value = joursRetard;
                                        });
                                    });
                                });

                                // Edit presence button click event
                                document.querySelectorAll('.edit-presence-btn').forEach(button => {
                                    button.addEventListener('click', function () {
                                        const presenceId = this.getAttribute('data-presence-id');
                                        const agentId = this.getAttribute('data-agent-id');
                                        const annee = this.getAttribute('data-annee');
                                        const mois = this.getAttribute('data-mois');
                                        const joursPresence = this.getAttribute('data-jours-presence');
                                        const joursAbsence = this.getAttribute('data-jours-absence');
                                        const joursRetard = this.getAttribute('data-jours-retard');

                                        document.getElementById('editIdPresence').value = presenceId;
                                        document.getElementById('editAgentId').value = agentId;
                                        document.getElementById('editAnnee').value = annee;
                                        document.getElementById('editMois').value = mois;
                                        document.getElementById('editJoursPresence').value = joursPresence;
                                        document.getElementById('editJoursAbsence').value = joursAbsence;
                                        document.getElementById('editJoursRetard').value = joursRetard;
                                    });
                                });

                                // Delete presence button click event
                                document.querySelectorAll('.delete-presence-btn').forEach(button => {
                                    button.addEventListener('click', function () {
                                        const form = this.closest('.delete-presence-form');
                                        Swal.fire({
                                            title: 'Êtes-vous sûr?',
                                            text: "Cette action est irréversible!",
                                            icon: 'warning',
                                            showCancelButton: true,
                                            confirmButtonColor: '#3085d6',
                                            cancelButtonColor: '#d33',
                                            confirmButtonText: 'Oui, supprimer!',
                                            cancelButtonText: 'Annuler'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                form.submit();
                                            }
                                        });
                                    });
                                });
                            });
                        </script>

                    </div>
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<?php include "./views/include/footer.php"; ?>