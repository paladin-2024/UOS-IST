<?php
include "./views/include/header.php";
$agent = new Agent();
$structure = new Structure();
$service = new Service();
$grade = new Grade();
$roleModel = new Role();
$roles = $roleModel->getAllRoles();

$search = isset($_GET['search']) ? $_GET['search'] : '';
?>

<!-- Espace de travail -->
<main id="main" class="main">

    <div class="pagetitle">
        <h1>AGENTS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Agents</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table agents -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                            <h5 class="card-title">
                                Gestion des agents
                                <span>
                                    | <a data-bs-toggle="modal" data-bs-target="#createAgentModal" class="btnPage">
                                        <i class="bi bi-plus-circle-fill"></i> Ajouter
                                    </a>
                                    | <a data-bs-toggle="modal" data-bs-target="#importAgentModal" class="btnPage">
                                        <i class="bi bi-file-earmark-excel-fill"></i> Importer
                                    </a>
                                </span>
                            </h5>


                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="grh/agent.add">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par nom...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Noms</th>
                                        <th scope="col">Matricule</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Grade</th>
                                        <th scope="col">Téléphone</th>
                                        <th scope="col">Service/Structure</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $listeAgent = $agent->getAgents($search);
                                    $i = 1;

                                    foreach ($listeAgent as $l) {
                                        $ver1 = $structure->getUserPermissionStructure($_SESSION['id'], $l['idStructure']);
                                        $dateN = date('d/m/Y', strtotime($l['dateNaissance']));
                                        
                                        // Récupérer le nom du grade
                                        $gradeInfo = !empty($l['grade_id']) ? $grade->getGradeById($l['grade_id']) : null;
                                        $gradeName = $gradeInfo ? $gradeInfo['designation'] : '-';
                                        
                                        // Récupérer le nom du service
                                        $serviceInfo = !empty($l['idService']) ? $service->getServiceById($l['idService']) : null;
                                        $serviceName = $serviceInfo ? $serviceInfo['designation'] : $l['designationStructure'];
                                        
                                        if ($ver1->fetch()) {
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$l['noms']}</td>
                                                <td>" . (empty($l['matricule']) ? '-' : $l['matricule']) . "</td>
                                                <td>" . (empty($l['type_agent']) ? '-' : $l['type_agent']) . "</td>
                                                <td>{$gradeName}</td>
                                                <td>{$l['telephone']}</td>
                                                <td>{$serviceName}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editAgent(
                                                        {$l['idAgent']}, 
                                                        \"" . addslashes($l['noms']) . "\",
                                                        \"" . addslashes($l['lieuNaissance']) . "\",
                                                        \"" . addslashes($l['dateNaissance']) . "\",
                                                        \"" . addslashes($l['sexe']) . "\",
                                                        \"" . addslashes($l['etatCivil']) . "\",
                                                        \"" . addslashes($l['niveauEtude']) . "\",
                                                        \"" . addslashes($l['telephone']) . "\",
                                                        \"" . addslashes($l['email']) . "\",
                                                        \"" . addslashes($l['codeAgent']) . "\",
                                                        \"" . addslashes($l['matricule'] ?? '') . "\",
                                                        \"" . addslashes($l['type_agent'] ?? '') . "\",
                                                        " . ($l['grade_id'] ?? 'null') . ",
                                                        \"" . addslashes($l['photo']) . "\",
                                                        {$l['idStructure']},
                                                        " . ($l['idService'] ?? 'null') . "
                                                    )'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDelete({$l['idAgent']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-primary' onclick='assignUserAccess(
                                                        {$l['idAgent']}, 
                                                        \"" . addslashes($l['noms']) . "\",
                                                        \"" . addslashes($l['photo']) . "\"
                                                    )'>
                                                        <i class='bi bi-person-plus'></i>Attribuer un accès
                                                    </button>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour ajouter un agent -->
<div class="modal fade" id="createAgentModal" tabindex="-1" role="dialog" aria-labelledby="createAgentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg"> <!-- Increased size of the modal -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un Agent</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form method="POST" action="controller/create_agent.php" class="needs-validation" novalidate>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="noms" class="form-label">Noms <span class="text-danger">*</span></label>
            <input type="text" name="noms" class="form-control" required>
            <div class="invalid-feedback">Veuillez saisir les noms.</div>
        </div>
        <div class="col-md-6">
            <label for="matricule" class="form-label">Matricule</label>
            <input type="text" name="matricule" class="form-control">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="type_agent" class="form-label">Type d'agent <span class="text-danger">*</span></label>
            <select name="type_agent" id="type_agent" class="form-select" required onchange="updateGradeOptions()">
                <option value="">Sélectionner le type</option>
                <option value="Enseignant">Enseignant</option>
                <option value="Administratif">Administratif</option>
                <option value="Recherche">Recherche</option>
            </select>
            <div class="invalid-feedback">Veuillez sélectionner le type d'agent.</div>
        </div>
        <div class="col-md-6">
            <label for="grade_id" class="form-label">Grade</label>
            <select name="grade_id" id="grade_id" class="form-select">
                <option value="">Sélectionner le grade</option>
                <?php
                $grades = $grade->getGrades();
                foreach ($grades as $g) {
                    echo "<option value='{$g['idgrade']}' data-type='{$g['type_agent']}'>{$g['designation']}</option>";
                }
                ?>
            </select>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="lieuNaissance" class="form-label">Lieu de Naissance</label>
            <input type="text" name="lieuNaissance" class="form-control">
        </div>
        <div class="col-md-6">
            <label for="dateNaissance" class="form-label">Date de Naissance</label>
            <input type="date" name="dateNaissance" class="form-control">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="sexe" class="form-label">Sexe <span class="text-danger">*</span></label>
            <select name="sexe" class="form-select" required>
                <option value="">Sélectionner le sexe</option>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
            </select>
            <div class="invalid-feedback">Veuillez sélectionner le sexe.</div>
        </div>
        <div class="col-md-6">
            <label for="etatCivil" class="form-label">État Civil <span class="text-danger">*</span></label>
            <select name="etatCivil" class="form-select" required>
                <option value="">Sélectionner l'état civil</option>
                <option value="Célibataire">Célibataire</option>
                <option value="Marié">Marié</option>
                <option value="Divorcé">Divorcé</option>
                <option value="Veuf">Veuf</option>
            </select>
            <div class="invalid-feedback">Veuillez sélectionner l'état civil.</div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="niveauEtude" class="form-label">Niveau d'Étude <span class="text-danger">*</span></label>
            <input type="text" name="niveauEtude" class="form-control" required>
            <div class="invalid-feedback">Veuillez saisir le niveau d'étude.</div>
        </div>
        <div class="col-md-6">
            <label for="telephone" class="form-label">Téléphone</label>
            <input type="text" name="telephone" class="form-control">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="email" class="form-label">Adresse mail</label>
            <input type="text" name="email" class="form-control">
        </div>
        <div class="col-md-6">
            <label for="codeAgent" class="form-label">CODE POINTEUSE AGENT</label>
            <input type="text" name="codeAgent" class="form-control">
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="idStructure" class="form-label">Campus <span class="text-danger">*</span></label>
            <select name="idStructure" id="idStructure" class="form-select" required onchange="updateServiceOptions()">
                <option value="">Sélectionner un campus</option>
                <?php
                $util = $structure->getStructures();
                foreach ($util as $a) {
                    $ver = $structure->getUserPermissionStructure($_SESSION['id'], $a['idStructure']);
                    if ($ver->fetch()) {
                        echo "<option value='{$a['idStructure']}'>{$a['designation']}</option>";
                    }
                }
                ?>
            </select>
            <div class="invalid-feedback">Veuillez sélectionner une structure.</div>
        </div>
        <div class="col-md-6">
            <label for="idService" class="form-label">Service</label>
            <select name="idService" id="idService" class="form-select">
                <option value="">Sélectionner un service</option>
                <!-- Les options seront chargées dynamiquement en fonction de la structure sélectionnée -->
            </select>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
        <button type="submit" name="addAgentBtn" class="btn btn-primary">
            <i class="bi bi-save"></i> Enregistrer
        </button>
    </div>
</form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour attribuer un accès utilisateur -->
<div class="modal fade" id="assignUserAccessModal" tabindex="-1" role="dialog" aria-labelledby="assignUserAccessModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Attribuer un Accès Utilisateur</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/assign_user_access.php" class="needs-validation" novalidate>
                    <input type="hidden" name="idAgent" id="assignUserIdAgent">
                    <input type="hidden" name="nomUser" id="assignUserNomUser">
                    <input type="hidden" name="imageUser" id="assignUserImageUser">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="loginUser" class="form-label">Identifiant <span class="text-danger">*</span></label>
                            <input type="text" name="loginUser" id="loginUser" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir un identifiant.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="role" class="form-label">Rôle <span class="text-danger">*</span></label>
                            <select name="idRole" class="form-select" required>
                                <option value="">Sélectionner un rôle</option>
                                <?php
                                // Fetch roles from the database
                                foreach ($roles as $role) {
                                    echo "<option value='{$role['idRole']}'>{$role['nomRole']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un rôle.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="assignUserAccessBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier un agent -->
<div class="modal fade" id="editAgentModal" tabindex="-1" role="dialog" aria-labelledby="editAgentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg"> <!-- Increased size of the modal -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un Agent</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/edit_agent.php" class="needs-validation" novalidate>
                    <input type="hidden" name="idAgent" id="editAgentId">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="noms" class="form-label">Noms</label>
                            <input type="text" name="noms" id="editAgentNoms" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="matricule" class="form-label">Matricule</label>
                            <input type="text" name="matricule" id="editAgentMatricule" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="type_agent" class="form-label">Type d'agent <span class="text-danger">*</span></label>
                            <select name="type_agent" id="editAgentType" class="form-select" required onchange="updateEditGradeOptions()">
                                <option value="">Sélectionner le type</option>
                                <option value="Enseignant">Enseignant</option>
                                <option value="Administratif">Administratif</option>
                                <option value="Recherche">Recherche</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner le type d'agent.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="grade_id" class="form-label">Grade</label>
                            <select name="grade_id" id="editAgentGrade" class="form-select">
                                <option value="">Sélectionner le grade</option>
                                <?php
                                foreach ($grades as $g) {
                                    echo "<option value='{$g['idgrade']}' data-type='{$g['type_agent']}'>{$g['designation']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="lieuNaissance" class="form-label">Lieu de Naissance</label>
                            <input type="text" name="lieuNaissance" id="editAgentLieuNaissance" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="dateNaissance" class="form-label">Date de Naissance</label>
                            <input type="date" name="dateNaissance" id="editAgentDateNaissance" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="sexe" class="form-label">Sexe</label>
                            <select name="sexe" id="editAgentSexe" class="form-select" required>
                                <option value="M">Masculin</option>
                                <option value="F">Féminin</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="etatCivil" class="form-label">État Civil</label>
                            <select name="etatCivil" id="editAgentEtatCivil" class="form-select" required>
                                <option value="Célibataire">Célibataire</option>
                                <option value="Marié">Marié</option>
                                <option value="Divorcé">Divorcé</option>
                                <option value="Veuf">Veuf</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="niveauEtude" class="form-label">Niveau d'Étude</label>
                            <input type="text" name="niveauEtude" id="editAgentNiveauEtude" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label for="telephone" class="form-label">Téléphone</label>
                            <input type="text" name="telephone" id="editTelephone" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="email" class="form-label">Adresse mail</label>
                            <input type="text" name="email" id="editEmail" class="form-control">
                            <input type="hidden" name="pictureAgent" id="pictureInput">
                        </div>
                        <div class="col-md-6">
                            <label for="codeAgent" class="form-label">CODE POINTEUSE AGENT</label>
                            <input type="text" name="codeAgent" id="editCodeAgent" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="idStructure" class="form-label">Campus</label>
                            <select name="idStructure" id="editAgentStructure" class="form-select" required onchange="updateEditServiceOptions()">
                                <?php
                                foreach ($util as $a) {
                                    $ver = $structure->getUserPermissionStructure($_SESSION['id'], $a['idStructure']);
                                    if ($ver->fetch()) {
                                        echo "<option value='{$a['idStructure']}'>{$a['designation']}</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="idService" class="form-label">Service</label>
                            <select name="idService" id="editAgentService" class="form-select">
                                <option value="">Sélectionner un service</option>
                                <!-- Les options seront chargées dynamiquement en fonction de la structure sélectionnée -->
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editAgentBtn" class="btn btn-primary"><i class="bi bi-save"></i> Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour importer des agents -->
<div class="modal fade" id="importAgentModal" tabindex="-1" role="dialog" aria-labelledby="importAgentModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des Agents</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/import_agent.php" class="needs-validation" enctype="multipart/form-data" novalidate>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Veuillez télécharger un fichier Excel (.xlsx, .xls) contenant les données des agents à importer.
                        <br>
                        <strong>Note:</strong> La première ligne du fichier doit contenir les en-têtes des colonnes.
                    </div>
                    
                    <div class="mb-3">
                        <label for="importFile" class="form-label">Fichier Excel <span class="text-danger">*</span></label>
                        <input type="file" name="importFile" id="importFile" class="form-control" accept=".xlsx, .xls" required>
                        <div class="invalid-feedback">Veuillez sélectionner un fichier Excel.</div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="importIdStructure" class="form-label">Structure <span class="text-danger">*</span></label>
                            <select name="importIdStructure" id="importIdStructure" class="form-select" required>
                                <option value="">Sélectionner une structure</option>
                                <?php
                                $structures = $structure->getStructures();
                                foreach ($structures as $s) {
                                    $ver = $structure->getUserPermissionStructure($_SESSION['id'], $s['idStructure']);
                                    if ($ver->fetch()) {
                                        echo "<option value='{$s['idStructure']}'>{$s['designation']}</option>";
                                    }
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une structure.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="startRow" class="form-label">Ligne de début <span class="text-danger">*</span></label>
                            <input type="number" name="startRow" id="startRow" class="form-control" value="2" min="1" required>
                            <div class="invalid-feedback">Veuillez spécifier la ligne de début.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="nomsColumn" class="form-label">Colonne Noms <span class="text-danger">*</span></label>
                            <input type="number" name="nomsColumn" id="nomsColumn" class="form-control" min="1" required>
                            <div class="invalid-feedback">Obligatoire</div>
                        </div>
                        <div class="col-md-4">
                            <label for="matriculeColumn" class="form-label">Colonne Matricule</label>
                            <input type="number" name="matriculeColumn" id="matriculeColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="typeAgentColumn" class="form-label">Colonne Type Agent</label>
                            <input type="number" name="typeAgentColumn" id="typeAgentColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="lieuNaissanceColumn" class="form-label">Colonne Lieu de Naissance</label>
                            <input type="number" name="lieuNaissanceColumn" id="lieuNaissanceColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="dateNaissanceColumn" class="form-label">Colonne Date de Naissance</label>
                            <input type="number" name="dateNaissanceColumn" id="dateNaissanceColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="sexeColumn" class="form-label">Colonne Sexe</label>
                            <input type="number" name="sexeColumn" id="sexeColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="etatCivilColumn" class="form-label">Colonne État Civil</label>
                            <input type="number" name="etatCivilColumn" id="etatCivilColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="niveauEtudeColumn" class="form-label">Colonne Niveau d'Étude</label>
                            <input type="number" name="niveauEtudeColumn" id="niveauEtudeColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="telephoneColumn" class="form-label">Colonne Téléphone</label>
                            <input type="number" name="telephoneColumn" id="telephoneColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="emailColumn" class="form-label">Colonne Email</label>
                            <input type="number" name="emailColumn" id="emailColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="codeAgentColumn" class="form-label">Colonne Code Agent</label>
                            <input type="number" name="codeAgentColumn" id="codeAgentColumn" class="form-control" min="0">
                            <small class="text-muted">Laisser vide si non applicable</small>
                        </div>
                        <div class="col-md-4">
                            <label for="defaultType" class="form-label">Type d'agent par défaut</label>
                            <select name="defaultType" id="defaultType" class="form-select">
                                <option value="">Aucun</option>
                                <option value="Enseignant">Enseignant</option>
                                <option value="Administratif">Administratif</option>
                                <option value="Recherche">Recherche</option>
                            </select>
                            <small class="text-muted">Si colonne Type Agent non spécifiée</small>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="importAgentBtn" class="btn btn-primary">
                            <i class="bi bi-upload"></i> Importer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    // Fonction pour filtrer les grades en fonction du type d'agent sélectionné
    function updateGradeOptions() {
        const typeSelect = document.getElementById('type_agent');
        const gradeSelect = document.getElementById('grade_id');
        const selectedType = typeSelect.value;
        
        // Masquer toutes les options de grade
        Array.from(gradeSelect.options).forEach(option => {
            if (option.value === '') {
                option.style.display = 'block'; // Toujours afficher l'option vide
            } else {
                const gradeType = option.getAttribute('data-type');
                option.style.display = (gradeType === selectedType || !selectedType) ? 'block' : 'none';
            }
        });
        
        // Réinitialiser la sélection si le grade actuel n'est pas compatible
        const currentGrade = gradeSelect.value;
        let isCurrentGradeValid = false;
        
        Array.from(gradeSelect.options).forEach(option => {
            if (option.value === currentGrade && option.style.display !== 'none') {
                isCurrentGradeValid = true;
            }
        });
        
        if (!isCurrentGradeValid) {
            gradeSelect.value = '';
        }
    }
    
    // Fonction pour filtrer les grades dans le formulaire d'édition
    function updateEditGradeOptions() {
        const typeSelect = document.getElementById('editAgentType');
        const gradeSelect = document.getElementById('editAgentGrade');
        const selectedType = typeSelect.value;
        
        Array.from(gradeSelect.options).forEach(option => {
            if (option.value === '') {
                option.style.display = 'block';
            } else {
                const gradeType = option.getAttribute('data-type');
                option.style.display = (gradeType === selectedType || !selectedType) ? 'block' : 'none';
            }
        });
        
        const currentGrade = gradeSelect.value;
        let isCurrentGradeValid = false;
        
        Array.from(gradeSelect.options).forEach(option => {
            if (option.value === currentGrade && option.style.display !== 'none') {
                isCurrentGradeValid = true;
            }
        });
        
        if (!isCurrentGradeValid) {
            gradeSelect.value = '';
        }
    }
    
    // Fonction pour charger les services en fonction de la structure sélectionnée
    function updateServiceOptions() {
        const structureSelect = document.getElementById('idStructure');
        const serviceSelect = document.getElementById('idService');
        const structureId = structureSelect.value;
        
        // Vider le select des services sauf la première option
        serviceSelect.innerHTML = '<option value="">Sélectionner un service</option>';
        
        if (structureId) {
            // Appel AJAX pour récupérer les services de la structure
            fetch('controller/get_services.php?idStructure=' + structureId)
                .then(response => response.json())
                .then(data => {
                    data.forEach(service => {
                        const option = document.createElement('option');
                        option.value = service.idService;
                        option.textContent = service.designationService;
                        serviceSelect.appendChild(option);
                    });
                })
                .catch(error => console.error('Erreur:', error));
        }
    }
    
    // Fonction pour charger les services dans le formulaire d'édition
    function updateEditServiceOptions() {
        const structureSelect = document.getElementById('editAgentStructure');
        const serviceSelect = document.getElementById('editAgentService');
        const structureId = structureSelect.value;
        const currentServiceId = serviceSelect.getAttribute('data-current-service');
        
        // Vider le select des services sauf la première option
        serviceSelect.innerHTML = '<option value="">Sélectionner un service</option>';
        
        if (structureId) {
            fetch('controller/get_services.php?idStructure=' + structureId)
                .then(response => response.json())
                .then(data => {
                    data.forEach(service => {
                        const option = document.createElement('option');
                        option.value = service.idService;
                        option.textContent = service.designationService;
                        if (service.idService == currentServiceId) {
                            option.selected = true;
                        }
                        serviceSelect.appendChild(option);
                    });
                })
                .catch(error => console.error('Erreur:', error));
        }
    }

    function editAgent(id, noms, lieuNaissance, dateNaissance, sexe, etatCivil, niveauEtude, telephone, email, code, matricule, type_agent, grade_id, photo, idStructure, idService) {
        document.getElementById('editAgentId').value = id;
        document.getElementById('editAgentNoms').value = noms;
        document.getElementById('editAgentLieuNaissance').value = lieuNaissance;
        document.getElementById('editAgentDateNaissance').value = dateNaissance;
        document.getElementById('editAgentSexe').value = sexe;
        document.getElementById('editAgentEtatCivil').value = etatCivil;
        document.getElementById('editAgentNiveauEtude').value = niveauEtude;
        document.getElementById('editTelephone').value = telephone;
        document.getElementById('editEmail').value = email;
        document.getElementById('editCodeAgent').value = code;
        document.getElementById('editAgentMatricule').value = matricule;
        document.getElementById('editAgentType').value = type_agent;
        document.getElementById('pictureInput').value = photo;

// Sélectionner la structure
let structureSelect = document.getElementById('editAgentStructure');
for (let i = 0; i < structureSelect.options.length; i++) {
    if (structureSelect.options[i].value == idStructure) {
        structureSelect.options[i].selected = true;
        break;
    }
}

// Sélectionner le grade si disponible
if (grade_id) {
    document.getElementById('editAgentGrade').value = grade_id;
} else {
    document.getElementById('editAgentGrade').value = '';
}

// Stocker l'ID du service actuel pour le sélectionner après chargement
let serviceSelect = document.getElementById('editAgentService');
serviceSelect.setAttribute('data-current-service', idService || '');

// Mettre à jour les options de grade en fonction du type d'agent
updateEditGradeOptions();

// Charger les services de la structure sélectionnée
updateEditServiceOptions();

new bootstrap.Modal(document.getElementById('editAgentModal')).show();
}

function confirmDelete(idAgent) {
Swal.fire({
    title: 'Êtes-vous sûr ?',
    text: "Cette action est irréversible !",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Oui, supprimer',
    cancelButtonText: 'Annuler'
}).then((result) => {
    if (result.isConfirmed) {
        window.location.href = 'controller/delete_agent.php?idAgent=' + idAgent;
    }
});
}

function assignUserAccess(idAgent, nomUser, imageUser) {
document.getElementById('assignUserIdAgent').value = idAgent;
document.getElementById('assignUserNomUser').value = nomUser;
document.getElementById('assignUserImageUser').value = imageUser;

new bootstrap.Modal(document.getElementById('assignUserAccessModal')).show();
}

// Initialiser les filtres de grade au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
updateGradeOptions();

// Ajouter des écouteurs d'événements pour les changements de structure
document.getElementById('idStructure').addEventListener('change', updateServiceOptions);
document.getElementById('editAgentStructure').addEventListener('change', updateEditServiceOptions);
});
</script>

<?php include "./views/include/footer.php"; ?>

