<?php
include "./views/include/header.php";
$universite = new Universite();
$horaireModel = new Horaire();

$userId = $_SESSION['id'];

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Vérifier si l'utilisateur est un responsable de section
$isResponsable = $universite->isUserSectionResponsable($userId, $currentYear['idannee_acad']);

// Récupérer les promotions selon le rôle de l'utilisateur
if ($isResponsable) {
    // L'utilisateur est un responsable de section, filtrer les promotions
    $promotions = $universite->getPromotionsByResponsable($currentYear['idannee_acad'], $userId);
} else {
    // L'utilisateur n'est pas un responsable, vérifier s'il a un rôle admin
    if (isset($_SESSION['idRole']) && $_SESSION['idRole'] === 1) {
        // Pour les administrateurs, afficher toutes les promotions
        $promotions = $universite->getPromotions($currentYear['idannee_acad']);
    } else {
        // Utilisateur standard sans droits spécifiques
        $promotions = [];
        $_SESSION['error'] = "Vous n'avez pas les droits pour accéder aux horaires des promotions.";
    }
}

// Si aucune promotion n'est accessible, afficher un message
if (empty($promotions)) {
    ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>GESTION DES HORAIRES</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                    <li class="breadcrumb-item active">Horaires</li>
                </ol>
            </nav>
        </div>

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="alert alert-warning" role="alert">
                                <i class="bi bi-exclamation-triangle me-2"></i>
                                Vous n'êtes pas responsable d'une section ou aucune promotion n'est disponible pour l'année académique en cours.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php
    include "./views/include/footer.php";
    exit;
}

// Récupérer les horaires pour la promotion sélectionnée
$idPromotion = isset($_GET['promotion']) ? intval($_GET['promotion']) : (isset($promotions[0]) ? $promotions[0]['idpromotion'] : 0);

// Vérifier si la promotion sélectionnée fait partie des promotions autorisées
$promotionAuthorized = false;
foreach ($promotions as $p) {
    if ($p['idpromotion'] === $idPromotion) {
        $promotionAuthorized = true;
        break;
    }
}

if (!$promotionAuthorized && !empty($promotions)) {
    // Si la promotion n'est pas autorisée, utiliser la première promotion disponible
    $idPromotion = $promotions[0]['idpromotion'];
}

// Gérer la navigation par semaine
$today = date('Y-m-d');
$weekOffset = isset($_GET['week']) ? intval($_GET['week']) : 0;

// Déterminer le premier jour de la semaine courante (lundi)
$currentMonday = date('Y-m-d', strtotime("monday this week $weekOffset weeks", strtotime($today)));
$currentSunday = date('Y-m-d', strtotime("sunday this week $weekOffset weeks", strtotime($today)));


// Récupérer les horaires pour la semaine spécifique
$horaires = $horaireModel->getHorairesByPromotionAndDates(
    $idPromotion, 
    $currentYear['idannee_acad'],
    $currentMonday,   // Date de début de la semaine
    $currentSunday    // Date de fin de la semaine
);

// Récupérer les ECUE disponibles pour cette promotion
$ecues = $universite->getEcuesByPromotion($idPromotion);


// Pour l'affichage
$weekDates = [];
$weekDays = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
foreach ($weekDays as $index => $day) {
    $date = date('Y-m-d', strtotime("+$index days", strtotime($currentMonday)));
    $weekDates[$day] = [
        'date' => $date,
        'display' => $day . ' ' . date('d/m', strtotime($date))
    ];
}

// Après l'initialisation de $weekDates, ajoutez:
$jours = array_keys($weekDates); // Extrait les jours (Lundi, Mardi, etc.) de $weekDates


// Nouvelles plages horaires simplifiées
$periodes = [
    '08:00-12:00', // Avant-midi
    '13:00-18:00'  // Après-midi
];

// Organiser les horaires par jour et période
$horaireGrid = [];
foreach ($jours as $jour) {
    $horaireGrid[$jour] = [];
    foreach ($periodes as $periode) {
        $horaireGrid[$jour][$periode] = [];
    }
}

// Remplir la grille avec les horaires
$processedIds = []; // Pour suivre les IDs déjà traités
foreach ($horaires as $h) {
    // Vérifier si cet horaire a déjà été traité
    if (in_array($h['idhoraire'], $processedIds)) {
        continue; // Ignorer ce doublon
    }
    
    $processedIds[] = $h['idhoraire']; // Marquer cet ID comme traité
    
    $heureDebut = substr($h['heure_debut'], 0, 5);
    $heureFin = substr($h['heure_fin'], 0, 5);
    
    // Si on a une date_cours spécifique, utiliser le jour correspondant à cette date
    if (!empty($h['date_cours'])) {
        // Convertir la date en jour de la semaine en français
        $jourMapping = [
            'Monday' => 'Lundi',
            'Tuesday' => 'Mardi',
            'Wednesday' => 'Mercredi',
            'Thursday' => 'Jeudi',
            'Friday' => 'Vendredi',
            'Saturday' => 'Samedi',
            'Sunday' => 'Dimanche'
        ];
        $jourSemaine = date('l', strtotime($h['date_cours']));
        $jour = $jourMapping[$jourSemaine];
    } else {
        $jour = $h['jour'];
    }
    
    // Déterminer si c'est un cours du matin ou de l'après-midi
    if ($heureDebut >= '08:00' && $heureDebut < '13:00') {
        $periode = '08:00-12:00';
    } else if ($heureDebut >= '13:00' && $heureDebut < '18:00') {
        $periode = '13:00-18:00';
    } else {
        continue; // Ignorer les horaires hors des plages définies
    }
    
    // Ajouter des propriétés pour identifier les cours de longue durée
    $dureeEnHeures = (strtotime("2000-01-01 $heureFin") - strtotime("2000-01-01 $heureDebut")) / 3600;
    $h['multi_period'] = $dureeEnHeures > 2;
    $h['full_day'] = $dureeEnHeures >= 4;
    $h['exact_hours'] = "$heureDebut - $heureFin"; // Ajout pour afficher les heures exactes
    
    // Ajouter l'horaire à la période correspondante
    if (isset($horaireGrid[$jour][$periode])) {
        $horaireGrid[$jour][$periode][] = $h;
    }
}



?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>GESTION DES HORAIRES</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Horaires</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row mb-3">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Sélection de la promotion</h5>
                        <form method="GET" action="" class="row g-3">
                            <input type="hidden" name="view" value="enseignement/horaires">
                            <div class="col-md-8">
                                <select name="promotion" class="form-select" onchange="this.form.submit()">
                                    <option value="">Sélectionnez une promotion</option>
                                    <?php foreach ($promotions as $p): ?>
                                        <option value="<?= $p['idpromotion'] ?>" <?= $idPromotion == $p['idpromotion'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($p['designationPromotion']) ?> (<?= $p['cycle'] ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <a data-bs-toggle="modal" data-bs-target="#addHoraireModal" class="btn btn-primary w-100">
                                    <i class="bi bi-plus-circle"></i> Ajouter un horaire
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Légende</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-primary text-white p-2 me-2" style="width: 20px; height: 20px;"></div>
                                    <span>Cours magistral</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-success text-white p-2 me-2" style="width: 20px; height: 20px;"></div>
                                    <span>Travaux dirigés</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-warning text-white p-2 me-2" style="width: 20px; height: 20px;"></div>
                                    <span>Travaux pratiques</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center mb-2">
                                    <div class="bg-danger text-white p-2 me-2" style="width: 20px; height: 20px;"></div>
                                    <span>Évaluation</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Navigation par semaine -->
        <div class="row mb-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <a href="?view=enseignement/horaires&promotion=<?= $idPromotion ?>&week=<?= $weekOffset - 1 ?>" class="btn btn-outline-primary">
                            <i class="bi bi-arrow-left"></i> Semaine précédente
                        </a>
                        
                        <h5 class="mb-0">
                            Semaine du <?= date('d/m/Y', strtotime($currentMonday)) ?> 
                            au <?= date('d/m/Y', strtotime($currentSunday)) ?>
                        </h5>
                        
                        <a href="?view=enseignement/horaires&promotion=<?= $idPromotion ?>&week=<?= $weekOffset + 1 ?>" class="btn btn-outline-primary">
                            Semaine suivante <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            Emploi du temps -
                            <?php 
                            $promotionName = '';
                            foreach ($promotions as $p) {
                                if ($p['idpromotion'] == $idPromotion) {
                                    $promotionName = $p['designationPromotion'];
                                    break;
                                }
                            }
                            echo htmlspecialchars($promotionName);
                            ?>
                            (<?= htmlspecialchars($currentYear['designation']) ?>)
                        </h5>
                        
                        <div class="table-responsive">
                            <table class="table table-bordered horaire-table">
                                <thead>
                                    <tr>
                                        <th style="width: 10%;">Horaire</th>
                                        <?php foreach ($weekDates as $jour => $dateInfo): ?>
                                            <th style="width: 15%;"><?= $dateInfo['display'] ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach ($periodes as $periode): 
                                        list($debut, $fin) = explode('-', $periode);
                                    ?>
                                        <tr>
                                            <td class="text-center fw-bold"><?= $debut ?><br>-<br><?= $fin ?></td>
                                            <?php foreach ($weekDates as $jour => $dateInfo): ?>
                                                <td class="horaire-cell <?= date('Y-m-d') == $dateInfo['date'] ? 'current-day' : '' ?>" data-date="<?= $dateInfo['date'] ?>">
                                                    <?php 
                                                    if (!empty($horaireGrid[$jour][$periode])):
                                                        // Trier les horaires par heure de début
                                                        usort($horaireGrid[$jour][$periode], function($a, $b) {
                                                            return strcmp($a['heure_debut'], $b['heure_debut']);
                                                        });
                                                        
                                                        foreach ($horaireGrid[$jour][$periode] as $h): 
                                                            // Déterminer la couleur en fonction du type de cours
                                                            $typeClass = 'primary'; // Cours magistral par défaut
                                                            if (isset($h['type_cours'])) {
                                                                if (strpos(strtolower($h['type_cours']), 'td') !== false) {
                                                                    $typeClass = 'success'; // Travaux dirigés
                                                                } elseif (strpos(strtolower($h['type_cours']), 'tp') !== false) {
                                                                    $typeClass = 'warning'; // Travaux pratiques
                                                                } elseif (strpos(strtolower($h['type_cours']), 'eval') !== false) {
                                                                    $typeClass = 'danger'; // Évaluation
                                                                }
                                                            }
                                                            
                                                            // Classe additionnelle pour les longues durées
                                                            $additionalClass = '';
                                                            if (isset($h['full_day']) && $h['full_day']) {
                                                                $additionalClass = 'full-day';
                                                            } elseif (isset($h['multi_period']) && $h['multi_period']) {
                                                                $additionalClass = 'multi-period';
                                                            }
                                                    ?>
                                                        <div class="horaire-item bg-<?= $typeClass ?> text-white p-2 mb-2 rounded <?= $additionalClass ?>">
                                                            <div class="d-flex justify-content-between align-items-center">
                                                                <span class="fw-bold"><?= htmlspecialchars($h['designationECUE']) ?></span>
                                                                <span class="badge bg-light text-dark"><?= $h['exact_hours'] ?></span>
                                                            </div>
                                                            <div>Salle: <?= htmlspecialchars($h['salle']) ?></div>
                                                            <div class="small"><?= htmlspecialchars($h['enseignant_nom']) ?></div>
                                                            <div class="d-flex justify-content-end mt-1">
                                                            <button class="btn btn-sm btn-light" onclick="editHoraire(<?= $h['idhoraire'] ?>)">
                                                                    <i class="bi bi-pencil"></i>
                                                                </button>
                                                                <button class="btn btn-sm btn-danger ms-1" onclick="deleteHoraire(<?= $h['idhoraire'] ?>)">
                                                                    <i class="bi bi-trash"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    <?php 
                                                        endforeach;
                                                    endif;
                                                    ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal pour ajouter un horaire -->
<div class="modal fade" id="addHoraireModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un horaire de cours</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="horaireForm" method="POST" action="controller/horaire_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="add_horaire">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    <input type="hidden" name="promotion" value="<?= $idPromotion ?>">
                    <input type="hidden" name="week" value="<?= $weekOffset ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="idECUE" class="form-label">Cours (ECUE)</label>
                            <select name="idECUE" id="idECUE" class="form-select" required>
                                <option value="">Sélectionnez un cours</option>
                                <?php foreach ($ecues as $e): ?>
                                    <option value="<?= $e['idECUE'] ?>"><?= htmlspecialchars($e['designationECUE']) ?> (<?= htmlspecialchars($e['designationUE']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un cours.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="jour" class="form-label">Jour</label>
                            <select name="jour" id="jour" class="form-select" required>
                                <option value="">Sélectionnez un jour</option>
                                <?php foreach ($jours as $jour): ?>
                                    <option value="<?= $jour ?>"><?= $jour ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un jour.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="date_cours" class="form-label">Date du cours</label>
                            <input type="date" name="date_cours" id="date_cours" class="form-control" required>
                            <div class="invalid-feedback">Veuillez sélectionner une date.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="type_cours" class="form-label">Type de cours</label>
                            <select name="type_cours" id="type_cours" class="form-select" required>
                                <option value="">Sélectionnez un type</option>
                                <option value="CM">Cours Magistral</option>
                                <option value="TD">Travaux Dirigés</option>
                                <option value="TP">Travaux Pratiques</option>
                                <option value="Evaluation">Évaluation</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un type de cours.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="salle" class="form-label">Salle</label>
                            <input type="text" name="salle" id="salle" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une salle.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="heure_debut" class="form-label">Heure de début</label>
                            <input type="time" name="heure_debut" id="heure_debut" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une heure de début.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="heure_fin" class="form-label">Heure de fin</label>
                            <input type="time" name="heure_fin" id="heure_fin" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une heure de fin.</div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour modifier un horaire -->
<div class="modal fade" id="editHoraireModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un horaire de cours</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editHoraireForm" method="POST" action="controller/horaire_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="edit_horaire">
                    <input type="hidden" name="idHoraire" id="edit_idHoraire">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    <input type="hidden" name="promotion" value="<?= $idPromotion ?>">
                    <input type="hidden" name="week" value="<?= $weekOffset ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_idECUE" class="form-label">Cours (ECUE)</label>
                            <select name="idECUE" id="edit_idECUE" class="form-select" required>
                                <option value="">Sélectionnez un cours</option>
                                <?php foreach ($ecues as $e): ?>
                                    <option value="<?= $e['idECUE'] ?>"><?= htmlspecialchars($e['designationECUE']) ?> (<?= htmlspecialchars($e['designationUE']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un cours.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_jour" class="form-label">Jour</label>
                            <select name="jour" id="edit_jour" class="form-select" required>
                                <option value="">Sélectionnez un jour</option>
                                <?php foreach ($jours as $jour): ?>
                                    <option value="<?= $jour ?>"><?= $jour ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un jour.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_date_cours" class="form-label">Date du cours</label>
                            <input type="date" name="date_cours" id="edit_date_cours" class="form-control" required>
                            <div class="invalid-feedback">Veuillez sélectionner une date.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_type_cours" class="form-label">Type de cours</label>
                            <select name="type_cours" id="edit_type_cours" class="form-select" required>
                                <option value="">Sélectionnez un type</option>
                                <option value="CM">Cours Magistral</option>
                                <option value="TD">Travaux Dirigés</option>
                                <option value="TP">Travaux Pratiques</option>
                                <option value="Evaluation">Évaluation</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un type de cours.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_salle" class="form-label">Salle</label>
                            <input type="text" name="salle" id="edit_salle" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une salle.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_heure_debut" class="form-label">Heure de début</label>
                            <input type="time" name="heure_debut" id="edit_heure_debut" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une heure de début.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_heure_fin" class="form-label">Heure de fin</label>
                            <input type="time" name="heure_fin" id="edit_heure_fin" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une heure de fin.</div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
// Validation des heures
document.addEventListener('DOMContentLoaded', function() {
    const heureDebut = document.getElementById('heure_debut');
    const heureFin = document.getElementById('heure_fin');
    const editHeureDebut = document.getElementById('edit_heure_debut');
    const editHeureFin = document.getElementById('edit_heure_fin');
    
    function validateHoraire() {
        if (heureDebut.value && heureFin.value) {
            if (heureDebut.value >= heureFin.value) {
                heureFin.setCustomValidity('L\'heure de fin doit être postérieure à l\'heure de début');
            } else {
                heureFin.setCustomValidity('');
            }
        }
    }
    
    function validateEditHoraire() {
        if (editHeureDebut.value && editHeureFin.value) {
            if (editHeureDebut.value >= editHeureFin.value) {
                editHeureFin.setCustomValidity('L\'heure de fin doit être postérieure à l\'heure de début');
            } else {
                editHeureFin.setCustomValidity('');
            }
        }
    }
    
    heureDebut.addEventListener('change', validateHoraire);
    heureFin.addEventListener('change', validateHoraire);
    editHeureDebut.addEventListener('change', validateEditHoraire);
    editHeureFin.addEventListener('change', validateEditHoraire);
});

// Fonction pour éditer un horaire
function editHoraire(idHoraire) {
    // Charger les détails de l'horaire via AJAX
    fetch(`controller/get_horaire.php?id=${idHoraire}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: data.error
                });
                return;
            }
            
            // Remplir le formulaire avec les données
            document.getElementById('edit_idHoraire').value = data.idhoraire;
            document.getElementById('edit_idECUE').value = data.idECUE;
            document.getElementById('edit_jour').value = data.jour;
            document.getElementById('edit_type_cours').value = data.type_cours;
            document.getElementById('edit_heure_debut').value = data.heure_debut;
            document.getElementById('edit_heure_fin').value = data.heure_fin;
            document.getElementById('edit_salle').value = data.salle;
            
            // Remplir le champ date si disponible
            if (data.date_cours) {
                document.getElementById('edit_date_cours').value = data.date_cours;
            } else {
                // Si date_cours n'est pas disponible, utiliser la date d'aujourd'hui
                document.getElementById('edit_date_cours').value = new Date().toISOString().split('T')[0];
            }
            
            // Afficher le modal
            new bootstrap.Modal(document.getElementById('editHoraireModal')).show();
        })
        .catch(error => {
            console.error('Erreur:', error);
            Swal.fire({
                icon: 'error',
                title: 'Erreur',
                text: 'Une erreur est survenue lors de la récupération des détails de l\'horaire.'
            });
        });
}


// Fonction pour supprimer un horaire
function deleteHoraire(idHoraire) {
    Swal.fire({
        title: 'Êtes-vous sûr?',
        text: "Cette action ne peut pas être annulée!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, supprimer!',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `controller/horaire_controller.php?action=delete_horaire&id=${idHoraire}&idAnneeAcad=<?= $currentYear['idannee_acad'] ?>&promotion=<?= $idPromotion ?>`;
        }
    });
}




// Ajouter ce script à la section JavaScript existante
document.addEventListener('DOMContentLoaded', function() {
    // Configuration des clics sur le calendrier
    setupCalendarCellClicks();

    // Récupération des éléments du formulaire d'ajout
    const jourSelect = document.getElementById('jour');
    const dateInput = document.getElementById('date_cours');
    
    // Récupération des éléments du formulaire de modification
    const editJourSelect = document.getElementById('edit_jour');
    const editDateInput = document.getElementById('edit_date_cours');
    
    // Mapping des jours français vers index (0 = Lundi, 6 = Dimanche)
    const jourMapping = {
        'Lundi': 0,
        'Mardi': 1,
        'Mercredi': 2,
        'Jeudi': 3,
        'Vendredi': 4,
        'Samedi': 5,
        'Dimanche': 6
    };
    
    // Mapping inverse (pour convertir index en jour)
    const indexMapping = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
    
    // Fonction pour mettre à jour la date en fonction du jour sélectionné
    function updateDateFromDay(jourSelectElement, dateInputElement) {
        if (!jourSelectElement.value) return;
        
        // Trouver le lundi de la semaine courante
        const currentDate = new Date();
        const currentDay = currentDate.getDay(); // 0 = Dimanche, 1 = Lundi, etc.
        const daysToMonday = currentDay === 0 ? 6 : currentDay - 1;
        const mondayDate = new Date(currentDate);
        mondayDate.setDate(currentDate.getDate() - daysToMonday);
        
        // Calculer la date correspondant au jour sélectionné
        const selectedJourIndex = jourMapping[jourSelectElement.value];
        const targetDate = new Date(mondayDate);
        targetDate.setDate(mondayDate.getDate() + selectedJourIndex);
        
        // Formater la date au format YYYY-MM-DD pour l'input date
        const formattedDate = targetDate.toISOString().split('T')[0];
        dateInputElement.value = formattedDate;
    }
    
    // Fonction pour mettre à jour le jour en fonction de la date sélectionnée
    function updateDayFromDate(dateInputElement, jourSelectElement) {
        if (!dateInputElement.value) return;
        
        const selectedDate = new Date(dateInputElement.value);
        const dayOfWeek = selectedDate.getDay(); // 0 = Dimanche, 1 = Lundi, etc.
        const adjustedIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
        jourSelectElement.value = indexMapping[adjustedIndex];
    }
    
    // Appliquer les événements pour le formulaire d'ajout
    if (jourSelect && dateInput) {
        jourSelect.addEventListener('change', function() {
            updateDateFromDay(jourSelect, dateInput);
        });
        
        dateInput.addEventListener('change', function() {
            updateDayFromDate(dateInput, jourSelect);
        });
        
        // Initialiser la date avec le jour déjà sélectionné (si c'est le cas)
        if (jourSelect.value) {
            updateDateFromDay(jourSelect, dateInput);
        }
    }
    
    // Appliquer les événements pour le formulaire de modification
    if (editJourSelect && editDateInput) {
        editJourSelect.addEventListener('change', function() {
            updateDateFromDay(editJourSelect, editDateInput);
        });
        
        editDateInput.addEventListener('change', function() {
            updateDayFromDate(editDateInput, editJourSelect);
        });
    }
    
    // Initialiser la date du modal d'ajout avec la date sélectionnée dans le calendrier
    const currentDate = new Date();
    dateInput.value = currentDate.toISOString().split('T')[0];
    updateDayFromDate(dateInput, jourSelect);
});


// Fonction pour permettre d'ajouter un horaire en cliquant sur une cellule
function setupCalendarCellClicks() {
    const cells = document.querySelectorAll('.horaire-cell');
    cells.forEach(cell => {
        cell.addEventListener('click', function(e) {
            // Ne déclencher que pour les clics directs sur la cellule (pas sur les horaires existants)
            if (e.target === cell || e.target.classList.contains('add-placeholder')) {
                const date = cell.getAttribute('data-date');
                if (date) {
                    // Ouvrir le modal d'ajout
                    const modal = new bootstrap.Modal(document.getElementById('addHoraireModal'));
                    
                    // Mettre à jour la date
                    document.getElementById('date_cours').value = date;
                    
                    // Mettre à jour le jour correspondant
                    updateDayFromDate(document.getElementById('date_cours'), document.getElementById('jour'));
                    
                    modal.show();
                }
            }
        });
    });
}

</script>

<style>
.horaire-table th, .horaire-table td {
    vertical-align: middle;
    padding: 0.5rem;
}

.horaire-table th {
    text-align: center;
    background-color: #f8f9fa;
}

.horaire-item {
    font-size: 0.85rem;
}

/* Styles pour les grandes périodes */
.horaire-cell {
    position: relative;
    min-height: 200px;
    padding: 10px;
    vertical-align: top;
}

/* Badge pour les heures exactes */
.horaire-item .badge {
    font-size: 0.75rem;
}

/* Espacement entre les cartes d'horaires */
.horaire-item {
    margin-bottom: 10px;
}

/* Indicateurs visuels pour les cours multi-périodes */
.horaire-item.multi-period {
    border-left: 4px solid #ffcc00;
}

.horaire-item.full-day {
    border-left: 4px solid #ff9900;
    font-weight: bold;
}

/* Pour mieux différencier les cases matin/après-midi */
.horaire-table tr:nth-child(odd) td:not(:first-child) {
    background-color: rgba(0, 0, 0, 0.02);
}

/* Afficher les heures de début et de fin */
.horaire-item .badge {
    background-color: rgba(255, 255, 255, 0.8) !important;
    font-weight: normal;
}

/* Styles pour indiquer le jour actuel */
.current-day {
    background-color: rgba(0, 123, 255, 0.1);
}

</style>

<?php include "./views/include/footer.php"; ?>

