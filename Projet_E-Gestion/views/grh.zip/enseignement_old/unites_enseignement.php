<?php
include "./views/include/header.php";
$universite = new Universite();

$search = isset($_GET['search']) ? $_GET['search'] : '';
$selectedSection = isset($_GET['section']) ? intval($_GET['section']) : 0;

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Récupérer toutes les sections accessibles à l'utilisateur
$sections = [];
if ($_SESSION['idRole'] == 1) { // Si administrateur
    $sections = $universite->getSections();
} else {
    // Pour les autres utilisateurs, vérifier les sections associées
    $userSections = $universite->getUserSections($_SESSION['id']);
    foreach ($userSections as $sectionId) {
        $sectionData = $universite->getSectionById($sectionId);
        if ($sectionData) {
            $sections[] = $sectionData;
        }
    }
}

// Récupérer toutes les UEs pour l'année en cours
$ues = [];
if (!empty($sections)) {
    $sectionIds = array_column($sections, 'idsection');
    
    // Si c'est un administrateur et aucune section n'est sélectionnée, récupérer toutes les UEs
    if ($_SESSION['idRole'] == 1 && $selectedSection == 0) {
        $ues = $universite->getAllUEs($currentYear['idannee_acad'], $search);
    } 
    // Si une section spécifique est sélectionnée
    elseif ($selectedSection > 0 && in_array($selectedSection, $sectionIds)) {
        $ues = $universite->getAllUEsBySection($selectedSection, $currentYear['idannee_acad'], $search);
    } 
    // Sinon, utiliser la première section accessible
    else {
        $ues = $universite->getAllUEsBySection($sectionIds[0], $currentYear['idannee_acad'], $search);
    }
}
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>GESTION DES UNITÉS D'ENSEIGNEMENT</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Unités d'Enseignement</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table des UEs -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Liste des Unités d'Enseignement
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createUEModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter une UE
                                        </a>
                                        | <a data-bs-toggle="modal" data-bs-target="#importUEModal" class="btnPage">
                                            <i class="bi bi-upload"></i> Importer des UEs
                                        </a>
                                    </span>
                                </h5>

                                <form method="GET" action="" class="mb-3">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="input-group">
                                                <input type="hidden" name="view" value="enseignement/unites_enseignement">
                                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher une UE...">
                                                <button type="submit" class="btn btn-primary">Rechercher</button>
                                            </div>
                                        </div>
                                        <?php if ($_SESSION['idRole'] == 1): ?>
                                        <div class="col-md-6">
                                            <select name="section" class="form-select" onchange="this.form.submit()">
                                                <option value="0">Toutes les sections</option>
                                                <?php foreach ($sections as $section): ?>
                                                    <option value="<?= $section['idsection'] ?>" <?= $selectedSection == $section['idsection'] ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($section['designationSection']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </form>

                                <!-- Table des UEs -->
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Semestre</th>
                                            <th scope="col">Promotion</th>
                                            <th scope="col">Section</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($ues as $ue) {
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$ue['codeUE']}</td>
                                                <td>{$ue['designationUE']}</td>
                                                <td>{$ue['numeroSemestre']}</td>
                                                <td>{$ue['designationPromotion']}</td>
                                                <td>{$ue['designationSection']}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='openEditUEModal({$ue['idUE']}, \"{$ue['codeUE']}\", \"{$ue['designationUE']}\", {$ue['semestre_idsemestre']})'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='deleteUE({$ue['idUE']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-primary' onclick='window.location.href=\"?view=enseignement/ecues&ue={$ue['idUE']}\"'>
                                                        <i class='bi bi-book'></i> ECUEs
                                                    </button>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }

                                        if (empty($ues)) {
                                            echo "<tr><td colspan='7' class='text-center'>Aucune unité d'enseignement trouvée</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>


<!-- Modal pour ajouter une UE -->
<div class="modal fade" id="createUEModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Unité d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <form id="ueForm" method="POST" action="controller/ue_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="promotion" class="form-label">Promotion</label>
                            <select name="promotion" id="promotion" class="form-select" required onchange="loadSemestres(this.value)">
                                <option value="">Sélectionnez une promotion</option>
                                <?php 
                                foreach ($sections as $section) {
                                    $promotions = $universite->getPromotionsBySection($section['idsection'], $currentYear['idannee_acad']);
                                    if (!empty($promotions)) {
                                        echo "<optgroup label='{$section['designationSection']}'>";
                                        foreach ($promotions as $promotion) {
                                            echo "<option value='{$promotion['idpromotion']}'>{$promotion['designationPromotion']} ({$promotion['cycle']})</option>";
                                        }
                                        echo "</optgroup>";
                                    }
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="semestre" class="form-label">Semestre</label>
                            <select name="semestre" id="semestre" class="form-select" required>
                                <option value="">Sélectionnez d'abord une promotion</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un semestre.</div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="code" class="form-label">Code UE</label>
                            <input type="text" name="code" id="code" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer un code.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designation" class="form-label">Désignation</label>
                            <input type="text" name="designation" id="designation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <!-- [garder le reste du formulaire inchangé] -->
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addUEBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une UE -->
<div class="modal fade" id="editUEModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Unité d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editUEForm" method="POST" action="controller/ue_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="idUE" id="edit_idUE">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_code" class="form-label">Code UE</label>
                            <input type="text" name="code" id="edit_code" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer un code.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_designation" class="form-label">Désignation</label>
                            <input type="text" name="designation" id="edit_designation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_description" class="form-label">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_semestre" class="form-label">Semestre</label>
                            <select name="semestre" id="edit_semestre" class="form-select" required>
                                <?php
                                $allSemestres = $universite->getAllSemestres();
                                foreach ($allSemestres as $sem) {
                                    echo "<option value='{$sem['idsemestre']}'>{$sem['numeroSemestre']} - {$sem['designationPromotion']} ({$sem['designationSection']})</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un semestre.</div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editUEBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour importer des UEs -->
<div class="modal fade" id="importUEModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des Unités d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="importForm" method="POST" action="controller/ue_controller.php" class="needs-validation" enctype="multipart/form-data" novalidate>
                    <input type="hidden" name="action" value="import">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="promotion_import" class="form-label">Promotion</label>
                            <select name="promotion_import" id="promotion_import" class="form-select" required onchange="loadSemestresImport(this.value)">
                                <option value="">Sélectionnez une promotion</option>
                                <?php 
                                foreach ($sections as $section) {
                                    $promotions = $universite->getPromotionsBySection($section['idsection'], $currentYear['idannee_acad']);
                                    if (!empty($promotions)) {
                                        echo "<optgroup label='{$section['designationSection']}'>";
                                        foreach ($promotions as $promotion) {
                                            echo "<option value='{$promotion['idpromotion']}'>{$promotion['designationPromotion']} ({$promotion['cycle']})</option>";
                                        }
                                        echo "</optgroup>";
                                    }
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="semestre_import" class="form-label">Semestre</label>
                            <select name="semestre_import" id="semestre_import" class="form-select" required>
                                <option value="">Sélectionnez d'abord une promotion</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un semestre.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="fichier_import" class="form-label">Fichier Excel/CSV</label>
                            <input type="file" name="fichier_import" id="fichier_import" class="form-control" required accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                            <div class="invalid-feedback">Veuillez sélectionner un fichier.</div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Le fichier doit contenir les colonnes suivantes: Code UE, Désignation, Description (optionnelle).
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="colonne_code" class="form-label">Colonne Code UE</label>
                            <input type="text" name="colonne_code" id="colonne_code" class="form-control" value="A" required>
                            <div class="invalid-feedback">Veuillez indiquer la colonne.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="colonne_designation" class="form-label">Colonne Désignation</label>
                            <input type="text" name="colonne_designation" id="colonne_designation" class="form-control" value="B" required>
                            <div class="invalid-feedback">Veuillez indiquer la colonne.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="colonne_description" class="form-label">Colonne Description (optionnelle)</label>
                            <input type="text" name="colonne_description" id="colonne_description" class="form-control" value="C">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="skip_header" name="skip_header" value="1" checked>
                                <label class="form-check-label" for="skip_header">
                                    Ignorer la première ligne (en-têtes)
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-upload"></i> Importer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
// Fonction pour charger les semestres en fonction de la promotion
function loadSemestres(promotionId) {
    if (!promotionId) {
        document.getElementById('semestre').innerHTML = '<option value="">Sélectionnez d\'abord une promotion</option>';
        return;
    }
    
    fetch(`controller/get_semestres.php?promotion=${promotionId}`)
        .then(response => response.json())
        .then(data => {
            let options = '<option value="">Sélectionnez un semestre</option>';
            data.forEach(semestre => {
                options += `<option value="${semestre.idsemestre}">${semestre.numeroSemestre}</option>`;
            });
            document.getElementById('semestre').innerHTML = options;
        })
        .catch(error => console.error('Erreur:', error));
}

// Fonction pour charger les semestres pour l'importation
function loadSemestresImport(promotionId) {
    if (!promotionId) {
        document.getElementById('semestre_import').innerHTML = '<option value="">Sélectionnez d\'abord une promotion</option>';
        return;
    }
    
    fetch(`controller/get_semestres.php?promotion=${promotionId}`)
        .then(response => response.json())
        .then(data => {
            let options = '<option value="">Sélectionnez un semestre</option>';
            data.forEach(semestre => {
                options += `<option value="${semestre.idsemestre}">${semestre.numeroSemestre}</option>`;
            });
            document.getElementById('semestre_import').innerHTML = options;
        })
        .catch(error => console.error('Erreur:', error));
}

// Fonction pour ouvrir le modal de modification d'une UE
function openEditUEModal(idUE, code, designation, semestreId) {
    document.getElementById('edit_idUE').value = idUE;
    document.getElementById('edit_code').value = code;
    document.getElementById('edit_designation').value = designation;
    document.getElementById('edit_semestre').value = semestreId;
    
    // Récupérer la description de l'UE par une requête AJAX
    fetch(`controller/get_ue_details.php?id=${idUE}`)
        .then(response => response.json())
        .then(data => {
            if (data.description) {
                document.getElementById('edit_description').value = data.description;
            }
        })
        .catch(error => console.error('Erreur:', error));
    
    new bootstrap.Modal(document.getElementById('editUEModal')).show();
}

// Fonction pour supprimer une UE
function deleteUE(idUE) {
    Swal.fire({
        title: 'Êtes-vous sûr?',
        text: "Cette action supprimera l'unité d'enseignement et ne peut pas être annulée!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, supprimer!',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `controller/ue_controller.php?action=delete&id=${idUE}`;
        }
    });
}


// Validation des formulaires Bootstrap
(function () {
    'use strict'
    
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                
                form.classList.add('was-validated')
            }, false)
        })
})()
</script>

<?php include "./views/include/footer.php"; ?>
<div
