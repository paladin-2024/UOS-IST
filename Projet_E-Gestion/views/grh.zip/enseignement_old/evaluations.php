<?php
include "./views/include/header.php";
$universite = new Universite();
$ecue = new Ecue();
$agent = new Agent();
$enseignant = new Enseignant();

// Vérifier que l'utilisateur est connecté et est un enseignant
$userId = $_SESSION['id'] ?? 0;

// Vérifier si l'utilisateur est un enseignant
if (!$userId || !$enseignant->isUserEnseignant($userId)) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Accès refusé',
            text: 'Vous devez être connecté en tant qu\'enseignant pour accéder à cette page.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

// Récupérer l'ID de l'agent (enseignant)
$idEnseignant = $enseignant->getAgentIdByUserId($userId);
if (!$idEnseignant) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'Impossible de récupérer les informations de l\'enseignant.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

// Récupérer l'ID de l'ECUE depuis l'URL
$idEcue = isset($_GET['ecue']) ? intval($_GET['ecue']) : 0;
if ($idEcue <= 0) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'ECUE non spécifié ou invalide.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Vérifier si l'enseignant est autorisé à accéder à cet ECUE
$isAuthorized = $enseignant->isEnseignantAssignedToEcue($idEnseignant, $idEcue, $currentYear['idannee_acad']);
if (!$isAuthorized) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Accès refusé',
            text: 'Vous n\'êtes pas autorisé à accéder aux évaluations de ce cours.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer les détails de l'ECUE
$ecueDetails = $ecue->getEcueById($idEcue);
if (!$ecueDetails) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'ECUE non trouvé.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer les sessions (première, deuxième)
$sessions = $universite->getSessions();

// Récupérer les types d'évaluation (contrôle continu, examen, etc.)
$typesEvaluation = $ecue->getEvaluationTypes();

// Récupérer les évaluations existantes pour cet ECUE
$evaluations = $ecue->getEvaluationsByEcue($idEcue, $currentYear['idannee_acad']);

// Récupérer la liste des étudiants inscrits à ce cours
$etudiants = $ecue->getStudentsByEcue($idEcue, $currentYear['idannee_acad']);

// Récupérer la configuration des moyennes pour cet ECUE
$configMoyenne = $ecue->getConfigurationMoyenne($idEcue, $currentYear['idannee_acad']);
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>ÉVALUATIONS - <?= htmlspecialchars($ecueDetails['designationECUE']) ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?view=dashboard">Accueil</a></li>
                <li class="breadcrumb-item"><a href="?view=recherche/mes_cours">Mes Cours</a></li>
                <li class="breadcrumb-item active">Évaluations</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <!-- Informations du cours -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Informations générales</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Cours:</strong> <?= htmlspecialchars($ecueDetails['designationECUE']) ?></p>
                                <p><strong>UE:</strong> <?= htmlspecialchars($ecueDetails['designationUE']) ?></p>
                                <p><strong>Semestre:</strong> <?= htmlspecialchars($ecueDetails['numeroSemestre']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Promotion:</strong> <?= htmlspecialchars($ecueDetails['designationPromotion']) ?></p>
                                <p><strong>Année académique:</strong> <?= htmlspecialchars($currentYear['designation']) ?></p>
                                <p><strong>Volume horaire:</strong> CMI: <?= $ecueDetails['CMI'] ?>h | TD: <?= $ecueDetails['TD'] ?>h | TP: <?= $ecueDetails['TP'] ?>h</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Onglets de navigation -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-bordered" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="evaluations-tab" data-bs-toggle="tab" data-bs-target="#evaluations-content" type="button" role="tab" aria-selected="true">
                                    <i class="bi bi-list-check me-1"></i> Liste des évaluations
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="notes-tab" data-bs-toggle="tab" data-bs-target="#notes-content" type="button" role="tab" aria-selected="false">
                                    <i class="bi bi-file-earmark-spreadsheet me-1"></i> Grille de notes
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="config-tab" data-bs-toggle="tab" data-bs-target="#config-content" type="button" role="tab" aria-selected="false">
                                    <i class="bi bi-gear me-1"></i> Configuration
                                </button>
                            </li>
                        </ul>
                        
                        <div class="tab-content pt-3">
                            <!-- Onglet Liste des évaluations -->
                            <div class="tab-pane fade show active" id="evaluations-content" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5>Liste des évaluations</h5>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEvaluationModal">
                                        <i class="bi bi-plus-circle"></i> Ajouter une évaluation
                                    </button>
                                </div>
                                
                                <?php if (empty($evaluations)): ?>
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-1"></i> Aucune évaluation n'a encore été créée pour ce cours.
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Titre</th>
                                                    <th>Type</th>
                                                    <th>Date</th>
                                                    <th>Session</th>
                                                    <th>Pondération</th>
                                                    <th>Statut</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($evaluations as $eval): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($eval['titre']) ?></td>
                                                        <td><?= htmlspecialchars($eval['designationT']) ?></td>
                                                        <td><?= date('d/m/Y', strtotime($eval['date_evaluation'])) ?></td>
                                                        <td><?= htmlspecialchars($eval['designSession']) ?></td>
                                                        <td><?= $eval['ponderation'] ?></td>
                                                        <td>
                                                            <?php if ($eval['est_visible']): ?>
                                                                <span class="badge bg-success">Visible</span>
                                                            <?php else: ?>
                                                                <span class="badge bg-secondary">Non visible</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <button class="btn btn-sm btn-primary" onclick="openEnterGradesModal(<?= $eval['idevaluation'] ?>, '<?= addslashes($eval['titre']) ?>')">
                                                                <i class="bi bi-pencil-square"></i> Saisir les notes
                                                            </button>
                                                            <button class="btn btn-sm btn-warning" onclick="openEditEvaluationModal(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-pencil"></i> Modifier
                                                            </button>
                                                            <button class="btn btn-sm btn-danger" onclick="confirmDeleteEvaluation(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-trash"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-success" onclick="exportNotesEvaluation(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-file-excel"></i> Exporter
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Onglet Grille de notes -->
                            <div class="tab-pane fade" id="notes-content" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5>Grille des notes</h5>
                                    <div>
                                        <button class="btn btn-success" onclick="exportAllNotes()">
                                            <i class="bi bi-file-excel"></i> Exporter toutes les notes
                                        </button>
                                    </div>
                                </div>
                                
                                <?php if (empty($evaluations) || empty($etudiants)): ?>
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-1"></i> 
                                        <?php if (empty($evaluations)): ?>
                                            Aucune évaluation n'a encore été créée pour ce cours.
                                        <?php else: ?>
                                            Aucun étudiant inscrit à ce cours.
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                            <tr>
                                                    <th rowspan="2" style="vertical-align: middle;">N°</th>
                                                    <th rowspan="2" style="vertical-align: middle;">Matricule</th>
                                                    <th rowspan="2" style="vertical-align: middle;">Nom de l'étudiant</th>
                                                    <?php
                                                    // Regrouper les évaluations par session
                                                    $evalsBySessions = [];
                                                    foreach ($evaluations as $eval) {
                                                        $sessionId = $eval['session_idsession'];
                                                        if (!isset($evalsBySessions[$sessionId])) {
                                                            $evalsBySessions[$sessionId] = [
                                                                'session' => $eval['designSession'],
                                                                'evals' => []
                                                            ];
                                                        }
                                                        $evalsBySessions[$sessionId]['evals'][] = $eval;
                                                    }
                                                    
                                                    // Afficher les en-têtes des sessions et le nombre de colonnes pour chaque session
                                                    foreach ($evalsBySessions as $sessionId => $sessionData): 
                                                        $colCount = count($sessionData['evals']);
                                                    ?>
                                                        <th colspan="<?= $colCount + 1 ?>" class="text-center">
                                                            <?= htmlspecialchars($sessionData['session']) ?>
                                                        </th>
                                                    <?php endforeach; ?>
                                                </tr>
                                                <tr>
                                                    <?php 
                                                    // Afficher les en-têtes des évaluations pour chaque session
                                                    foreach ($evalsBySessions as $sessionId => $sessionData): 
                                                        foreach ($sessionData['evals'] as $eval): 
                                                    ?>
                                                        <th class="text-center">
                                                            <?= htmlspecialchars($eval['titre']) ?>
                                                            <br><small>(<?= $eval['ponderation'] ?>)</small>
                                                        </th>
                                                    <?php 
                                                        endforeach; 
                                                        // Ajouter une colonne pour la moyenne de la session
                                                    ?>
                                                        <th class="text-center bg-light">Moy. <?= htmlspecialchars($sessionData['session']) ?></th>
                                                    <?php endforeach; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $i = 1;
                                                foreach ($etudiants as $etudiant): 
                                                    // Récupérer les notes de l'étudiant pour toutes les évaluations
                                                    $notes = $ecue->getStudentGrades($etudiant['idetudiant'], $idEcue, $currentYear['idannee_acad']);
                                                ?>
                                                    <tr>
                                                        <td><?= $i++ ?></td>
                                                        <td><?= htmlspecialchars($etudiant['matricule']) ?></td>
                                                        <td><?= htmlspecialchars($etudiant['noms']) ?></td>
                                                        <?php 
                                                        // Afficher les notes de l'étudiant pour chaque évaluation
                                                        foreach ($evalsBySessions as $sessionId => $sessionData): 
                                                            $sessionTotal = 0;
                                                            $coeffTotal = 0;
                                                            
                                                            foreach ($sessionData['evals'] as $eval): 
                                                                $note = null;
                                                                foreach ($notes as $n) {
                                                                    if ($n['idevaluation'] == $eval['idevaluation']) {
                                                                        $note = $n['coteObtenu'];
                                                                        $sessionTotal += $note * $eval['ponderation'];
                                                                        $coeffTotal += $eval['ponderation'];
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                // Calculer la classe CSS en fonction de la note
                                                                $noteClass = '';
                                                                if ($note !== null) {
                                                                    if ($note < 10) {
                                                                        $noteClass = 'text-danger';
                                                                    } elseif ($note >= 16) {
                                                                        $noteClass = 'text-success';
                                                                    }
                                                                }
                                                        ?>
                                                            <td class="text-center <?= $noteClass ?>">
                                                                <?= $note !== null ? number_format($note, 2) : '-' ?>
                                                            </td>
                                                        <?php 
                                                            endforeach;
                                                            
                                                            // Calculer et afficher la moyenne de la session
                                                            $moyenneSession = $coeffTotal > 0 ? $sessionTotal / $coeffTotal : null;
                                                            $moyenneClass = '';
                                                            if ($moyenneSession !== null) {
                                                                if ($moyenneSession < 10) {
                                                                    $moyenneClass = 'text-danger';
                                                                } elseif ($moyenneSession >= 16) {
                                                                    $moyenneClass = 'text-success';
                                                                }
                                                            }
                                                        ?>
                                                            <td class="text-center bg-light <?= $moyenneClass ?>">
                                                                <?= $moyenneSession !== null ? number_format($moyenneSession, 2) : '-' ?>
                                                            </td>
                                                        <?php endforeach; ?>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Onglet Configuration -->
                            <div class="tab-pane fade" id="config-content" role="tabpanel">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Configuration des moyennes</h5>
                                        <form id="configForm" action="controller/evaluation_controller.php" method="POST">
                                            <input type="hidden" name="action" value="save_config">
                                            <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                                            <input type="hidden" name="annee_acad_id" value="<?= $currentYear['idannee_acad'] ?>">
                                            
                                            <div class="alert alert-info">
                                                <i class="bi bi-info-circle me-1"></i>
                                                Cette configuration sera utilisée pour calculer les moyennes des étudiants pour ce cours.
                                            </div>
                                            
                                            <?php foreach ($sessions as $session): ?>
                                                <div class="card mb-3">
                                                    <div class="card-header bg-light">
                                                        <h5 class="mb-0">Session: <?= htmlspecialchars($session['designSession']) ?></h5>
                                                    </div>
                                                    <div class="card-body">
                                                        <input type="hidden" name="session_ids[]" value="<?= $session['idsession'] ?>">
                                                        
                                                        <div class="row mb-3">
                                                            <div class="col-md-6">
                                                                <label class="form-label">Pondération Contrôle Continu (%)</label>
                                                                <input type="number" class="form-control" name="ponderation_cc[<?= $session['idsession'] ?>]" 
                                                                       value="<?= isset($configMoyenne[$session['idsession']]) ? $configMoyenne[$session['idsession']]['ponderation_cc'] * 100 : 40 ?>"
                                                                       min="0" max="100" step="5" required>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label">Pondération Examen (%)</label>
                                                                <input type="number" class="form-control" name="ponderation_ex[<?= $session['idsession'] ?>]" 
                                                                       value="<?= isset($configMoyenne[$session['idsession']]) ? $configMoyenne[$session['idsession']]['ponderation_ex'] * 100 : 60 ?>"
                                                                       min="0" max="100" step="5" required>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <label class="form-label">Formule Contrôle Continu</label>
                                                                <textarea class="form-control" name="formule_cc[<?= $session['idsession'] ?>]" rows="3" placeholder="Ex: (CC1 + CC2 + CC3) / 3"><?= isset($configMoyenne[$session['idsession']]) ? $configMoyenne[$session['idsession']]['formule_cc'] : '' ?></textarea>
                                                                <div class="form-text">
                                                                    Utilisez les codes des évaluations (CC1, CC2, TP1, etc.) dans la formule.
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <label class="form-label">Formule Examen</label>
                                                                <textarea class="form-control" name="formule_ex[<?= $session['idsession'] ?>]" rows="3" placeholder="Ex: EXAM"><?= isset($configMoyenne[$session['idsession']]) ? $configMoyenne[$session['idsession']]['formule_ex'] : '' ?></textarea>
                                                                <div class="form-text">
                                                                    Utilisez les codes des évaluations (EXAMEN, RATTRAPAGE, etc.) dans la formule.
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                            
                                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="bi bi-save"></i> Enregistrer la configuration
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal pour ajouter une évaluation -->
<div class="modal fade" id="addEvaluationModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addEvaluationForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="add_evaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    <input type="hidden" name="idUser" value="<?= $userId ?>">
                    <input type="hidden" name="annee_acad_id" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <div class="mb-3">
                        <label for="titre" class="form-label">Titre de l'évaluation</label>
                        <input type="text" class="form-control" id="titre" name="titre" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description (optionnelle)</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="date_evaluation" class="form-label">Date de l'évaluation</label>
                            <input type="date" class="form-control" id="date_evaluation" name="date_evaluation" required>
                        </div>
                        <div class="col-md-6">
                            <label for="idType" class="form-label">Type d'évaluation</label>
                            <select class="form-select" id="idType" name="idType" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($typesEvaluation as $type): ?>
                                    <option value="<?= $type['idType'] ?>"><?= htmlspecialchars($type['designationT']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="session_idsession" class="form-label">Session</label>
                            <select class="form-select" id="session_idsession" name="session_idsession" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($sessions as $session): ?>
                                    <option value="<?= $session['idsession'] ?>"><?= htmlspecialchars($session['designSession']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="ponderation" class="form-label">Pondération</label>
                            <input type="number" class="form-control" id="ponderation" name="ponderation" value="1" min="0.1" max="10" step="0.1" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="est_visible" name="est_visible" value="1">
                        <label class="form-check-label" for="est_visible">Rendre visible pour les étudiants</label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une évaluation -->
<div class="modal fade" id="editEvaluationModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editEvaluationForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="update_evaluation">
                    <input type="hidden" name="idevaluation" id="edit_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    
                    <div class="mb-3">
                        <label for="edit_titre" class="form-label">Titre de l'évaluation</label>
                        <input type="text" class="form-control" id="edit_titre" name="titre" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description (optionnelle)</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_date_evaluation" class="form-label">Date de l'évaluation</label>
                            <input type="date" class="form-control" id="edit_date_evaluation" name="date_evaluation" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_idType" class="form-label">Type d'évaluation</label>
                            <select class="form-select" id="edit_idType" name="idType" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($typesEvaluation as $type): ?>
                                    <option value="<?= $type['idType'] ?>"><?= htmlspecialchars($type['designationT']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_session_idsession" class="form-label">Session</label>
                            <select class="form-select" id="edit_session_idsession" name="session_idsession" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($sessions as $session): ?>
                                    <option value="<?= $session['idsession'] ?>"><?= htmlspecialchars($session['designSession']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_ponderation" class="form-label">Pondération</label>
                            <input type="number" class="form-control" id="edit_ponderation" name="ponderation" min="0.1" max="10" step="0.1" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="edit_est_visible" name="est_visible" value="1">
                        <label class="form-check-label" for="edit_est_visible">Rendre visible pour les étudiants</label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Mettre à jour</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour importer des notes depuis Excel -->
<div class="modal fade" id="importGradesModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des notes depuis Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="importGradesForm" action="controller/import_grades.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="idevaluation" id="import_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-1"></i>
                        Veuillez d'abord exporter le modèle Excel, remplir les notes, puis le réimporter ici.
                        <br>
                        <strong>Important :</strong> Ne modifiez pas la structure du fichier Excel.
                    </div>
                    
                    <div class="mb-3">
                        <label for="excelFile" class="form-label">Fichier Excel (*.xlsx)</label>
                        <input type="file" class="form-control" id="excelFile" name="excelFile" accept=".xlsx" required>
                        <div class="form-text">Seuls les fichiers Excel (XLSX) sont acceptés.</div>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="confirmImport" name="confirmImport" required>
                        <label class="form-check-label" for="confirmImport">
                            Je confirme que les données importées sont correctes et correspondent à l'évaluation sélectionnée.
                        </label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Importer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Formulaire caché pour l'export du modèle Excel des notes -->
<form id="exportTemplateForm" action="controller/export_notes_template.php" method="POST" style="display: none;">
    <input type="hidden" name="idevaluation" id="export_template_idevaluation">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>


<!-- Modal pour saisir les notes -->
<div class="modal fade" id="enterGradesModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Saisie des notes - <span id="evaluation_title"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="gradesForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="save_grades">
                    <input type="hidden" name="idevaluation" id="grades_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    <input type="hidden" name="session_idsession" id="grades_session_id">

                    <!-- Dans le modal pour saisir les notes (enterGradesModal), ajoutez ceci juste au-dessus du tableau -->
                    <div class="d-flex justify-content-end mb-3">
                        <button type="button" class="btn btn-info me-2" onclick="exportGradesTemplate()">
                            <i class="bi bi-file-earmark-excel"></i> Exporter modèle Excel
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#importGradesModal">
                            <i class="bi bi-file-earmark-arrow-up"></i> Importer depuis Excel
                        </button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Matricule</th>
                                    <th>Nom de l'étudiant</th>
                                    <th>Note (/20)</th>
                                </tr>
                            </thead>
                            <tbody id="grades_table_body">
                                <!-- Les lignes seront générées dynamiquement par JavaScript -->
                            </tbody>
                        </table>
                    </div>

                    

                    <!-- Formulaire pour importer les notes depuis Excel -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer les notes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Formulaire caché pour l'export des notes d'une évaluation -->
<form id="exportForm" action="controller/export_notes_evaluation.php" method="POST" style="display: none;">
    <input type="hidden" name="idevaluation" id="export_idevaluation">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>

<!-- Formulaire caché pour l'export de toutes les notes -->
<form id="exportAllForm" action="controller/export_notes_ecue.php" method="POST" style="display: none;">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>

<script>
// Fonction pour ouvrir le modal de modification d'une évaluation
function openEditEvaluationModal(evaluationId) {
    // Récupérer les données de l'évaluation via AJAX
    fetch(`controller/get_evaluation.php?id=${evaluationId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                Swal.fire('Erreur', data.error, 'error');
                return;
            }
            
            // Remplir le formulaire avec les données
            document.getElementById('edit_idevaluation').value = data.idevaluation;
            document.getElementById('edit_titre').value = data.titre;
            document.getElementById('edit_description').value = data.description || '';
            document.getElementById('edit_date_evaluation').value = data.date_evaluation;
            document.getElementById('edit_idType').value = data.idType;
            document.getElementById('edit_session_idsession').value = data.session_idsession;
            document.getElementById('edit_ponderation').value = data.ponderation;
            document.getElementById('edit_est_visible').checked = data.est_visible == 1;
            
            // Afficher le modal
            new bootstrap.Modal(document.getElementById('editEvaluationModal')).show();
        })
        .catch(error => {
            console.error('Erreur:', error);
            Swal.fire('Erreur', 'Une erreur est survenue lors de la récupération des données.', 'error');
        });
}

// Ajouter ces fonctions à la section script existante

// Fonction pour exporter le modèle Excel pour une évaluation
function exportGradesTemplate() {
    const evaluationId = document.getElementById('grades_idevaluation').value;
    document.getElementById('export_template_idevaluation').value = evaluationId;
    document.getElementById('exportTemplateForm').submit();
}

// Mise à jour de la fonction openEnterGradesModal pour préparer aussi l'import
function openEnterGradesModal(evaluationId, evaluationTitle) {
    document.getElementById('evaluation_title').textContent = evaluationTitle;
    document.getElementById('grades_idevaluation').value = evaluationId;
    document.getElementById('import_idevaluation').value = evaluationId; // Pour le modal d'import
    
    // Récupérer les notes existantes et les étudiants via AJAX
    fetch(`controller/get_grades.php?evaluation=${evaluationId}&ecue=<?= $idEcue ?>`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                Swal.fire('Erreur', data.error, 'error');
                return;
            }
            
            // Stocker l'ID de session pour le formulaire
            document.getElementById('grades_session_id').value = data.session_idsession;
            
            // Générer les lignes du tableau avec les étudiants et leurs notes
            const tableBody = document.getElementById('grades_table_body');
            tableBody.innerHTML = '';
            
            data.students.forEach((student, index) => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${student.matricule}</td>
                    <td>${student.noms}</td>
                    <td>
                        <input type="number" class="form-control" name="notes[${student.idetudiant}]" 
                               value="${student.note !== null ? student.note : ''}" min="0" max="20" step="0.25">
                    </td>
                `;
                
                tableBody.appendChild(row);
            });
            
            // Afficher le modal
            new bootstrap.Modal(document.getElementById('enterGradesModal')).show();
        })
        .catch(error => {
            console.error('Erreur:', error);
            Swal.fire('Erreur', 'Une erreur est survenue lors de la récupération des données.', 'error');
        });
}


// Fonction pour confirmer la suppression d'une évaluation
function confirmDeleteEvaluation(evaluationId) {
    Swal.fire({
        title: 'Confirmation',
        text: "Êtes-vous sûr de vouloir supprimer cette évaluation ? Cette action est irréversible et supprimera toutes les notes associées.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, supprimer',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `controller/evaluation_controller.php?action=delete_evaluation&id=${evaluationId}&ecue=<?= $idEcue ?>`;
        }
    });
}

// Fonction pour exporter les notes d'une évaluation
function exportNotesEvaluation(evaluationId) {
    document.getElementById('export_idevaluation').value = evaluationId;
    document.getElementById('exportForm').submit();
}

// Fonction pour exporter toutes les notes
function exportAllNotes() {
    document.getElementById('exportAllForm').submit();
}

// Initialisation des tooltips Bootstrap
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>

<?php include "./views/include/footer.php"; ?>


