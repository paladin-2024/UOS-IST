<?php
include "./views/include/header.php";
$universite = new Universite();

// Fetch users for the dropdown
$structure = new Structure();
$users = $structure->getUsers();

$search = isset($_GET['search']) ? $_GET['search'] : '';
?>
<!-- Espace de travail -->
<main id="main" class="main">

    <div class="pagetitle">
        <h1>PROMOTIONS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Promotions</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table promotions -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Gestion des promotions
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createPromotionModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter
                                        </a>
                                    </span>
                                </h5>

                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="configuration/promotion">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par designation...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Cycle</th>
                                            <th scope="col">Orientation</th>
                                            <th scope="col">Année Académique</th>
                                            <th scope="col">Date de Création</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $listePromotions = $universite->getPromotions($search);
                                        $i = 1;

                                        foreach ($listePromotions as $promotion){
                                            $dc = date('d/m/Y H:i:s', strtotime($promotion['dateCreation']));
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$promotion['designationPromotion']}</td>
                                                <td>{$promotion['cycle']}</td>
                                                <td>{$promotion['orientationDesignation']}</td>
                                                <td>{$promotion['anneeDesignation']}</td>
                                                <td>{$dc}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editPromotion(
                                                        {$promotion['idpromotion']}, 
                                                        \"{$promotion['designationPromotion']}\",
                                                        \"{$promotion['cycle']}\",
                                                        \"{$promotion['orientation_idorientation']}\",
                                                        \"{$promotion['annee_acad_idannee_acad']}\"
                                                    )'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDelete({$promotion['idpromotion']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour ajouter une promotion -->
<div class="modal fade" id="createPromotionModal" tabindex="-1" role="dialog" aria-labelledby="createPromotionModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Promotion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/create_promotion.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designationPromotion" class="form-label">Désignation en abbregé (Ex : L1 INFO) <span class="text-danger">*</span></label>
                            <input type="text" name="designationPromotion" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="cycle" class="form-label">Cycle <span class="text-danger">*</span></label>
                            <select name="cycle" class="form-control" required>
                                <option value="Premier">Premier</option>
                                <option value="Deuxieme">Deuxième</option>
                                <option value="Troisieme">Troisième</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un cycle.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="orientationId" class="form-label">Orientation Ou filière<span class="text-danger">*</span></label>
                            <select name="orientationId" class="form-control" required>
                                <!-- Populate with orientations -->
                                <?php
                                $orientations = $universite->getOrientations();
                                foreach ($orientations as $orientation) {
                                    echo "<option value='{$orientation['idorientation']}'>{$orientation['designationOrientation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une orientation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addPromotionBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une promotion -->
<div class="modal fade" id="editPromotionModal" tabindex="-1" role="dialog" aria-labelledby="editPromotionModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Promotion</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/edit_promotion.php" class="needs-validation" novalidate>
                    <input type="hidden" name="editPromotionId" id="editPromotionId">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editPromotionDesignation" class="form-label">Désignation en abbregé (Ex : L1 INFO)<span class="text-danger">*</span></label>
                            <input type="text" name="editPromotionDesignation" id="editPromotionDesignation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editCycle" class="form-label">Cycle <span class="text-danger">*</span></label>
                            <select name="editCycle" id="editCycle" class="form-control" required>
                                <option value="Premier">Premier</option>
                                <option value="Deuxieme">Deuxième</option>
                                <option value="Troisieme">Troisième</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un cycle.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editOrientationId" class="form-label">Orientation ou filière<span class="text-danger">*</span></label>
                            <select name="editOrientationId" id="editOrientationId" class="form-control" required>
                                <!-- Populate with orientations -->
                                <?php
                                foreach ($orientations as $orientation) {
                                    echo "<option value='{$orientation['idorientation']}'>{$orientation['designationOrientation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une orientation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editAnneeId" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="editAnneeId" id="editAnneeId" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="updatePromotionBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function editPromotion(id, designation, cycle, orientationId, anneeId) {
        document.getElementById('editPromotionId').value = id;
        document.getElementById('editPromotionDesignation').value = designation;
        document.getElementById('editCycle').value = cycle;
        document.getElementById('editOrientationId').value = orientationId;
        document.getElementById('editAnneeId').value = anneeId;

        new bootstrap.Modal(document.getElementById('editPromotionModal')).show();
    }

    function confirmDelete(idPromotion) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_promotion.php?idpromotion=' + idPromotion;
            }
        });
    }
</script>

<?php include "./views/include/footer.php"; ?>
