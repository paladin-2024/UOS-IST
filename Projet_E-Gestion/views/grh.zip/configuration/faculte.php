<?php
include "./views/include/header.php";
$section = new Universite();

$structure = new Structure();

// Fetch users for the dropdown
$users = $structure->getUsers(); // Assuming this method exists to fetch users

$userss = $structure->getUsers(); 

$search = isset($_GET['search']) ? $_GET['search'] : '';
?>
<!-- Espace de travail -->
<main id="main" class="main">

    <div class="pagetitle">
        <h1>SECTIONS / FACULTÉS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Sections / Facultés</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table sections -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Gestion des sections / facultés
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createSectionModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter
                                        </a>
                                    </span>
                                </h5>

                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="configuration/faculte">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par designation...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Année Académique</th>
                                            <th scope="col">Date de Création</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $listeSections = $section->getSections($search);
                                        $i = 1;

                                        foreach ($listeSections as $l){
                                            $dc = date('d/m/Y H:i:s', strtotime($l['dateCreation']));
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$l['designationSection']}</td>
                                                <td>{$l['anneeDesignation']}</td>
                                                <td>{$dc}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editSection(
                                                        {$l['idsection']}, 
                                                        \"{$l['designationSection']}\",
                                                        \"{$l['idAnnee']}\"
                                                    )'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDelete({$l['idsection']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-info' data-bs-toggle='collapse' data-bs-target='#managers-{$l['idsection']}'>
                                                        <i class='bi bi-eye'></i> Voir Managers
                                                    </button>
                                                    <button class='btn btn-sm btn-success' data-bs-toggle='modal' data-bs-target='#addManagerModal' onclick='setSectionId({$l['idsection']})'>
                                                        <i class='bi bi-plus-circle'></i> Ajouter Manager
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='managers-{$l['idsection']}'>
                                                <td colspan='6'>
                                                    <table class='table table-sm'>
                                                        <thead>
                                                            <tr>
                                                                <th>Nom</th>
                                                                <th>Fonction</th>
                                                                <th>Signature</th>
                                                                <th>Année académique</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>";
                                            $managers = $section->getManagersBySection($l['idsection']);
                                            foreach ($managers as $manager) {
                                                echo "
                                                            <tr>
                                                                <td>{$manager['noms']}</td>
                                                                <td>{$manager['fonction']}</td>
                                                                <td><img src='uploads/{$manager['signature']}' alt='Signature' width='100'></td>
                                                                <td>{$manager['anneeDesignation']}</td>
                                                                <td>
                                                                    <button class='btn btn-sm btn-warning' onclick='editManager(
                                                                        {$manager['idresponsable_section']}, 
                                                                        \"{$manager['noms']}\",
                                                                        \"{$manager['fonction']}\",
                                                                        \"{$manager['signature']}\",
                                                                        \"{$manager['idUser']}\",
                                                                        \"{$manager['annee_acad_idannee_acad']}\"
                                                                    )'>
                                                                        <i class='bi bi-pencil-square'></i> Modifier
                                                                    </button>
                                                                    <button class='btn btn-sm btn-danger' onclick='confirmDeleteManager({$manager['idresponsable_section']})'>
                                                                        <i class='bi bi-trash'></i> Supprimer
                                                                    </button>
                                                                </td>
                                                            </tr>";
                                            }
                                            echo "
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour ajouter une section -->
<div class="modal fade" id="createSectionModal" tabindex="-1" role="dialog" aria-labelledby="createSectionModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Section / Faculté</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/create_section.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designationSection" class="form-label">Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="designationSection" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $section->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addSectionBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour ajouter un manager -->
<div class="modal fade" id="addManagerModal" tabindex="-1" role="dialog" aria-labelledby="addManagerModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un Manager</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/create_manager.php" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="userId" class="form-label">Utilisateur <span class="text-danger">*</span></label>
                            <select name="userId" class="form-control" required>
                                <?php
                                foreach ($users as $user) {
                                    echo "<option value='{$user['idUser']}'>{$user['nomUser']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un utilisateur.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="fonction" class="form-label">Fonction <span class="text-danger">*</span></label>
                            <input type="text" name="fonction" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une fonction.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="signature" class="form-label">Signature <span class="text-danger">*</span></label>
                            <input type="file" name="signature" class="form-control" accept="image/*" required>
                            <div class="invalid-feedback">Veuillez importer une signature.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $section->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        <input type="hidden" name="sectionId" id="managerSectionId">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addManagerBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une section -->
<div class="modal fade" id="editSectionModal" tabindex="-1" role="dialog" aria-labelledby="editSectionModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Section / Faculté</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/edit_section.php" class="needs-validation" novalidate>
                    <input type="hidden" name="editSectionId" id="editSectionId">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editSectionDesignation" class="form-label">Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="editSectionDesignation" id="editSectionDesignation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editSectionAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="editSectionAnnee" id="editSectionAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="updateSectionBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier un manager -->
<div class="modal fade" id="editManagerModal" tabindex="-1" role="dialog" aria-labelledby="editManagerModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un Manager</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/update_manager.php" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <input type="hidden" name="editManagerId" id="editManagerId">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editUserId" class="form-label">Utilisateur <span class="text-danger">*</span></label>
                            <select name="editUserId" id="editUserId" class="form-control" required>
                                <?php
                                foreach ($userss as $user2) {
                                    echo "<option value='{$user2['idUser']}'>{$user2['nomUser']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un utilisateur.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editFonction" class="form-label">Fonction <span class="text-danger">*</span></label>
                            <input type="text" name="editFonction" id="editFonction" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une fonction.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="currentSignature" class="form-label">Signature Actuelle</label>
                            <div id="currentSignature">
                                <img src="" alt="Signature actuelle" id="currentSignatureImg" width="100">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label for="editSignature" class="form-label">Signature <span class="text-danger">*</span></label>
                            <input type="file" name="editSignature" id="editSignature" class="form-control" accept="image/*">
                            <div class="invalid-feedback">Veuillez importer une signature.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" id="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $section->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="updateManagerBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function editSection(id, designation, idAnnee) {
        document.getElementById('editSectionId').value = id;
        document.getElementById('editSectionDesignation').value = designation;
        document.getElementById('editSectionAnnee').value = idAnnee;

        new bootstrap.Modal(document.getElementById('editSectionModal')).show();
    }

    function confirmDelete(idSection) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_section.php?idsection=' + idSection;
            }
        });
    }

    function editManager(id, noms, fonction, signature,iduser,annee) {
        document.getElementById('editManagerId').value = id;
        document.getElementById('editUserId').value = iduser;
        document.getElementById('editFonction').value = fonction;
        document.getElementById('idAnnee').value = annee;
        //document.getElementById('editSignature').value = signature;
        document.getElementById('currentSignatureImg').src = 'uploads/' + signature;
        // Signature handling can be added if needed

        new bootstrap.Modal(document.getElementById('editManagerModal')).show();
    }

    function confirmDeleteManager(idManager) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_manager.php?idresponsable_section=' + idManager;
            }
        });
    }

    function setSectionId(sectionId) {
        document.getElementById('managerSectionId').value = sectionId;
    }
</script>

<?php include "./views/include/footer.php"; ?>