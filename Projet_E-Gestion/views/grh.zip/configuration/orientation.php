<?php
include "./views/include/header.php";
$universite = new Universite();

// Fetch only teacher users for the dropdown
$structure = new Structure();
$users = $structure->getTeacherUsers();
$userss = $structure->getTeacherUsers();

$search = isset($_GET['search']) ? $_GET['search'] : '';
?>

<!-- Espace de travail -->
<main id="main" class="main">

    <div class="pagetitle">
        <h1>ORIENTATIONS</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Orientations</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table orientations -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                            <h5 class="card-title">
                                Gestion des orientations
                                <span>
                                    | <a data-bs-toggle="modal" data-bs-target="#createOrientationModal" class="btnPage">
                                        <i class="bi bi-plus-circle-fill"></i> Ajouter
                                    </a>
                                    | <a data-bs-toggle="modal" data-bs-target="#exportOrientationsModal" class="btnPage">
                                        <i class="bi bi-file-excel-fill"></i> Exporter
                                    </a>
                                </span>
                            </h5>


                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="configuration/orientation">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par designation...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Section</th>
                                            <th scope="col">Date de Création</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $listeOrientations = $universite->getOrientations($search);
                                        $i = 1;

                                        foreach ($listeOrientations as $l){
                                            $dc = date('d/m/Y H:i:s', strtotime($l['dateCreation']));
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$l['designationOrientation']}</td>
                                                <td>{$l['sectionDesignation']}</td>
                                                <td>{$dc}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editOrientation(
                                                        {$l['idorientation']}, 
                                                        \"{$l['designationOrientation']}\",
                                                        \"{$l['section_idsection']}\"
                                                    )'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDelete({$l['idorientation']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-info' data-bs-toggle='collapse' data-bs-target='#managers-{$l['idorientation']}'>
                                                        <i class='bi bi-eye'></i> Voir Responsables
                                                    </button>
                                                    <button class='btn btn-sm btn-success' data-bs-toggle='modal' data-bs-target='#addManagerModal' onclick='setOrientationId({$l['idorientation']})'>
                                                        <i class='bi bi-plus-circle'></i> Ajouter Responsable
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='managers-{$l['idorientation']}'>
                                                <td colspan='6'>
                                                    <table class='table table-sm'>
                                                        <thead>
                                                            <tr>
                                                                <th>Nom</th>
                                                                <th>Fonction</th>
                                                                <th>Signature</th>
                                                                <th>Année académique</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>";
                                            $managers = $universite->getManagersByOrientation($l['idorientation']);
                                            foreach ($managers as $manager) {
                                                echo "
                                                            <tr>
                                                                <td>{$manager['noms']}</td>
                                                                <td>{$manager['fonction']}</td>
                                                                <td><img src='uploads/{$manager['signature']}' alt='Signature' width='100'></td>
                                                                <td>{$manager['anneeDesignation']}</td>
                                                                <td>
                                                                    <button class='btn btn-sm btn-warning' onclick='editManager(
                                                                        {$manager['idresponsable_orientation']}, 
                                                                        \"{$manager['noms']}\",
                                                                        \"{$manager['fonction']}\",
                                                                        \"{$manager['signature']}\",
                                                                        \"{$manager['idUser']}\",
                                                                        \"{$manager['annee_acad_idannee_acad']}\"
                                                                    )'>
                                                                        <i class='bi bi-pencil-square'></i> Modifier
                                                                    </button>
                                                                    <button class='btn btn-sm btn-danger' onclick='confirmDeleteManager({$manager['idresponsable_orientation']})'>
                                                                        <i class='bi bi-trash'></i> Supprimer
                                                                    </button>
                                                                </td>
                                                            </tr>";
                                            }
                                            echo "
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour exporter les orientations -->
<div class="modal fade" id="exportOrientationsModal" tabindex="-1" role="dialog" aria-labelledby="exportOrientationsModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Exporter les Orientations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/export_orientations.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="exportSectionId" class="form-label">Section</label>
                            <select name="idSection" id="exportSectionId" class="form-control">
                                <option value="all">Toutes les sections</option>
                                <?php
                                $sections = $universite->getSections();
                                foreach ($sections as $section) {
                                    echo "<option value='{$section['idsection']}'>{$section['designationSection']} - {$section['anneeDesignation']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="exportOrientationId" class="form-label">Orientation</label>
                            <select name="idOrientation" id="exportOrientationId" class="form-control">
                                <option value="all">Toutes les orientations</option>
                                <?php
                                $allOrientations = $universite->getOrientations();
                                foreach ($allOrientations as $orientation) {
                                    echo "<option value='{$orientation['idorientation']}'>{$orientation['designationOrientation']} ({$orientation['sectionDesignation']})</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="includeManagers" id="includeManagers" checked>
                                <label class="form-check-label" for="includeManagers">
                                    Inclure les responsables
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="exportBtn" class="btn btn-primary">
                            <i class="bi bi-file-excel"></i> Exporter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour ajouter une orientation -->
<div class="modal fade" id="createOrientationModal" tabindex="-1" role="dialog" aria-labelledby="createOrientationModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Orientation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/create_orientation.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designationOrientation" class="form-label">Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="designationOrientation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="sectionId" class="form-label">Section <span class="text-danger">*</span></label>
                            <select name="sectionId" class="form-control" required>
                                <!-- Populate with sections -->
                                <?php
                                $sections = $universite->getSections();
                                foreach ($sections as $section) {
                                    echo "<option value='{$section['idsection']}'>{$section['designationSection']} - {$section['anneeDesignation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une section.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addOrientationBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une orientation -->
<div class="modal fade" id="editOrientationModal" tabindex="-1" role="dialog" aria-labelledby="editOrientationModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Orientation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/edit_orientation.php" class="needs-validation" novalidate>
                    <input type="hidden" name="editOrientationId" id="editOrientationId">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editOrientationDesignation" class="form-label">Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="editOrientationDesignation" id="editOrientationDesignation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editSectionId" class="form-label">Section <span class="text-danger">*</span></label>
                            <select name="editSectionId" id="editSectionId" class="form-control" required>
                                <!-- Populate with sections -->
                                <?php
                                foreach ($sections as $section) {
                                    echo "<option value='{$section['idsection']}'>{$section['designationSection']} - {$section['anneeDesignation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une section.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="updateOrientationBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour ajouter un responsable -->
<div class="modal fade" id="addManagerModal" tabindex="-1" role="dialog" aria-labelledby="addManagerModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter un Responsable</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/create_manager_orientation.php" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="userId" class="form-label">Utilisateur <span class="text-danger">*</span></label>
                            <select name="userId" class="form-control" required>
                                <?php
                                foreach ($users as $user) {
                                    echo "<option value='{$user['idUser']}'>{$user['nomUser']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un utilisateur.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="fonction" class="form-label">Fonction <span class="text-danger">*</span></label>
                            <input type="text" name="fonction" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une fonction.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="signature" class="form-label">Signature <span class="text-danger">*</span></label>
                            <input type="file" name="signature" class="form-control" accept="image/*" required>
                            <div class="invalid-feedback">Veuillez importer une signature.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        <input type="hidden" name="orientationId" id="managerOrientationId">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addManagerBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier un responsable -->
<div class="modal fade" id="editManagerModal" tabindex="-1" role="dialog" aria-labelledby="editManagerModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un Responsable</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/update_manager_orientation.php" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <input type="hidden" name="editManagerId" id="editManagerId">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editUserId" class="form-label">Utilisateur <span class="text-danger">*</span></label>
                            <select name="editUserId" id="editUserId" class="form-control" required>
                                <?php
                                foreach ($userss as $user) {
                                    echo "<option value='{$user['idUser']}'>{$user['nomUser']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un utilisateur.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editFonction" class="form-label">Fonction <span class="text-danger">*</span></label>
                            <input type="text" name="editFonction" id="editFonction" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une fonction.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="currentSignature" class="form-label">Signature Actuelle</label>
                            <div id="currentSignature">
                                <img src="" alt="Signature actuelle" id="currentSignatureImg" width="100">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label for="editSignature" class="form-label">Signature <span class="text-danger">*</span></label>
                            <input type="file" name="editSignature" id="editSignature" class="form-control" accept="image/*">
                            <div class="invalid-feedback">Veuillez importer une signature.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idAnnee" class="form-label">Année Académique <span class="text-danger">*</span></label>
                            <select name="idAnnee" id="idAnnee" class="form-control" required>
                                <!-- Populate with academic years -->
                                <?php
                                $academicYears = $universite->getAcademicYears();
                                foreach ($academicYears as $year) {
                                    echo "<option value='{$year['idannee_acad']}'>{$year['designation']}</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une année académique.</div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="updateManagerBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
    function editOrientation(id, designation, sectionId) {
        document.getElementById('editOrientationId').value = id;
        document.getElementById('editOrientationDesignation').value = designation;
        document.getElementById('editSectionId').value = sectionId;

        new bootstrap.Modal(document.getElementById('editOrientationModal')).show();
    }

    function confirmDelete(idOrientation) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_orientation.php?idorientation=' + idOrientation;
            }
        });
    }

    function editManager(id, noms, fonction, signature, idUser, annee) {
        document.getElementById('editManagerId').value = id;
        document.getElementById('editUserId').value = idUser;
        document.getElementById('editFonction').value = fonction;
        document.getElementById('idAnnee').value = annee;
        document.getElementById('currentSignatureImg').src = 'uploads/' + signature;

        new bootstrap.Modal(document.getElementById('editManagerModal')).show();
    }

    function confirmDeleteManager(idManager) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible !",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_manager_orientation.php?idresponsable_orientation=' + idManager;
            }
        });
    }

    function setOrientationId(orientationId) {
        document.getElementById('managerOrientationId').value = orientationId;
    }
</script>

<script>
    // Autres scripts existants...
    
    // Filtrer les orientations par section
    document.getElementById('exportSectionId').addEventListener('change', function() {
        const sectionId = this.value;
        const orientationSelect = document.getElementById('exportOrientationId');
        
        // Réinitialiser l'option "Toutes les orientations"
        orientationSelect.innerHTML = '<option value="all">Toutes les orientations</option>';
        
        // Si "Toutes les sections" est sélectionné, afficher toutes les orientations
        if (sectionId === 'all') {
            <?php foreach ($allOrientations as $orientation): ?>
                orientationSelect.innerHTML += `<option value="<?= $orientation['idorientation'] ?>"><?= $orientation['designationOrientation'] ?> (<?= $orientation['sectionDesignation'] ?>)</option>`;
            <?php endforeach; ?>
        } else {
            // Sinon, filtrer les orientations par section
            <?php foreach ($allOrientations as $orientation): ?>
                if ('<?= $orientation['section_idsection'] ?>' === sectionId) {
                    orientationSelect.innerHTML += `<option value="<?= $orientation['idorientation'] ?>"><?= $orientation['designationOrientation'] ?></option>`;
                }
            <?php endforeach; ?>
        }
    });
</script>


<?php include "./views/include/footer_file.php"; ?>

