<?php
include "./views/include/header.php";
$universite = new Universite();

// Récupérer la configuration actuelle
$config = $universite->getConfigurationUniversite();
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Configuration de l'Établissement</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Configuration</li>
            </ol>
        </nav>
    </div>

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Informations de l'Établissement</h5>

                        <form id="configForm" method="POST" action="controller/save_config_universite.php" enctype="multipart/form-data">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Type d'Établissement</label>
                                    <select name="type_etablissement" class="form-select" required>
                                        <option value="Institut Supérieur" <?= ($config['type_etablissement'] ?? '') == 'Institut Supérieur' ? 'selected' : '' ?>>Institut Supérieur</option>
                                        <option value="Université" <?= ($config['type_etablissement'] ?? '') == 'Université' ? 'selected' : '' ?>>Université</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Sigle</label>
                                    <input type="text" class="form-control" name="sigle" value="<?= htmlspecialchars($config['sigle'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <label class="form-label">Nom Complet</label>
                                    <input type="text" class="form-control" name="nom" value="<?= htmlspecialchars($config['nom'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <label class="form-label">Ministère de Tutelle</label>
                                    <input type="text" class="form-control" name="ministere_tutelle" value="<?= htmlspecialchars($config['ministere_tutelle'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Adresse</label>
                                    <textarea class="form-control" name="adresse" rows="2"><?= htmlspecialchars($config['adresse'] ?? '') ?></textarea>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Ville</label>
                                    <input type="text" class="form-control" name="ville" value="<?= htmlspecialchars($config['ville'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" name="telephone" value="<?= htmlspecialchars($config['telephone'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($config['email'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Site Web</label>
                                    <input type="url" class="form-control" name="site_web" value="<?= htmlspecialchars($config['site_web'] ?? '') ?>">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Nom du Responsable</label>
                                    <input type="text" class="form-control" name="nom_responsable" value="<?= htmlspecialchars($config['nom_responsable'] ?? '') ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Titre du Responsable</label>
                                    <input type="text" class="form-control" name="titre_responsable" value="<?= htmlspecialchars($config['titre_responsable'] ?? '') ?>" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label">Logo</label>
                                    <input type="file" class="form-control" name="logo" accept="image/*">
                                    <?php if (!empty($config['logo'])): ?>
                                        <img src="<?= $config['logo'] ?>" alt="Logo actuel" class="mt-2" style="max-height: 100px">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Signature du Responsable</label>
                                    <input type="file" class="form-control" name="signature_responsable" accept="image/*">
                                    <?php if (!empty($config['signature_responsable'])): ?>
                                        <img src="<?= $config['signature_responsable'] ?>" alt="Signature actuelle" class="mt-2" style="max-height: 100px">
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Cachet</label>
                                    <input type="file" class="form-control" name="cachet" accept="image/*">
                                    <?php if (!empty($config['cachet'])): ?>
                                        <img src="<?= $config['cachet'] ?>" alt="Cachet actuel" class="mt-2" style="max-height: 100px">
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary">Enregistrer</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script>
document.getElementById('configForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    // Afficher un indicateur de chargement
    Swal.fire({
        title: 'Enregistrement en cours...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    fetch('controller/save_config_universite.php', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erreur réseau');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Succès',
                text: data.message || 'Configuration enregistrée avec succès'
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Erreur',
                text: data.message || 'Une erreur est survenue lors de l\'enregistrement'
            });
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'Une erreur est survenue lors de la communication avec le serveur'
        });
    });
});
</script>

<?php include "./views/include/footer_file.php"; ?>