<?php
include "./views/include/header.php";
$universite = new Universite();
$agentModel = new Agent();
$etudiantModel = new Etudiant();

// Récupération des données
$enseignantsByUR = $universite->getEnseignantsByUniteRecherche();
$etudiantsByProf = $universite->getEtudiantsByProfesseurAndSection();
$sections = $universite->getSections();

// Variables pour les filtres
$filtreOrientation = isset($_GET['orientation']) ? $_GET['orientation'] : '';
$filtreSection = isset($_GET['section']) ? $_GET['section'] : '';
$filtreGrade = isset($_GET['grade']) ? $_GET['grade'] : '';
$recherche = isset($_GET['recherche']) ? $_GET['recherche'] : '';

// Récupérer les listes pour les filtres
$orientations = array_unique(array_column($enseignantsByUR, 'designationOrientation'));
$grades = array_unique(array_column($etudiantsByProf, 'grade'));
?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Tableau de Bord de la Recherche</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Tableau de Bord</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <!-- Statistiques des Unités de Recherche -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Enseignants par Unité de Recherche</h5>
                        
                        <!-- Formulaire de recherche et filtres -->
                        <form action="" method="GET" class="mb-3">
                            <div class="row g-3 align-items-center">
                                <div class="col-md-4">
                                    <input type="text" class="form-control" id="searchUR" placeholder="Rechercher..." 
                                           value="<?= htmlspecialchars($recherche) ?>">
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select" id="filterOrientation">
                                        <option value="">Tous les départements</option>
                                        <?php foreach ($orientations as $orientation): ?>
                                            <option value="<?= htmlspecialchars($orientation) ?>" 
                                                    <?= $filtreOrientation === $orientation ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($orientation) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-primary" id="searchURBtn">Filtrer</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-secondary" id="resetURBtn">Réinitialiser</button>
                                </div>
                            </div>
                        </form>
                        
                        <div class="table-responsive">
                            <table class="table table-striped" id="tableUR">
                                <thead>
                                    <tr>
                                        <th>Département</th>
                                        <th>Unité de Recherche</th>
                                        <th>Nombre d'Enseignants</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($enseignantsByUR as $ur): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($ur['designationOrientation']) ?></td>
                                        <td><?= htmlspecialchars($ur['designation_UR']) ?></td>
                                        <td><span class="badge bg-primary"><?= htmlspecialchars($ur['nombre_enseignants']) ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistiques des Étudiants par Professeur -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            Étudiants par Professeur et Section 
                            <small class="text-muted">(Année académique en cours)</small>
                        </h5>
                        
                        <!-- Formulaire de recherche et filtres -->
                        <form action="" method="GET" class="mb-3">
                            <div class="row g-3 align-items-center">
                                <div class="col-md-3">
                                    <input type="text" class="form-control" id="searchProf" placeholder="Rechercher un professeur..." 
                                           value="<?= htmlspecialchars($recherche) ?>">
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select" id="filterSection">
                                        <option value="">Toutes les sections</option>
                                        <?php foreach ($sections as $section): ?>
                                            <option value="<?= htmlspecialchars($section['idsection']) ?>" 
                                                    <?= $filtreSection === $section['idsection'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($section['designationSection']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <select class="form-select" id="filterGrade">
                                        <option value="">Tous les grades</option>
                                        <?php foreach ($grades as $grade): ?>
                                            <option value="<?= htmlspecialchars($grade) ?>" 
                                                    <?= $filtreGrade === $grade ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($grade) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-primary" id="searchProfBtn">Filtrer</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-secondary" id="resetProfBtn">Réinitialiser</button>
                                </div>
                            </div>
                        </form>
                        
                        <div class="table-responsive">
                            <table class="table table-striped" id="tableProf">
                                <thead>
                                    <tr>
                                        <th>Section</th>
                                        <th>Professeur</th>
                                        <th>Grade</th>
                                        <th>Sujets Validés</th>
                                        <th>Sujets En Attente</th>
                                        <th>Total Étudiants</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($etudiantsByProf as $prof): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($prof['designationSection']) ?></td>
                                        <td><?= htmlspecialchars($prof['nomEnseignant']) ?></td>
                                        <td><?= htmlspecialchars($prof['grade']) ?></td>
                                        <td>
                                            <span class="badge bg-success">
                                                <?= htmlspecialchars($prof['sujets_valides'] ?? 0) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-warning">
                                                <?= htmlspecialchars($prof['sujets_en_attente'] ?? 0) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary">
                                                <?= htmlspecialchars($prof['total_etudiants']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr class="table-info">
                                        <td colspan="3"><strong>Total</strong></td>
                                        <td>
                                            <span class="badge bg-success">
                                                <?= array_sum(array_column($etudiantsByProf, 'sujets_valides')) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-warning">
                                                <?= array_sum(array_column($etudiantsByProf, 'sujets_en_attente')) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary">
                                                <?= array_sum(array_column($etudiantsByProf, 'total_etudiants')) ?>
                                            </span>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Évolution par Section (déjà avec un filtre) -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">
                            Évolution par Section
                            <div class="float-end">
                                <select id="sectionSelect" class="form-select form-select-sm" style="width: 200px;">
                                    <option value="">Sélectionner une section</option>
                                    <?php foreach ($sections as $section): ?>
                                    <option value="<?= htmlspecialchars($section['idsection']) ?>"><?= htmlspecialchars($section['designationSection']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </h5>
                        <div id="evolutionChart"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sectionSelect = document.getElementById('sectionSelect');
    
    // Filtrage pour les unités de recherche
    const searchURBtn = document.getElementById('searchURBtn');
    const resetURBtn = document.getElementById('resetURBtn');
    const searchUR = document.getElementById('searchUR');
    const filterOrientation = document.getElementById('filterOrientation');
    const tableUR = document.getElementById('tableUR');
    
    // Filtrage pour les professeurs
    const searchProfBtn = document.getElementById('searchProfBtn');
    const resetProfBtn = document.getElementById('resetProfBtn');
    const searchProf = document.getElementById('searchProf');
    const filterSection = document.getElementById('filterSection');
    const filterGrade = document.getElementById('filterGrade');
    const tableProf = document.getElementById('tableProf');
    
    // Fonctions de filtrage pour le tableau des unités de recherche
    function filterTableUR() {
        const searchText = searchUR.value.toLowerCase();
        const orientation = filterOrientation.value.toLowerCase();
        const rows = tableUR.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const departement = row.cells[0].textContent.toLowerCase();
            const unite = row.cells[1].textContent.toLowerCase();
            
            const matchSearch = searchText === '' || 
                                 departement.includes(searchText) || 
                                 unite.includes(searchText);
            
            const matchOrientation = orientation === '' || departement === orientation;
            
            row.style.display = (matchSearch && matchOrientation) ? '' : 'none';
        });
    }
    
    // Fonctions de filtrage pour le tableau des professeurs
    function filterTableProf() {
        const searchText = searchProf.value.toLowerCase();
        const section = filterSection.options[filterSection.selectedIndex].text.toLowerCase();
        const grade = filterGrade.value.toLowerCase();
        const rows = tableProf.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const rowSection = row.cells[0].textContent.toLowerCase();
            const professeur = row.cells[1].textContent.toLowerCase();
            const rowGrade = row.cells[2].textContent.toLowerCase();
            
            const matchSearch = searchText === '' || professeur.includes(searchText);
            const matchSection = section === 'toutes les sections' || rowSection.includes(section);
            const matchGrade = grade === '' || rowGrade === grade;
            
            row.style.display = (matchSearch && matchSection && matchGrade) ? '' : 'none';
        });
        
        // Mettre à jour les totaux dans le pied de tableau
        updateProfTotals();
    }
    
    // Mettre à jour les totaux dans le pied de tableau des professeurs
    function updateProfTotals() {
        const rows = Array.from(tableProf.querySelectorAll('tbody tr')).filter(row => row.style.display !== 'none');
        let totalValidated = 0;
        let totalPending = 0;
        let totalStudents = 0;
        
        rows.forEach(row => {
            totalValidated += parseInt(row.cells[3].textContent.trim());
            totalPending += parseInt(row.cells[4].textContent.trim());
            totalStudents += parseInt(row.cells[5].textContent.trim());
        });
        
        const tfoot = tableProf.querySelector('tfoot');
        if (tfoot) {
            tfoot.rows[0].cells[3].querySelector('span').textContent = totalValidated;
            tfoot.rows[0].cells[4].querySelector('span').textContent = totalPending;
            tfoot.rows[0].cells[5].querySelector('span').textContent = totalStudents;
        }
    }
    
    // Gestion des événements pour les filtres Unité de Recherche
    if (searchURBtn) {
        searchURBtn.addEventListener('click', filterTableUR);
    }
    
    if (resetURBtn) {
        resetURBtn.addEventListener('click', function() {
            searchUR.value = '';
            filterOrientation.selectedIndex = 0;
            filterTableUR();
        });
    }
    
    // Gestion des événements pour les filtres Professeurs
    if (searchProfBtn) {
        searchProfBtn.addEventListener('click', filterTableProf);
    }
    
    if (resetProfBtn) {
        resetProfBtn.addEventListener('click', function() {
            searchProf.value = '';
            filterSection.selectedIndex = 0;
            filterGrade.selectedIndex = 0;
            filterTableProf();
        });
    }
    
    // Recherche en temps réel (optionnel)
    if (searchUR) {
        searchUR.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                filterTableUR();
            }
        });
    }
    
    if (searchProf) {
        searchProf.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                filterTableProf();
            }
        });
    }
    
    // Évolution par Section (code existant)
    if (sectionSelect) {
        sectionSelect.onchange = function(e) {
            const selectedValue = this.value;
            loadEvolutionData(selectedValue);
        };
    }
});

function loadEvolutionData(sectionId) {
    const chartDiv = document.getElementById('evolutionChart');
    chartDiv.innerHTML = '<div class="text-center">Chargement...</div>';

    fetch(`controller/get_evolution_data.php?sectionId=${sectionId}`)
        .then(response => response.json())
        .then(data => {
            if (!data || data.length === 0) {
                chartDiv.innerHTML = '<div class="alert alert-warning">Aucune donnée disponible pour cette section</div>';
                return;
            }

            const options = {
                series: [{
                    name: 'Total Étudiants',
                    type: 'column',
                    data: data.map(d => parseInt(d.total_etudiants) || 0)
                }, {
                    name: 'Travaux Validés',
                    type: 'column',
                    data: data.map(d => parseInt(d.etudiants_valides) || 0)
                }],
                chart: {
                    height: 350,
                    type: 'bar',
                    toolbar: {
                        show: true
                    }
                },
                plotOptions: {
                    bar: {
                        borderRadius: 3,
                        dataLabels: {
                            position: 'top'
                        }
                    }
                },
                dataLabels: {
                    enabled: true,
                    formatter: function (val) {
                        return val;
                    },
                    offsetY: -20,
                    style: {
                        fontSize: '12px',
                        colors: ["#304758"]
                    }
                },
                stroke: {
                    width: [2, 2]
                },
                xaxis: {
                    categories: data.map(d => d.annee),
                    position: 'bottom',
                    labels: {
                        offsetY: 0
                    },
                    axisBorder: {
                        show: true
                    },
                    axisTicks: {
                        show: true
                    },
                    title: {
                        text: "Années Académiques"
                    }
                },
                yaxis: {
                    title: {
                        text: "Nombre d'étudiants"
                    }
                },
                fill: {
                    opacity: 1
                },
                colors: ['#435ebe', '#198754'],
                title: {
                    text: 'Évolution des étudiants par année',
                    floating: false,
                    align: 'center',
                    style: {
                        fontSize: '14px'
                    }
                },
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    shared: true,
                    intersect: false
                }
            };

            const chart = new ApexCharts(document.querySelector("#evolutionChart"), options);
            chart.render();
        })
        .catch(error => {
            chartDiv.innerHTML = `<div class="alert alert-danger">Erreur lors du chargement des données: ${error.message}</div>`;
        });
}
</script>

<?php include "./views/include/footer_file.php"; ?>
