<?php
// Récupérer la configuration de l'université
$universite = new Universite();
$config = $universite->getConfigurationUniversite();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ScienceHub - Plateforme de Gestion des Travaux Scientifiques</title>

    <?php if (!empty($config['logo'])): ?>
        <!-- Favicons --> 
	<link href="../<?= htmlspecialchars($config['logo']) ?>" rel="icon">
	<link href="../<?= htmlspecialchars($config['logo']) ?>" rel="apple-touch-icon">
    <?php endif; ?>
    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #004494;
            --secondary-color: #f5f5f5;
            --accent-color: #FFD700;
            --text-color: #333;
            --light-text: #fff;
        }
        
        body {
            color: var(--text-color);
            font-family: 'Roboto', Arial, sans-serif;
        }
        
        /* EU Banner */
        .eu-banner {
            background-color: #444;
            color: white;
            padding: 8px 15px;
        }
        
        .eu-flag {
            width: 20px;
            height: 15px;
            margin-right: 10px;
            background-color: #003399;
            position: relative;
            overflow: hidden;
            display: inline-block;
        }
        
        /* Header */
        .custom-navbar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .navbar-brand img {
            height: 50px;
        }
        
        /* Main Banner */
        .main-banner {
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 2rem 0;
            position: relative;
        }
        
        .anniversary-badge {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            max-width: 120px;
        }
        
        /* Navigation */
        .main-nav {
            background-color: var(--primary-color);
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .main-nav .nav-link {
            color: var(--light-text);
            font-weight: 500;
            padding: 1rem 1.5rem;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .main-nav .nav-item:first-child .nav-link {
            border-left: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .main-nav .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        /* Search Bar */
        .search-bar {
            background-color: var(--secondary-color);
            padding: 1.5rem 0;
        }
        
        /* Featured Section */
        .featured-section {
            padding: 3rem 0;
        }
        
        .featured-card {
            height: 100%;
            transition: transform 0.3s;
            border: none;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .featured-card:hover {
            transform: translateY(-5px);
        }
        
        .featured-img {
            height: 200px;
            object-fit: cover;
        }
        
        /* Categories */
        .categories-section {
            background-color: var(--secondary-color);
            padding: 3rem 0;
        }
        
        .category-item {
            background-color: white;
            padding: 1.5rem;
            border-radius: 5px;
            text-align: center;
            height: 100%;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        
        .category-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        
        .category-icon {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }
        
        /* Statistics */
        .stats-section {
            padding: 3rem 0;
            background-color: var(--primary-color);
            color: white;
        }
        
        .stat-item {
            text-align: center;
            padding: 1.5rem;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        /* Footer */
        .footer {
            background-color: #333;
            color: white;
            padding: 3rem 0 1.5rem;
        }
        
        .footer-heading {
            color: var(--accent-color);
            margin-bottom: 1.5rem;
            font-weight: 600;
        }
        
        .footer-link {
            color: #ddd;
            text-decoration: none;
            display: block;
            margin-bottom: 0.5rem;
            transition: color 0.3s;
        }
        
        .footer-link:hover {
            color: white;
        }
        
        .social-icon {
            color: white;
            font-size: 1.5rem;
            margin-right: 1rem;
            transition: transform 0.3s;
        }
        
        .social-icon:hover {
            transform: scale(1.2);
        }
        
        /* Responsive Adjustments */
        @media (max-width: 992px) {
            .anniversary-badge {
                display: none;
            }
            
            .main-nav .nav-link {
                border: none;
                padding: 0.75rem 1rem;
            }
        }
        
        @media (max-width: 768px) {
            .featured-img {
                height: 180px;
            }
            
            .stat-number {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- EU Banner -->
    <div class="eu-banner d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <div class="eu-flag"></div>
            <span>Une plateforme universitaire</span>
        </div>
        <div class="d-flex align-items-center" role="button">
            <span class="me-2">Comment le vérifier?</span>
            <i class="fas fa-chevron-down"></i>
        </div>
    </div>
    
    <!-- Header Navbar -->
    <nav class="navbar navbar-expand-lg custom-navbar">
        <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="#">
            <?php if (!empty($config['logo'])): ?>
                <img src="../<?= htmlspecialchars($config['logo']) ?>" alt="<?= htmlspecialchars($config['sigle']) ?> Logo" class="me-2">
            <?php endif; ?>
            <div>
                <span class="d-block">ScienceHub</span>
                <small class="text-muted">Plateforme de Recherche</small>
            </div>
        </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link text-primary" href="login">
                            <i class="fas fa-user-circle me-1"></i> Connexion
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-primary" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-globe me-1"></i> Français
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">English</a></li>
                            <li><a class="dropdown-item" href="#">Español</a></li>
                            <li><a class="dropdown-item" href="#">Deutsch</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    
    
    <!-- Main Navigation -->
    <nav class="main-nav">
        <div class="container">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" href="index">Accueil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="projet">Projets tutorés</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="memoire">Mémoires</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="these">Thèses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="article">Articles</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="livre">Livres</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cours">Cours</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="statistique">Statistiques</a>
                </li>
            </ul>
        </div>
    </nav>