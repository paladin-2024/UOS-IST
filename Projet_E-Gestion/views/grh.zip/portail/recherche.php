<?php
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Universite.php';

$universite = new Universite();

// Récupérer les paramètres de recherche et de filtrage
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$typeDocument = isset($_GET['type_document']) ? $_GET['type_document'] : '';
$typeAuteur = isset($_GET['type_auteur']) ? $_GET['type_auteur'] : '';
$departementId = isset($_GET['departement_id']) ? intval($_GET['departement_id']) : 0;
$anneeId = isset($_GET['annee_academique_id']) ? intval($_GET['annee_academique_id']) : 0;

// Préparer les filtres
$filters = [
    'est_public' => 1,
    'statut' => 'Validé'
];

if (!empty($typeDocument)) $filters['type_document'] = $typeDocument;
if (!empty($typeAuteur)) $filters['type_auteur'] = $typeAuteur;
if ($departementId > 0) $filters['departement_id'] = $departementId;
if ($anneeId > 0) $filters['annee_academique_id'] = $anneeId;

// Récupérer les données pour les filtres
$departements = $universite->getAllDepartments();
$academicYears = $universite->getAcademicYears();

// Récupérer les travaux
$travaux = $universite->getTravaux($search, $filters);

include 'header2.php';
?>

<main class="container py-5">
    <!-- Fil d'Ariane -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Accueil</a></li>
            <li class="breadcrumb-item active">Recherche de travaux scientifiques</li>
        </ol>
    </nav>

    <!-- Barre de recherche et filtres -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="" class="row g-3">
                <!-- Barre de recherche -->
                <div class="col-md-12 mb-3">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Rechercher par titre, auteur, mots-clés..." value="<?= htmlspecialchars($search) ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i> Rechercher
                        </button>
                    </div>
                </div>

                <!-- Filtres -->
                <div class="col-md-3">
                    <label class="form-label">Type de document</label>
                    <select name="type_document" class="form-select">
                        <option value="">Tous les types</option>
                        <option value="Mémoire" <?= $typeDocument === 'Mémoire' ? 'selected' : '' ?>>Mémoire</option>
                        <option value="Thèse" <?= $typeDocument === 'Thèse' ? 'selected' : '' ?>>Thèse</option>
                        <option value="Rapport de stage" <?= $typeDocument === 'Rapport de stage' ? 'selected' : '' ?>>Rapport de stage</option>
                        <option value="Article scientifique" <?= $typeDocument === 'Article scientifique' ? 'selected' : '' ?>>Article scientifique</option>
                        <option value="Projet tutoré" <?= $typeDocument === 'Projet tutoré' ? 'selected' : '' ?>>Projet tutoré</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Type d'auteur</label>
                    <select name="type_auteur" class="form-select">
                        <option value="">Tous les auteurs</option>
                        <option value="Etudiant" <?= $typeAuteur === 'Etudiant' ? 'selected' : '' ?>>Étudiant</option>
                        <option value="Enseignant" <?= $typeAuteur === 'Enseignant' ? 'selected' : '' ?>>Enseignant</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Département</label>
                    <select name="departement_id" class="form-select">
                        <option value="">Tous les départements</option>
                        <?php foreach ($departements as $dept): ?>
                            <option value="<?= $dept['iddepartement'] ?>" <?= $departementId === $dept['iddepartement'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($dept['designationDepartement']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Année académique</label>
                    <select name="annee_academique_id" class="form-select">
                        <option value="">Toutes les années</option>
                        <?php foreach ($academicYears as $year): ?>
                            <option value="<?= $year['idannee_acad'] ?>" <?= $anneeId === $year['idannee_acad'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($year['designation']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Résultats de recherche -->
    <div class="row">
        <?php if (!empty($travaux)): ?>
            <?php foreach ($travaux as $travail): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <!-- En-tête avec type de document -->
                        <div class="card-header <?= $travail['type_class'] ?> text-white">
                            <i class="fas fa-file-alt me-2"></i>
                            <?= $travail['type_document'] ?>
                        </div>

                        <div class="card-body">
                            <!-- Titre -->
                            <h5 class="card-title mb-3">
                                <a href="voir_travail?id=<?= $travail['id'] ?>" class="text-decoration-none text-dark">
                                    <?= htmlspecialchars($travail['titre']) ?>
                                </a>
                            </h5>

                            <!-- Informations sur l'auteur -->
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-user-circle text-muted me-2"></i>
                                <span>
                                    <?= htmlspecialchars($travail['nom_auteur']) ?>
                                    <span class="badge bg-secondary ms-1"><?= $travail['type_auteur'] ?></span>
                                </span>
                            </div>

                            <!-- Département et date -->
                            <div class="small text-muted mb-3">
                                <i class="fas fa-graduation-cap me-2"></i>
                                <?= htmlspecialchars($travail['designationDepartement']) ?>
                                <br>
                                <i class="fas fa-calendar-alt me-2"></i>
                                <?= $travail['date_depot_formatee'] ?>
                            </div>

                            <!-- Résumé court -->
                            <p class="card-text small">
                                <?= htmlspecialchars(substr($travail['resume'], 0, 100)) ?>...
                            </p>
                        </div>

                        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                            <a href="voir_travail?id=<?= $travail['id'] ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-eye me-1"></i> Consulter
                            </a>
                            <div class="text-muted small">
                                <i class="fas fa-chart-bar me-1"></i>
                                <?= number_format($travail['nb_consultations']) ?> vues
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Aucun travail scientifique ne correspond à vos critères de recherche.
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
.card {
    transition: transform 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card-title {
    font-size: 1.1rem;
    line-height: 1.4;
    height: 3.1em;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
}
</style>

<?php include 'footer.php'; ?>