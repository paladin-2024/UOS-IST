<?php
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Universite.php';

$universite = new Universite();

// Récupérer les filtres
$departementId = isset($_GET['departement']) ? intval($_GET['departement']) : 0;
$anneeId = isset($_GET['annee']) ? intval($_GET['annee']) : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Préparer les filtres pour la requête
$filters = [
    'type_document' => 'Article scientifique',
    'est_public' => 1,
    'statut' => 'Validé'
];

if ($departementId > 0) $filters['departement_id'] = $departementId;
if ($anneeId > 0) $filters['annee_academique_id'] = $anneeId;

// Récupérer les articles
$articles = $universite->getTravaux($search, $filters);

// Récupérer les données pour les filtres
$departements = $universite->getAllDepartments();
$academicYears = $universite->getAcademicYears();

// Calculer les statistiques
$stats = [
    'total_articles' => count($articles),
    'total_auteurs' => count(array_unique(array_column($articles, 'nom_auteur'))),
    'total_consultations' => array_sum(array_column($articles, 'nb_consultations')),
    'total_departements' => count(array_unique(array_column($articles, 'departement_id')))
];

include 'header2.php';
?>

<main class="py-5">
    <!-- Fil d'Ariane -->
    <div class="container mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index">Accueil</a></li>
                <li class="breadcrumb-item active">Articles scientifiques</li>
            </ol>
        </nav>
    </div>

    <!-- En-tête de la page -->
    <div class="bg-danger text-white py-4 mb-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="h2 mb-2">Articles scientifiques</h1>
                    <p class="lead mb-0">Publications et contributions scientifiques</p>
                </div>
                <div class="col-md-4">
                    <div class="row text-center g-2">
                        <div class="col-6">
                            <div class="border rounded p-3">
                                <div class="h3 mb-0"><?= number_format($stats['total_articles']) ?></div>
                                <small>Articles</small>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="border rounded p-3">
                                <div class="h3 mb-0"><?= number_format($stats['total_auteurs']) ?></div>
                                <small>Auteurs</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Filtres de recherche -->
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" action="" class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Rechercher</label>
                        <input type="text" name="search" class="form-control" placeholder="Titre, auteur, mots-clés..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Département</label>
                        <select name="departement" class="form-select">
                            <option value="">Tous les départements</option>
                            <?php foreach ($departements as $dept): ?>
                                <option value="<?= $dept['iddepartement'] ?>" <?= $departementId === $dept['iddepartement'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($dept['designationDepartement']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Année académique</label>
                        <select name="annee" class="form-select">
                            <option value="">Toutes les années</option>
                            <?php foreach ($academicYears as $year): ?>
                                <option value="<?= $year['idannee_acad'] ?>" <?= $anneeId === $year['idannee_acad'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($year['designation']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="fas fa-search me-2"></i> Rechercher
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Liste des articles -->
        <div class="row g-4">
            <?php if (!empty($articles)): ?>
                <?php foreach ($articles as $article): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-header bg-danger text-white">
                                <i class="fas fa-newspaper me-2"></i>
                                Article scientifique
                            </div>

                            <div class="card-body">
                                <!-- Titre -->
                                <h5 class="card-title mb-3">
                                    <a href="voir_travail?id=<?= $article['id'] ?>" class="text-decoration-none text-dark">
                                        <?= htmlspecialchars($article['titre']) ?>
                                    </a>
                                </h5>

                                <!-- Auteur(s) -->
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-users text-muted me-2"></i>
                                    <span>
                                        <?= htmlspecialchars($article['nom_auteur']) ?>
                                    </span>
                                </div>

                                <!-- Spécialisation -->
                                <?php if (!empty($article['specialisation'])): ?>
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-microscope text-muted me-2"></i>
                                    <span class="small">
                                        <?= htmlspecialchars($article['specialisation']) ?>
                                    </span>
                                </div>
                                <?php endif; ?>

                                <!-- Département et année -->
                                <div class="small text-muted mb-3">
                                    <i class="fas fa-university me-2"></i>
                                    <?= htmlspecialchars($article['designationDepartement']) ?>
                                    <br>
                                    <i class="fas fa-calendar-alt me-2"></i>
                                    <?= $article['annee'] ?>
                                </div>

                                <!-- Résumé -->
                                <p class="card-text small">
                                    <?= htmlspecialchars(substr($article['resume'], 0, 100)) ?>...
                                </p>

                                <!-- Mots-clés -->
                                <?php if (!empty($article['mots_cles'])): ?>
                                <div class="mt-2">
                                    <?php foreach (explode(',', $article['mots_cles']) as $motCle): ?>
                                        <span class="badge bg-light text-dark me-1">
                                            <?= trim(htmlspecialchars($motCle)) ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                <a href="voir_travail?id=<?= $article['id'] ?>" class="btn btn-sm btn-outline-danger">
                                    <i class="fas fa-eye me-1"></i> Consulter
                                </a>
                                <div class="text-muted small">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    <?= number_format($article['nb_consultations']) ?> vues
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Aucun article ne correspond à vos critères de recherche.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
.card {
    transition: transform 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card-title {
    font-size: 1.1rem;
    line-height: 1.4;
    height: 3.1em;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
}

.bg-danger {
    background: linear-gradient(135deg, var(--bs-danger) 0%, #dc3545 100%);
}
</style>

<?php include 'footer.php'; ?>