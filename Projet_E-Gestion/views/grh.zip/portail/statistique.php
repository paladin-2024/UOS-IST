<?php
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Universite.php';

$universite = new Universite();

// Récupérer les statistiques globales
$totalTravaux = $universite->countTravaux();
$totalAuteurs = $universite->countAuteurs();
$totalInstitutions = $universite->countInstitutions();
$totalConsultations = $universite->countConsultations();

// Récupérer les statistiques par type de document
$stats = $universite->getTravaux('', [
    'est_public' => 1,
    'statut' => 'Validé'
]);

$statsParType = [
    'Thèse' => 0,
    'Mémoire' => 0,
    'Article scientifique' => 0,
    'Projet tutoré' => 0,
    'Rapport de stage' => 0,
    'Livre' => 0,        // Ajout des livres
    'Cours' => 0         // Ajout des cours
];

$statsParDepartement = [];
$statsParAnnee = [];

foreach ($stats as $travail) {
    // Comptage par type
    $statsParType[$travail['type_document']]++;
    
    // Comptage par département
    $dept = $travail['designationDepartement'];
    if (!isset($statsParDepartement[$dept])) {
        $statsParDepartement[$dept] = 0;
    }
    $statsParDepartement[$dept]++;
    
    // Comptage par année
    $annee = $travail['annee'];
    if (!isset($statsParAnnee[$annee])) {
        $statsParAnnee[$annee] = 0;
    }
    $statsParAnnee[$annee]++;
}

// Trier les statistiques
arsort($statsParDepartement);
krsort($statsParAnnee);

include 'header2.php';
?>

<main class="py-5">
    <!-- Fil d'Ariane -->
    <div class="container mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index">Accueil</a></li>
                <li class="breadcrumb-item active">Statistiques</li>
            </ol>
        </nav>
    </div>

    <!-- En-tête statistiques globales -->
    <div class="bg-primary text-white py-4 mb-4">
        <div class="container">
            <h1 class="h2 mb-4">Statistiques de la bibliothèque numérique</h1>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="border rounded p-3 text-center">
                        <div class="display-4 mb-2"><?= number_format($totalTravaux) ?></div>
                        <div>Travaux publiés</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded p-3 text-center">
                        <div class="display-4 mb-2"><?= number_format($totalAuteurs) ?></div>
                        <div>Auteurs</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded p-3 text-center">
                        <div class="display-4 mb-2"><?= number_format($totalInstitutions) ?></div>
                        <div>Départements</div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="border rounded p-3 text-center">
                        <div class="display-4 mb-2"><?= number_format($totalConsultations) ?></div>
                        <div>Consultations</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row g-4">
            <!-- Répartition par type -->
            <div class="col-md-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-chart-pie me-2"></i>
                            Répartition par type de document
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="typeChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Évolution par année -->
            <div class="col-md-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-chart-line me-2"></i>
                            Évolution des publications
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="evolutionChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Top départements -->
            <div class="col-md-12">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-university me-2"></i>
                            Publications par département
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($statsParDepartement as $dept => $count): ?>
                            <div class="col-md-6 mb-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="text-truncate me-3">
                                        <?= htmlspecialchars($dept) ?>
                                    </div>
                                    <div class="d-flex align-items-center">
                                        <div class="progress flex-grow-1 me-2" style="width: 100px;">
                                            <div class="progress-bar" role="progressbar" 
                                                 style="width: <?= ($count / $totalTravaux * 100) ?>%">
                                            </div>
                                        </div>
                                        <span class="badge bg-primary"><?= $count ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Inclure Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Configuration des graphiques
document.addEventListener('DOMContentLoaded', function() {
    // Graphique des types de documents
    const typeCtx = document.getElementById('typeChart').getContext('2d');
    new Chart(typeCtx, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode(array_keys($statsParType)) ?>,
            datasets: [{
                data: <?= json_encode(array_values($statsParType)) ?>,
                backgroundColor: [
                    '#0d6efd', // Thèses
                    '#198754', // Mémoires
                    '#dc3545', // Articles
                    '#ffc107', // Projets
                    '#6c757d', // Rapports
                    '#20c997', // Livres
                    '#6610f2'  // Cours
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        // Ajuster la taille de la légende si nécessaire
                        font: {
                            size: 11
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: ${value} (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });

    // Graphique d'évolution
    const evolutionCtx = document.getElementById('evolutionChart').getContext('2d');
    new Chart(evolutionCtx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_keys($statsParAnnee)) ?>,
            datasets: [{
                label: 'Publications',
                data: <?= json_encode(array_values($statsParAnnee)) ?>,
                borderColor: '#0d6efd',
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
});
</script>

<style>
.chart-container {
    position: relative;
    margin: auto;
}

.progress {
    height: 8px;
    background-color: #e9ecef;
}

.progress-bar {
    background-color: #0d6efd;
}

.card {
    transition: transform 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.bg-primary {
    background: linear-gradient(135deg, var(--bs-primary) 0%, #0056b3 100%);
}
</style>

<?php include 'footer.php'; ?>