 
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row gy-4">
                <div class="col-md-4">
                    <h4 class="footer-heading">À propos de ScienceHub</h4>
                    <p>ScienceHub est une plateforme dédiée à la gestion et au partage des travaux scientifiques, permettant aux chercheurs d'accéder à une vaste collection de ressources académiques.</p>
                    <div class="mt-3">
                        <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#" class="social-icon"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <h4 class="footer-heading">Liens rapides</h4>
                    <a href="index" class="footer-link">Accueil</a>
                    <a href="recherche_avancee" class="footer-link">Recherche avancée</a>
                    <a href="login" class="footer-link">Soumettre un travail</a>
                    <a href="statistique" class="footer-link">Statistiques</a>
                </div>
                
                <div class="col-md-3">
                    <h4 class="footer-heading">Ressources</h4>
                    <a href="#" class="footer-link">Guide d'utilisation</a>
                    <a href="#" class="footer-link">FAQ</a>
                    <a href="#" class="footer-link">Normes bibliographiques</a>
                    <a href="#" class="footer-link">Propriété intellectuelle</a>
                </div>
                
                <div class="col-md-3">
                    <h4 class="footer-heading">Contact</h4>
                    <?php if (!empty($config['email'])): ?>
                        <p><i class="fas fa-envelope me-2"></i> <?= htmlspecialchars($config['email']) ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($config['telephone'])): ?>
                        <p><i class="fas fa-phone me-2"></i> <?= htmlspecialchars($config['telephone']) ?></p>
                    <?php endif; ?>
                    
                    <?php if (!empty($config['adresse']) || !empty($config['ville'])): ?>
                        <p>
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <?= htmlspecialchars($config['adresse']) ?>
                            <?php if (!empty($config['ville'])): ?>
                                <?= htmlspecialchars($config['ville']) ?>
                            <?php endif; ?>
                            <?php if (!empty($config['pays'])): ?>
                                , <?= htmlspecialchars($config['pays']) ?>
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                    
                    <?php if (!empty($config['site_web'])): ?>
                        <p><i class="fas fa-globe me-2"></i> <a href="<?= htmlspecialchars($config['site_web']) ?>" target="_blank" class="text-white"><?= htmlspecialchars($config['site_web']) ?></a></p>
                    <?php endif; ?>
                </div>
            </div>
            
            <hr class="mt-4 mb-3 border-secondary">
            
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; <?= date('Y') ?> ScienceHub. Tous droits réservés.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#" class="footer-link d-inline-block me-3">Mentions légales</a>
                    <a href="#" class="footer-link d-inline-block me-3">Politique de confidentialité</a>
                    <a href="#" class="footer-link d-inline-block">Cookies</a>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
