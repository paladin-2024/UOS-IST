<?php
// Vérification de la connexion
if (!isset($_SESSION['student_id'])) {
    header('Location: ../login');
    exit();
}

// Inclusion des fichiers nécessaires
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Etudiant.php';
require_once dirname(__DIR__) . '/../models/Universite.php';
require_once dirname(__DIR__) . '/../models/Agent.php';

// Initialisation des modèles
$etudiantModel = new Etudiant();
$universite = new Universite();
$agentModel = new Agent();

// Récupération des informations de l'étudiant
$studentId = $_SESSION['student_id'];
$studentInfo = $etudiantModel->getEtudiantById($studentId);

if (!$studentInfo) {
    header('Location: ../login');
    exit();
}

// Récupérer les promotions disponibles pour l'orientation de l'étudiant
$orientationId = $etudiantModel->getOrientationByPromotion($studentInfo['promotion_idpromotion']);
$promotions = [];

if ($orientationId) {
    $promotions = $etudiantModel->getPromotionsByOrientation($orientationId);
}

// Afficher les messages de succès ou d'erreur
$successMessage = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$errorMessage = isset($_SESSION['error']) ? $_SESSION['error'] : '';

// Nettoyer les messages de session
unset($_SESSION['success']);
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - ScienceHub Mobile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #004494;
            --secondary-color: #f5f5f5;
            --accent-color: #FFD700;
            --text-color: #333;
            --light-text: #fff;
        }

        body {
            background-color: var(--secondary-color);
            font-family: 'Roboto', sans-serif;
            padding-top: 70px;
            padding-bottom: 70px;
        }

        .mobile-header {
            background-color: var(--primary-color);
            padding: 15px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .profile-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 15px;
            object-fit: cover;
            border: 3px solid var(--primary-color);
        }

        .info-group {
            margin-bottom: 15px;
        }

        .info-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 5px;
        }

        .info-value {
            font-size: 1rem;
            color: var(--text-color);
        }

        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .nav-item {
            flex: 1;
            text-align: center;
            padding: 10px;
            color: var(--text-color);
            text-decoration: none;
        }

        .nav-item.active {
            color: var(--primary-color);
        }
        
        .edit-icon {
            cursor: pointer;
            color: var(--primary-color);
            transition: color 0.2s;
        }
        
        .edit-icon:hover {
            color: var(--accent-color);
        }
        
        /* Notification pour les messages */
        .toast-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1050;
        }
        
        .custom-toast {
            background-color: white;
            color: var(--text-color);
            border-left: 4px solid var(--primary-color);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Mobile Header -->
    <header class="mobile-header text-white">
        <div class="d-flex align-items-center">
            <a href="student" class="text-white text-decoration-none me-3">
                <i class="fas fa-arrow-left"></i>
            </a>
            <h1 class="h6 mb-0">Mon Profil</h1>
        </div>
    </header>

    <!-- Toast Container for Notifications -->
    <div class="toast-container">
        <?php if (!empty($successMessage)): ?>
        <div class="toast custom-toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="fas fa-check-circle text-success me-2"></i>
                <strong class="me-auto">Succès</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?= htmlspecialchars($successMessage) ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($errorMessage)): ?>
        <div class="toast custom-toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <i class="fas fa-exclamation-circle text-danger me-2"></i>
                <strong class="me-auto">Erreur</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?= htmlspecialchars($errorMessage) ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Content Area -->
    <div class="container">
        <div class="profile-section">
            <div class="profile-header">
                <img src="<?= isset($_SESSION['student_photo']) && !empty($_SESSION['student_photo']) 
                    ? '../uploads/' . $_SESSION['student_photo'] 
                    : '../uploads/user.png' ?>" 
                    alt="Photo de profil" class="profile-avatar">
                <h2 class="h5 mb-1"><?= htmlspecialchars($studentInfo['noms']) ?></h2>
                <p class="text-muted mb-0"><?= htmlspecialchars($studentInfo['matricule']) ?></p>
            </div>

            <div class="info-group">
                <div class="info-label">Email</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['adressemail'] ?? 'Non renseigné') ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Téléphone</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['telephone'] ?? 'Non renseigné') ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Date de naissance</div>
                <div class="info-value">
                    <?= $studentInfo['dateNaissance'] ? date('d/m/Y', strtotime($studentInfo['dateNaissance'])) : 'Non renseigné' ?>
                </div>
            </div>

            <div class="info-group">
                <div class="info-label">Lieu de naissance</div>
                <div class="info-value">
                    <?= htmlspecialchars($studentInfo['lieuNaissance'] ?? 'Non renseigné') ?>
                </div>
            </div>

            <div class="info-group">
                <div class="info-label">Nationalité</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['nationalite']) ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Sexe</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['sexe']) ?></div>
            </div>

            <div class="info-group">
                <div class="info-label">Promotion</div>
                <div class="info-value d-flex align-items-center">
                    <?= htmlspecialchars($studentInfo['promotion']) ?>
                    <i class="fas fa-edit edit-icon ms-2" onclick="showChangePromotionModal()"></i>
                </div>
            </div>
            
            <div class="info-group">
                <div class="info-label">Orientation</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['orientation'] ?? 'Non définie') ?></div>
            </div>
            
            <div class="info-group">
                <div class="info-label">Année académique</div>
                <div class="info-value"><?= htmlspecialchars($studentInfo['annee_academique']) ?></div>
            </div>

            <div class="mt-4">
                <button class="btn btn-primary w-100 mb-2" onclick="showChangePasswordModal()">
                    <i class="fas fa-key me-2"></i>Changer le mot de passe
                </button>
                <a href="../controller/logout.php" class="btn btn-outline-danger w-100">
                    <i class="fas fa-sign-out-alt me-2"></i>Déconnexion
                </a>
            </div>
        </div>
    </div>

    <!-- Modal Changement de mot de passe -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Changer le mot de passe</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="changePasswordForm" action="../controller/change_password.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="currentPassword" class="form-label">Mot de passe actuel</label>
                            <input type="password" class="form-control" id="currentPassword" 
                                   name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="newPassword" class="form-label">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="newPassword" 
                                   name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirmer le mot de passe</label>
                            <input type="password" class="form-control" id="confirmPassword" 
                                   name="confirm_password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Changer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Changement de promotion -->
    <div class="modal fade" id="changePromotionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Changer de promotion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="changePromotionForm" action="../controller/update_promotion.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="promotion_id" class="form-label">Nouvelle promotion</label>
                            <select class="form-select" id="promotion_id" name="promotion_id" required>
                                <option value="">Sélectionnez une promotion</option>
                                <?php if (isset($promotions) && is_array($promotions)): ?>
                                    <?php foreach ($promotions as $promotion): ?>
                                        <option value="<?= $promotion['idpromotion'] ?>" 
                                                <?= ($promotion['idpromotion'] == $studentInfo['promotion_idpromotion']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($promotion['designationPromotion']) ?> 
                                            (<?= htmlspecialchars($promotion['cycle']) ?>) - 
                                            <?= htmlspecialchars($promotion['annee_academique']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                </select>
                            <div class="form-text text-muted">
                                Changer de promotion peut affecter vos sujets de recherche et vos tâches.
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Changer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <div class="d-flex justify-content-around">
            <a href="student" class="nav-item">
                <i class="fas fa-home d-block"></i>
                <small>Accueil</small>
            </a>
            <a href="student#tasks" class="nav-item">
                <i class="fas fa-tasks d-block"></i>
                <small>Tâches</small>
            </a>
            <a href="#" class="nav-item">
                <i class="fas fa-comment d-block"></i>
                <small>Messages</small>
            </a>
            <a href="#" class="nav-item active">
                <i class="fas fa-user d-block"></i>
                <small>Profil</small>
            </a>
        </div>
    </nav>

    <!-- JavaScript Dependencies -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialisation des composants Bootstrap
        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM chargé - initialisation des composants profile.php');
            
            // Auto-hide toasts after 5 seconds
            const toasts = document.querySelectorAll('.toast');
            toasts.forEach(toastEl => {
                const toast = new bootstrap.Toast(toastEl, {
                    autohide: true,
                    delay: 5000
                });
                toast.show();
            });
            
            // Form validation for password change
            const changePasswordForm = document.getElementById('changePasswordForm');
            if (changePasswordForm) {
                changePasswordForm.addEventListener('submit', function(e) {
                    const newPassword = document.getElementById('newPassword').value;
                    const confirmPassword = document.getElementById('confirmPassword').value;

                    if (newPassword !== confirmPassword) {
                        e.preventDefault();
                        alert('Les mots de passe ne correspondent pas');
                        return false;
                    }
                    
                    if (newPassword.length < 6) {
                        e.preventDefault();
                        alert('Le mot de passe doit contenir au moins 6 caractères');
                        return false;
                    }
                });
            } else {
                console.error('Formulaire de changement de mot de passe non trouvé');
            }
            
            console.log('Initialisation des composants profile.php terminée');
        });

        // Fonction pour afficher le modal de changement de mot de passe
        function showChangePasswordModal() {
            const modal = new bootstrap.Modal(document.getElementById('changePasswordModal'));
            if (modal) {
                modal.show();
            } else {
                console.error('Modal de changement de mot de passe non trouvé');
            }
        }

        // Fonction pour afficher le modal de changement de promotion
        function showChangePromotionModal() {
            const modal = new bootstrap.Modal(document.getElementById('changePromotionModal'));
            if (modal) {
                modal.show();
            } else {
                console.error('Modal de changement de promotion non trouvé');
            }
        }
    </script>
</body>
</html>
