<?php
error_reporting(E_ALL); 
ini_set("display_errors", 1);

// Vérification de la connexion
if (!isset($_SESSION['student_id'])) {
    header('Location: login');
    exit();
}

// Inclure les fichiers de modèle nécessaires
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Etudiant.php';
require_once dirname(__DIR__) . '/../models/Universite.php';
require_once dirname(__DIR__) . '/../models/Agent.php';
require_once dirname(__DIR__) . '/../models/Cours.php';

// Initialisation des modèles
$etudiantModel = new Etudiant();
$universite = new Universite();
$agentModel = new Agent();
$coursModel=new Cours();
$ecueModel = new Ecue();  // Ajoutez cette ligne
$currentYear=$universite->getCurrentAcademicYear();

// Récupération des informations de l'étudiant
$studentId = $_SESSION['student_id'];
$studentName = $_SESSION['student_name'] ?? 'Étudiant';
$studentMatricule = $_SESSION['student_matricule'] ?? '';  // Ajoutez cette ligne
$orientationId = $_SESSION['orientation_id'] ?? null;
$cycle = $_SESSION['cycle'] ?? null;

// Récupération des sujets disponibles
$sujetsDisponibles = $etudiantModel->getSujetsDisponibles($orientationId, $cycle);

// Récupération des tâches si un sujet est assigné
$sujetAssigne = $etudiantModel->getSujetAssigne($studentId);
$sujetId = $sujetAssigne ? $sujetAssigne['idsujets'] : null;
$taches = [];

if ($sujetAssigne) {
    // Ne récupérer les tâches que si le sujet est validé
    if ($sujetAssigne['statut_validation'] === 'Validé') {
        $taches = $etudiantModel->getTaches($sujetId);
    }
}

// Récupération des compteurs de notifications
$notifications = $etudiantModel->getNotificationCounters($studentId);

// Fonctions utilitaires
function getTypeAuteurClass($type, $isCurrentUser = false) {
    if ($isCurrentUser) {
        return 'warning';
    }
    
    return match ($type) {
        'Directeur' => 'primary',
        'Encadreur' => 'success',
        'Etudiant' => 'info',
        default => 'secondary',
    };
}

function getTypeAuteurLabel($type, $isCurrentUser = false) {
    if ($isCurrentUser) {
        return 'Vous';
    }
    
    return $type;
}

function getStatusColor($status) {
    return match (strtolower($status)) {
        'en attente' => 'warning',
        'validé', 'validée', 'terminé', 'terminée' => 'success',
        'rejeté', 'rejetée', 'refusé', 'refusée' => 'danger',
        'en cours' => 'info',
        default => 'secondary'
    };
}

$configUniversitee = $universite->getConfigurationUniversite();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portail Étudiant - ScienceHub Mobile</title>

    <?php if (!empty($configUniversitee['logo'])): ?>
        <!-- Favicons --> 
	<link href="../<?= htmlspecialchars($configUniversitee['logo']) ?>" rel="icon">
	<link href="../<?= htmlspecialchars($configUniversitee['logo']) ?>" rel="apple-touch-icon">
    <?php endif; ?>
    
    <!-- Feuilles de style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="../assets/css/notification-styles.css">
    
    <style>
        :root {
            --primary-color: #004494;
            --secondary-color: #f5f5f5;
            --accent-color: #FFD700;
            --text-color: #333;
            --light-text: #fff;
        }

        body {
            background-color: var(--secondary-color);
            font-family: 'Roboto', sans-serif;
            padding-top: 70px;
            padding-bottom: 70px;
        }

        .mobile-header {
            background-color: var(--primary-color);
            padding: 15px;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
        }

        .nav-item {
            flex: 1;
            text-align: center;
            padding: 10px;
            color: var(--text-color);
            text-decoration: none;
        }

        .nav-item.active {
            color: var(--primary-color);
        }

        .content-area {
            padding: 15px;
        }

        .subject-card, .task-card {
            background: white;
            border-radius: 10px;
            margin-bottom: 15px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            color: white;
        }

        .fab {
            position: fixed;
            bottom: 80px;
            right: 20px;
            width: 56px;
            height: 56px;
            border-radius: 28px;
            background: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            text-decoration: none;
        }

        .profile-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: none;
            z-index: 1001;
        }

        .profile-menu.show {
            display: block;
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: red;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 10px;
        }

        /* Timeline styles */
        .timeline {
            position: relative;
            padding: 20px 0;
            list-style: none;
            max-height: 300px;
            overflow-y: auto;
        }

        .timeline-item {
            position: relative;
            padding-left: 24px;
            margin-bottom: 20px;
        }

        .timeline-marker {
            position: absolute;
            left: 0;
            top: 0;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 0 0 2px #dee2e6;
        }

        .timeline-content {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .timeline:before {
            content: '';
            position: absolute;
            left: 5px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }

        /* Sidebar styles */
        .sidebar {
            position: fixed;
            left: 0;
            top: 70px;
            bottom: 70px;
            width: 250px;
            background-color: white;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            z-index: 999;
            overflow-y: auto;
            transform: translateX(-100%);
            transition: transform 0.3s ease-in-out;
        }

        .sidebar.show {
            transform: translateX(0);
        }

        .sidebar-header {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        .sidebar-profile {
            background-color: rgba(0, 0, 0, 0.03);
        }

        .sidebar .nav-link {
            color: var(--text-color);
            padding: 0.8rem 1rem;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .sidebar .nav-link i {
            width: 24px;
            margin-right: 10px;
            text-align: center;
        }

        .sidebar .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
            color: var(--primary-color);
        }

        .sidebar .nav-link.active {
            background-color: var(--primary-color);
            color: white;
        }

        .required:after {
            content: " *";
            color: red;
        }
        
        .modal-body {
            max-height: calc(100vh - 210px);
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Mobile Header -->
    <header class="mobile-header text-white">
        <div class="d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <div class="menu-toggle me-3" id="menuToggle">
                    <i class="fas fa-bars"></i>
                </div>
                <h1 class="h6 mb-0">ScienceHub</h1>
            </div>
            <div class="d-flex align-items-center">
                <div class="position-relative">
                    <img src="../uploads/user.png" alt="Profile" 
                         class="rounded-circle" width="30" id="profileIcon">
                    <div class="profile-menu" id="profileMenu">
                        <div class="p-3">
                            <div class="d-flex align-items-center mb-3">
                                <img src="../uploads/user.png" alt="Profile" 
                                     class="rounded-circle me-2" width="40">
                                <div>
                                    <strong><?php echo htmlspecialchars($studentName); ?></strong>
                                    <div class="small text-muted">Étudiant</div>
                                </div>
                            </div>
                            <a href="profile" class="btn btn-outline-primary btn-sm w-100 mb-2">
                                Mon Profil
                            </a>
                            <a href="../controller/logout.php" class="btn btn-outline-danger btn-sm w-100">
                                Déconnexion
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <!-- Profil -->
        <div class="sidebar-profile p-3 border-bottom">
            <div class="d-flex align-items-center">
                <div class="position-relative">
                    <img src="<?= isset($_SESSION['student_photo']) && !empty($_SESSION['student_photo']) 
                        ? '../uploads/' . $_SESSION['student_photo'] 
                        : '../uploads/user.png' ?>" 
                        alt="Photo de profil"
                        class="rounded-circle me-3"
                        width="50"
                        height="50">
                </div>
                <div>
                    <h6 class="mb-1"><?= htmlspecialchars($studentName) ?></h6>
                    <small class="text-muted">Étudiant</small>
                </div>
            </div>
        </div>

        <!-- Menu de navigation -->
        <div class="sidebar-menu">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a href="#" class="nav-link active" data-page="home">
                        <i class="fas fa-home"></i>
                        <span>Accueil</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-page="tasks">
                        <i class="fas fa-tasks"></i>
                        <span>Mes Tâches</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-page="subjects">
                        <i class="fas fa-book"></i>
                        <span>Sujets Disponibles</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-page="evaluations">
                        <i class="fas fa-chart-bar"></i>
                        <span>Mes Notes</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-page="progress">
                    <li class="nav-item">
                    <a href="#" class="nav-link" data-page="progress">
                        <i class="fas fa-chart-line"></i>
                        <span>Ma Progression</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" data-page="messages">
                        <i class="fas fa-comments"></i>
                        <span>Messages</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="profile" class="nav-link" data-page="profile">
                        <i class="fas fa-user"></i>
                        <span>Mon Profil</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link" id="proposerSujetSidebar">
                        <i class="fas fa-plus-circle"></i>
                        <span>Proposer un Sujet</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- Content Area -->
    <div class="content-area">
        <!-- Tabs -->
        <ul class="nav nav-pills mb-3" id="mainTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="subjects-tab" data-bs-toggle="tab" 
                        data-bs-target="#subjects" type="button"><i class="fas fa-folder"></i> Sujets</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="tasks-tab" data-bs-toggle="tab" 
                        data-bs-target="#tasks" type="button"><i class="fas fa-list"></i> Tâches</button>
            </li>
            <!-- Ajouter un nouvel onglet pour les cours -->
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="courses-tab" data-bs-toggle="tab" 
                        data-bs-target="#courses" type="button"><i class="fas fa-book"></i> Mes Cours</button>
            </li>
            <li class="nav-item" role="presentation">
            <button class="nav-link" id="evaluations-tab" data-bs-toggle="tab" 
                    data-bs-target="#evaluations" type="button"><i class="fas fa-chart-bar"></i> Mes Notes</button>
            </li>

        </ul>
                <!-- Tab Content -->
                <div class="tab-content" id="mainTabContent">
            <!-- Subjects Tab -->
            <div class="tab-pane fade show active" id="subjects" role="tabpanel">
                <?php if (empty($sujetsDisponibles)): ?>
                    <div class="alert alert-info">
                        Aucun sujet disponible pour le moment.
                    </div>
                <?php else: ?>
                    <?php foreach ($sujetsDisponibles as $sujet): ?>
                        <div class="subject-card">
                            <h5 class="card-title"><?= htmlspecialchars($sujet['intitule']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($sujet['unite_recherche']) ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    Spécialisation: <?= htmlspecialchars($sujet['specialisation']) ?>
                                </small>
                                <button type="button" class="btn btn-primary btn-sm" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#choixEncadreursModal<?= $sujet['idsujets'] ?>">
                                    Choisir ce sujet
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <!-- Modals pour chaque sujet -->
                    <?php foreach ($sujetsDisponibles as $sujet): ?>
                        <div class="modal fade" id="choixEncadreursModal<?= $sujet['idsujets'] ?>" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Choisir les encadrants</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="../controller/choisir_sujet.php" method="POST" 
                                        id="formChoixSujet<?= $sujet['idsujets'] ?>">
                                        <div class="modal-body">
                                            <input type="hidden" name="sujet_id" value="<?= $sujet['idsujets'] ?>">
                                            
                                            <!-- Détails du sujet -->
                                            <div class="mb-4">
                                                <h6>Sujet sélectionné :</h6>
                                                <p class="mb-1"><strong><?= htmlspecialchars($sujet['intitule']) ?></strong></p>
                                                <small class="text-muted">
                                                    <?= htmlspecialchars($sujet['unite_recherche']) ?>
                                                </small>
                                            </div>

                                            <!-- Sélection du Directeur -->
                                            <div class="mb-3">
                                                <label for="directeur<?= $sujet['idsujets'] ?>" class="form-label required">
                                                    Directeur de mémoire
                                                </label>
                                                <select class="form-select" id="directeur<?= $sujet['idsujets'] ?>" 
                                                        name="directeur_id" required>
                                                    <option value="">Sélectionnez un directeur</option>
                                                    <?php 
                                                    
                                                    
                                                    // Récupération des enseignants depuis la table agent
                                                    $directeurs = $agentModel->getAgentsByType('Enseignant');
                                                    foreach ($directeurs as $directeur):
                                                        
                                                    ?>
                                                        <option value="<?= $directeur['idAgent'] ?>">
                                                            <?= htmlspecialchars($directeur['gradeDesignation']." ".$directeur['noms']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                            <!-- Sélection de l'Encadreur -->
                                            <div class="mb-3">
                                                <label for="encadreur<?= $sujet['idsujets'] ?>" class="form-label">
                                                    Co-encadreur (optionnel)
                                                </label>
                                                <select class="form-select" id="encadreur<?= $sujet['idsujets'] ?>" 
                                                        name="encadreur_id">
                                                    <option value="">Sélectionnez un co-encadreur</option>
                                                    <?php 
                                                    // Pour le co-encadreur, tous les grades sont autorisés
                                                    foreach ($directeurs as $encadreur): ?>
                                                        <option value="<?= $encadreur['idAgent'] ?>">
                                                            <?= htmlspecialchars(($encadreur['gradeDesignation'] ? $encadreur['gradeDesignation'] . ' ' : '') . 
                                                                $encadreur['noms']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                            <!-- Message d'information -->
                                            <div class="alert alert-info">
                                                <small>
                                                    <i class="fas fa-info-circle"></i>
                                                    Le choix du sujet et des encadrants devra être validé par l'administration.
                                                </small>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                Annuler
                                            </button>
                                            <button type="submit" class="btn btn-primary">
                                                Confirmer le choix
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Tasks Tab -->
            <div class="tab-pane fade" id="tasks" role="tabpanel">
                <?php if ($sujetAssigne): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <h5 class="card-title">Mon sujet</h5>
                                <?php if ($sujetAssigne && $sujetAssigne['statut_validation'] === 'Validé'): ?>
                                    <a target="_" href="export_fiche_avancement?etudiant_id=<?= $studentId ?>" 
                                    class="btn btn-sm btn-success">
                                        <i class="fas fa-file-export"></i> Exporter ma fiche d'avancement
                                    </a>
                                <?php endif; ?>
                            </div>
                            <p class="mb-1"><strong><?= htmlspecialchars($sujetAssigne['intitule']) ?></strong></p>
                            <p class="mb-1 text-muted">
                                <small>Unité de recherche : <?= htmlspecialchars($sujetAssigne['unite_recherche'] ?? '') ?></small>
                            </p>
                            <p class="mb-1">
                                <small>Directeur : <?= htmlspecialchars($sujetAssigne['directeur'] ?? '') ?></small>
                            </p>
                            <?php if (!empty($sujetAssigne['encadreur'])): ?>
                                <p class="mb-1">
                                    <small>Co-encadreur : <?= htmlspecialchars($sujetAssigne['encadreur']) ?></small>
                                </p>
                            <?php endif; ?>
                            <div class="mt-2">
                                <span class="badge bg-<?= getStatusColor($sujetAssigne['statut_validation']) ?>">
                                    <?= htmlspecialchars($sujetAssigne['statut_validation']) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <?php if ($sujetAssigne['statut_validation'] === 'Validé'): ?>
                        <!-- Liste des tâches -->
                        <?php if (empty($taches)): ?>
                            <div class="alert alert-info">
                                Aucune tâche pour le moment.
                            </div>
                        <?php else: ?>
                            <?php foreach ($taches as $tache): 
                                $echanges = $etudiantModel->getEchangesTache($tache['idtaches']);
                            ?>
                                <div class="task-card">
                                    <!-- En-tête de la tâche -->
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div>
                                            <h6><?= htmlspecialchars($tache['description']) ?></h6>
                                            <small class="text-muted">
                                                Date: <?= date('d/m/Y', strtotime($tache['dateTache'])) ?>
                                            </small>
                                        </div>
                                        <span class="status-badge bg-<?= getStatusColor($tache['validation']) ?>">
                                            <?= htmlspecialchars($tache['validation']) ?>
                                        </span>
                                    </div>

                                    <!-- Fichier initial de la tâche -->
                                    <?php if ($tache['fichierTache']): ?>
                                        <div class="mb-3">
                                            <a href="../uploads/<?= htmlspecialchars($tache['fichierTache']) ?>" 
                                               class="btn btn-sm btn-outline-primary" target="_blank">
                                                <i class="fas fa-download"></i> Fichier initial
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Timeline des échanges -->
                                    <?php if (!empty($echanges)): ?>
                                        <div class="timeline mt-3">
                                            <?php foreach ($echanges as $echange): ?>
                                                <?php 
                                                // Vérifie si l'auteur du message est l'utilisateur actuel
                                                $isCurrentUser = ($echange['idAuteur'] == $_SESSION['student_id']);
                                                $typeClass = getTypeAuteurClass($echange['type_auteur'], $isCurrentUser);
                                                $auteurLabel = $isCurrentUser ? 'Vous' : $echange['type_auteur'];
                                                ?>
                                                <div class="timeline-item">
                                                    <div class="timeline-marker bg-<?= getTypeAuteurClass($echange['type_auteur']) ?>"></div>
                                                    <div class="timeline-content">
                                                        <div class="d-flex justify-content-between align-items-start">
                                                            <strong class="text-<?= getTypeAuteurClass($echange['type_auteur']) ?>">
                                                                <?= htmlspecialchars($auteurLabel) ?>
                                                            </strong>
                                                            <small class="text-muted">
                                                                <?= date('d/m/Y H:i', strtotime($echange['dateEchange'])) ?>
                                                            </small>
                                                        </div>
                                                        <p class="mb-2">
                                                            <?= nl2br(htmlspecialchars($echange['commentaire'])) ?>
                                                        </p>
                                                        <?php if ($echange['fichierJoint']): ?>
                                                            <a href="../uploads/<?= htmlspecialchars($echange['fichierJoint']) ?>" 
                                                               class="btn btn-sm btn-outline-secondary" target="_blank">
                                                                <i class="fas fa-file-download"></i> 
                                                                Voir le fichier joint
                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Bouton de réponse -->
                                    <button class="btn btn-primary btn-sm mt-3" 
                                            onclick="showReplyModal(<?= $tache['idtaches'] ?>)">
                                        <i class="fas fa-reply"></i> Répondre
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <!-- Formulaire d'ajout de tâche -->
                        <div class="card mt-3">
                            <div class="card-body">
                                <h5 class="card-title">Nouvelle tâche</h5>
                                <form action="../controller/ajouter_tache.php" method="POST" enctype="multipart/form-data">
                                    <div class="mb-3">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description" required></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="fichier" class="form-label">Fichier (optionnel)</label>
                                        <input type="file" class="form-control" id="fichier" name="fichier">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Ajouter la tâche</button>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            Votre sujet est en attente de validation. Vous pourrez ajouter des tâches une fois qu'il sera validé.
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        Vous n'avez pas encore de sujet assigné. Veuillez d'abord choisir un sujet dans l'onglet "Sujets".
                    </div>
                <?php endif; ?>
            </div>

            
            <!-- Onglet Cours -->
<div class="tab-pane fade" id="courses" role="tabpanel">
    <h4 class="mb-3">Mes cours</h4>
    
    <?php 
    // Récupérer les cours de l'étudiant
    $promotion = isset($_SESSION['promotion_id']) ? $_SESSION['promotion_id'] : 0;
    $cours = $coursModel->getCoursByPromotion($promotion, $currentYear['idannee_acad']);
    
    if (empty($cours)): 
    ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            Aucun cours disponible pour le moment.
        </div>
    <?php else: ?>
        <div class="list-group">
            <?php foreach ($cours as $c): ?>
                <a href="#" class="list-group-item list-group-item-action" 
                onclick="loadCourseDetails(<?= $c['idECUE'] ?>)">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?= htmlspecialchars($c['designationECUE']) ?></h5>
                        <small class="text-muted"><?= htmlspecialchars($c['designationUE']) ?></small>
                    </div>
                    <p class="mb-1">
                        <small>
                            <strong>Semestre:</strong> <?= htmlspecialchars($c['numeroSemestre']) ?>
                            &bull; <strong>Volume horaire:</strong> CMI: <?= $c['CMI'] ?>h, TD: <?= $c['TD'] ?>h, TP: <?= $c['TP'] ?>h
                        </small>
                    </p>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <!-- Modal pour les détails d'un cours -->
    <div class="modal fade" id="courseDetailsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="courseTitle">Détails du cours</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="courseContent">
                        <div class="text-center">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Chargement...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal pour soumettre un devoir -->
    <div class="modal fade" id="submitAssignmentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Soumettre une réponse</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="submitAssignmentForm" method="POST" action="../controller/submit_assignment.php" enctype="multipart/form-data">
                        <input type="hidden" name="iddevoir" id="submission_iddevoir">
                        <input type="hidden" name="idetudiant" value="<?= $studentId ?>">
                        
                        <div class="mb-3">
                            <label for="submission_commentaire" class="form-label">Commentaire (optionnel)</label>
                            <textarea class="form-control" id="submission_commentaire" name="commentaire" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="submission_fichier" class="form-label">Fichier (PDF, DOCX, ZIP, etc.)</label>
                            <input type="file" class="form-control" id="submission_fichier" name="fichier" required>
                            <div class="invalid-feedback">Veuillez sélectionner un fichier à soumettre.</div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-primary">Soumettre</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Onglet Notes/Évaluations -->
<div class="tab-pane fade" id="evaluations" role="tabpanel">
    <h4 class="mb-3">Mes notes</h4>
    
    <?php 
    // Récupérer les cours de l'étudiant
    $promotion = isset($_SESSION['promotion_id']) ? $_SESSION['promotion_id'] : 0;
    $coursEtudiant = $coursModel->getCoursByPromotion($promotion, $currentYear['idannee_acad']);
    
    // Vérifier si des cours existent
    if (empty($coursEtudiant)): 
    ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle me-2"></i>
            Aucun cours disponible pour afficher les notes.
        </div>
    <?php else: ?>
        <div class="accordion" id="accordionEvaluations">
            <?php 
            $matricule = isset($_SESSION['student_matricule']) ? $_SESSION['student_matricule'] : '';
            $allCourses = [];
            
            // Récupérer les données des cours et de leurs évaluations
            foreach ($coursEtudiant as $index => $cours):
                $evaluations = $ecueModel->getEvaluationsByEcue($cours['idECUE'], $currentYear['idannee_acad']);
                $evaluationsPubliques = array_filter($evaluations, function($eval) {
                    return $eval['est_visible'] == 1;
                });
                
                if (!empty($evaluationsPubliques)):
                    $allCourses[] = [
                        'cours' => $cours,
                        'evaluations' => $evaluationsPubliques
                    ];
                endif;
            endforeach;
            
            if (empty($allCourses)):
            ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Aucune évaluation publiée pour le moment.
                </div>
            <?php else: ?>
                <?php foreach ($allCourses as $index => $courseData): 
                    $cours = $courseData['cours'];
                    $evaluations = $courseData['evaluations'];
                    
                    // Récupérer les notes de l'étudiant pour ce cours
                    $notes = $ecueModel->getStudentGrades($studentId, $cours['idECUE'], $currentYear['idannee_acad']);
                    
                    // Regrouper les évaluations par session
                    $evalsBySession = [];
                    foreach ($evaluations as $eval) {
                        $sessionId = $eval['session_idsession'];
                        if (!isset($evalsBySession[$sessionId])) {
                            $evalsBySession[$sessionId] = [
                                'session' => $eval['designSession'],
                                'evaluations' => []
                            ];
                        }
                        $evalsBySession[$sessionId]['evaluations'][] = $eval;
                    }
                ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?= $cours['idECUE'] ?>">
                            <button class="accordion-button <?= $index > 0 ? 'collapsed' : '' ?>" type="button" 
                                    data-bs-toggle="collapse" data-bs-target="#collapse<?= $cours['idECUE'] ?>" 
                                    aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>" 
                                    aria-controls="collapse<?= $cours['idECUE'] ?>">
                                <strong><?= htmlspecialchars($cours['designationECUE']) ?></strong>
                                <span class="ms-auto badge bg-secondary">
                                    <?= htmlspecialchars($cours['numeroSemestre']) ?>
                                </span>
                            </button>
                        </h2>
                        <div id="collapse<?= $cours['idECUE'] ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" 
                             aria-labelledby="heading<?= $cours['idECUE'] ?>" data-bs-parent="#accordionEvaluations">
                            <div class="accordion-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th colspan="4" class="text-center bg-light">
                                                    <?= htmlspecialchars($cours['designationECUE']) ?> - <?= htmlspecialchars($cours['designationUE']) ?>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($evalsBySession as $sessionId => $sessionData): ?>
                                                <tr class="table-secondary">
                                                    <th colspan="4">Session: <?= htmlspecialchars($sessionData['session']) ?></th>
                                                </tr>
                                                <tr>
                                                    <th width="5%">N°</th>
                                                    <th width="45%">Évaluation</th>
                                                    <th width="20%">Date</th>
                                                    <th width="30%">Note</th>
                                                </tr>
                                                <?php 
                                                $evalCount = 1;
                                                $sessionTotal = 0;
                                                $coeffTotal = 0;
                                                
                                                foreach ($sessionData['evaluations'] as $eval): 
                                                    // Trouver la note pour cette évaluation
                                                    $note = null;
                                                    foreach ($notes as $n) {
                                                        if ($n['idevaluation'] == $eval['idevaluation']) {
                                                            $note = $n['coteObtenu'];
                                                            if ($note !== null) {
                                                                $sessionTotal += $note * $eval['ponderation'];
                                                                $coeffTotal += $eval['ponderation'];
                                                            }
                                                            break;
                                                        }
                                                    }
                                                    
                                                    // Déterminer la classe CSS selon la note
                                                    $noteClass = '';
                                                    if ($note !== null) {
                                                        if ($note < 10) $noteClass = 'text-danger';
                                                        elseif ($note >= 16) $noteClass = 'text-success';
                                                    }
                                                ?>
                                                    <tr>
                                                        <td><?= $evalCount++ ?></td>
                                                        <td>
                                                            <?= htmlspecialchars($eval['titre']) ?> 
                                                            <span class="badge bg-info"><?= htmlspecialchars($eval['designationT']) ?></span>
                                                            <br>
                                                            <small class="text-muted">Pondération: <?= $eval['ponderation'] ?></small>
                                                        </td>
                                                        <td><?= date('d/m/Y', strtotime($eval['date_evaluation'])) ?></td>
                                                        <td class="<?= $noteClass ?>">
                                                            <?php if ($note !== null): ?>
                                                                <strong><?= number_format($note, 2) ?>/20</strong>
                                                            <?php else: ?>
                                                                <span class="text-muted">Non disponible</span>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                                
                                                <?php if ($coeffTotal > 0): 
                                                    $moyenne = $sessionTotal / $coeffTotal;
                                                    $moyenneClass = '';
                                                    if ($moyenne < 10) $moyenneClass = 'text-danger';
                                                    elseif ($moyenne >= 16) $moyenneClass = 'text-success';
                                                ?>
                                                    <tr class="table-light">
                                                        <td colspan="3" class="text-end"><strong>Moyenne:</strong></td>
                                                        <td class="<?= $moyenneClass ?>">
                                                            <strong><?= number_format($moyenne, 2) ?>/20</strong>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>


            





        </div>
    </div>

    <!-- Modal de réponse -->
    <div class="modal fade" id="replyModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Répondre</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="../controller/ajouter_echange.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="tache_id" id="reply_tache_id">
                        <input type="hidden" name="type_auteur" value="Etudiant">
                        <input type="hidden" name="id_auteur" value="<?= $studentId ?>">
                        
                        <div class="mb-3">
                            <label for="commentaire" class="form-label">Votre réponse</label>
                            <textarea class="form-control" id="commentaire" name="commentaire" rows="4" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="fichier" class="form-label">Fichier (optionnel)</label>
                            <input type="file" class="form-control" id="fichier" name="fichier">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Envoyer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Floating Action Button -->
    <a href="#" class="fab" id="proposerSujetBtn">
        <i class="fas fa-plus"></i>
    </a>

    <!-- Modal Proposition Sujet -->
    <div class="modal fade" id="proposerSujetModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Proposer un sujet de recherche</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="proposerSujetForm" method="POST" action="../controller/proposer_sujet.php">
                        <input type="hidden" name="etudiant_id" value="<?= $studentId ?>">
                        
                        <div class="mb-4">
                            <label for="intitule" class="form-label required">Intitulé du sujet</label>
                            <input type="text" class="form-control" id="intitule" name="intitule" required>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label for="idSpecialisation" class="form-label required">Spécialisation</label>
                                <select class="form-select" id="idSpecialisation" name="idSpecialisation" required>
                                    <option value="">Sélectionner une spécialisation</option>
                                    <?php 
                                    // Récupérer les spécialisations de l'orientation
                                    $specialisations = $universite->getSpecialisationsByOrientation($orientationId);
                                    if ($specialisations):
                                        foreach ($specialisations as $specialisation): 
                                    ?>
                                        <option value="<?= $specialisation['idSpecialisation'] ?>">
                                            <?= htmlspecialchars($specialisation['designation']) ?>
                                            (<?= htmlspecialchars($specialisation['unite_recherche']) ?>)
                                        </option>
                                    <?php 
                                        endforeach;
                                    endif;
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="annee_acad" class="form-label required">Année Académique</label>
                                <select class="form-select" id="annee_acad" name="annee_acad" required>
                                    <?php 
                                    // Récupérer l'année académique actuelle
                                    $currentYear = $universite->getCurrentAcademicYear();
                                    if ($currentYear):
                                    ?>
                                        <option value="<?= $currentYear['idannee_acad'] ?>">
                                            <?= htmlspecialchars($currentYear['designation']) ?>
                                        </option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Sélection du Directeur -->
                        <div class="mb-4">
                            <label for="directeur" class="form-label required">Directeur de mémoire</label>
                            <select class="form-select" id="directeur" name="directeur_id" required>
                                <option value="">Sélectionner un directeur</option>
                                <?php 
                                
                                // Récupération des enseignants depuis la table agent
                                $enseignants = $agentModel->getAgentsByType('Enseignant');
                                if ($enseignants):
                                    foreach ($enseignants as $enseignant):
                                        $grade = $enseignant['gradeDesignation'];
                                ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= htmlspecialchars($grade . ' ' . $enseignant['noms']) ?>
                                    </option>
                                <?php 
                                    endforeach;
                                endif;
                                ?>
                            </select>
                        </div>

                        <!-- Sélection de l'Encadreur -->
                        <div class="mb-4">
                            <label for="encadreur" class="form-label">Co-encadreur (optionnel)</label>
                            <select class="form-select" id="encadreur" name="encadreur_id">
                                <option value="">Sélectionner un co-encadreur</option>
                                <?php 
                                if ($enseignants):
                                    foreach ($enseignants as $enseignant): 
                                ?>
                                    <option value="<?= $enseignant['idAgent'] ?>">
                                        <?= htmlspecialchars(($enseignant['gradeDesignation'] ? $enseignant['gradeDesignation'] . ' ' : '') . 
                                            $enseignant['noms']) ?>
                                    </option>
                                <?php 
                                    endforeach;
                                endif;
                                ?>
                            </select>
                        </div>

                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle"></i>
                                Votre proposition de sujet devra être validée par l'administration.
                            </small>
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                            <button type="submit" class="btn btn-primary">Soumettre la proposition</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <nav class="bottom-nav">
        <div class="d-flex justify-content-around">
            <a href="student" class="nav-item active">
                <i class="fas fa-home d-block"></i>
                <small>Accueil</small>
            </a>
            <a href="#" class="nav-item" data-page="tasks">
                <i class="fas fa-tasks d-block"></i>
                <small>Tâches</small>
            </a>
            <a href="#" class="nav-item" data-page="messages">
                <i class="fas fa-comment d-block"></i>
                <small>Messages</small>
            </a>
            <a href="profile" class="nav-item" data-page="profile">
                <i class="fas fa-user d-block"></i>
                <small>Profil</small>
            </a>
        </div>
    </nav>

    <!-- JavaScript Dependencies -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Validation côté client pour les formulaires de choix de sujet -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Fonction pour initialiser Bootstrap
        function initializeBootstrapComponents() {
            // Initialiser les tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });

            // Initialiser les popovers
            var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
            popoverTriggerList.map(function (popoverTriggerEl) {
                return new bootstrap.Popover(popoverTriggerEl);
            });
        }

        // Validation des formulaires de choix de sujet
        <?php foreach ($sujetsDisponibles as $sujet): ?>
        const form<?= $sujet['idsujets'] ?> = document.getElementById('formChoixSujet<?= $sujet['idsujets'] ?>');
        if (form<?= $sujet['idsujets'] ?>) {
            form<?= $sujet['idsujets'] ?>.addEventListener('submit', function(e) {
                const directeurId = this.querySelector('[name="directeur_id"]').value;
                const encadreurId = this.querySelector('[name="encadreur_id"]').value;

                if (directeurId === encadreurId && encadreurId !== '') {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur',
                        text: 'Le directeur et le co-encadreur doivent être différents.'
                    });
                    return false;
                }
            });
        }
        <?php endforeach; ?>

        // Validation du formulaire de proposition de sujet
        const proposerSujetForm = document.getElementById('proposerSujetForm');
        if (proposerSujetForm) {
            proposerSujetForm.addEventListener('submit', function(e) {
                const directeurId = this.querySelector('[name="directeur_id"]').value;
                const encadreurId = this.querySelector('[name="encadreur_id"]').value;

                if (directeurId === encadreurId && encadreurId !== '') {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur',
                        text: 'Le directeur et le co-encadreur doivent être différents.'
                    });
                    return false;
                }
            });
        }

        // Initialiser les composants Bootstrap
        initializeBootstrapComponents();
    });

    // Fonction pour afficher le modal de réponse
    function showReplyModal(tacheId) {
        document.getElementById('reply_tache_id').value = tacheId;
        document.getElementById('commentaire').value = '';
        document.getElementById('fichier').value = '';
        const replyModal = new bootstrap.Modal(document.getElementById('replyModal'));
        replyModal.show();
    }
    </script>

    <!-- Script principal pour l'interface utilisateur -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log('DOM chargé - initialisation des composants UI');
        
        // 1. Menu latéral
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const contentArea = document.querySelector('.content-area');
        
        if (menuToggle && sidebar && contentArea) {
            console.log('Éléments du menu trouvés');
            
            menuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                contentArea.classList.toggle('sidebar-open');
                console.log('Menu toggled:', sidebar.classList.contains('show'));
            });
            
            // Fermer le menu au clic en dehors
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.sidebar') && 
                    !e.target.closest('.menu-toggle') && 
                    sidebar.classList.contains('show')) {
                    sidebar.classList.remove('show');
                    contentArea.classList.remove('sidebar-open');
                }
            });
        } else {
            console.error('Éléments du menu manquants:', { menuToggle, sidebar, contentArea });
        }
        
        // 2. Menu de profil
        const profileIcon = document.getElementById('profileIcon');
        const profileMenu = document.getElementById('profileMenu');
        
        if (profileIcon && profileMenu) {
            console.log('Éléments du profil trouvés');
            
            profileIcon.addEventListener('click', function(e) {
                e.preventDefault();
                profileMenu.classList.toggle('show');
                console.log('Profile toggled:', profileMenu.classList.contains('show'));
            });
            
            // Fermer le menu au clic à l'extérieur
            document.addEventListener('click', function(event) {
                if (!event.target.closest('#profileIcon') && !event.target.closest('#profileMenu')) {
                    profileMenu.classList.remove('show');
                }
            });
        } else {
            console.error('Éléments du profil manquants:', { profileIcon, profileMenu });
        }
        
        // Dans le gestionnaire d'événements existant
        document.querySelectorAll('.nav-item[data-page]').forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                this.classList.add('active');
                
                const page = this.dataset.page;
                switch(page) {
                    case 'home':
                        document.querySelector('#subjects-tab')?.click();
                        break;
                    case 'tasks':
                        document.querySelector('#tasks-tab')?.click();
                        break;
                    case 'evaluations':
                        document.querySelector('#evaluations-tab')?.click();
                        break;
                    case 'profile':
                        window.location.href = 'profile';
                        break;
                }
            });
        });

        
        // 4. Gestion du bouton proposer sujet
        const proposerSujetBtn = document.getElementById('proposerSujetBtn');
        const proposerSujetSidebar = document.getElementById('proposerSujetSidebar');
        const proposerSujetModal = document.getElementById('proposerSujetModal');
        
        if (proposerSujetModal) {
            const bsModal = new bootstrap.Modal(proposerSujetModal);
            
            if (proposerSujetBtn) {
                proposerSujetBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    bsModal.show();
                });
            }
            
            if (proposerSujetSidebar) {
                proposerSujetSidebar.addEventListener('click', function(e) {
                    e.preventDefault();
                    bsModal.show();
                });
            }
        }
        
        // 5. Gestion des liens du menu latéral
        document.querySelectorAll('.sidebar-menu a').forEach(link => {
            link.addEventListener('click', function(e) {
                if (this.id === 'proposerSujetSidebar') {
                    e.preventDefault();
                    const proposerSujetModal = new bootstrap.Modal(document.getElementById('proposerSujetModal'));
                    proposerSujetModal.show();
                } else {
                    const page = this.getAttribute('data-page');
                    if (page) {
                        e.preventDefault();
                        // Mettre à jour l'onglet actif
                        document.querySelectorAll('.sidebar-menu a').forEach(a => a.classList.remove('active'));
                        this.classList.add('active');
                        
                        // Gérer la navigation
                        switch(page) {
                            case 'home':
                                document.querySelector('#subjects-tab')?.click();
                                break;
                            case 'tasks':
                                document.querySelector('#tasks-tab')?.click();
                                break;
                            case 'profile':
                                window.location.href = 'profile';
                                break;
                        }
                    }
                }
                
                // Fermer le menu sur mobile
                if (window.innerWidth < 768) {
                    sidebar.classList.remove('show');
                    contentArea.classList.remove('sidebar-open');
                }
            });
        });
        
        // Vérification de validation des formulaires
        document.querySelectorAll('form').forEach(form => {
            console.log('Formulaire trouvé:', form.id || 'sans id');
        });
        
        console.log('Initialisation UI terminée avec succès');
    });



// Fonction pour charger les détails d'un cours
function loadCourseDetails(idEcue) {
    const modal = new bootstrap.Modal(document.getElementById('courseDetailsModal'));
    modal.show();
    
    const courseContent = document.getElementById('courseContent');
    courseContent.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Chargement...</span>
            </div>
            <p class="mt-2">Chargement des détails du cours...</p>
        </div>
    `;
    
    // Charger les détails du cours via AJAX
    fetch(`../controller/get_course_details_student.php?id=${idEcue}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Erreur réseau');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Mettre à jour le titre du modal
            document.getElementById('courseTitle').textContent = data.course.designationECUE;
            
            // Créer le contenu HTML pour les détails du cours
            let html = `
                <div class="course-details">
                    <div class="mb-3">
                        <h5>Informations générales</h5>
                        <p><strong>UE:</strong> ${data.course.designationUE}</p>
                        <p><strong>Semestre:</strong> ${data.course.numeroSemestre}</p>
                        <p><strong>Volume horaire:</strong> CMI: ${data.course.CMI}h, TD: ${data.course.TD}h, TP: ${data.course.TP}h</p>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Enseignants</h5>
                        <ul class="list-group mb-3">
            `;
            
            if (data.enseignants && data.enseignants.length > 0) {
                data.enseignants.forEach(ens => {
                    html += `
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            ${ens.noms}
                            <span class="badge bg-primary">${ens.poste}</span>
                        </li>
                    `;
                });
            } else {
                html += `<li class="list-group-item">Aucun enseignant assigné</li>`;
            }
            
            html += `
                        </ul>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Supports de cours</h5>
                        <div class="list-group mb-3">
            `;
            
            if (data.supports && data.supports.length > 0) {
                data.supports.forEach(support => {
                    html += `
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">${support.titre}</h6>
                                ${support.est_payant ? 
                                    `<span class="badge bg-${support.access_granted ? 'success' : 'warning'}">
                                        ${support.access_granted ? 'Accès autorisé' : 'Accès payant'}
                                    </span>` : 
                                    '<span class="badge bg-info">Gratuit</span>'
                                }
                            </div>
                            <p class="mb-1">${support.description || ''}</p>
                            <div class="d-flex justify-content-end mt-2">
                                ${support.est_payant && !support.access_granted ?
                                    `<button class="btn btn-sm btn-warning" onclick="accessPayment(${support.idsupport}, 'support')">
                                        <i class="fas fa-lock"></i> Obtenir l'accès
                                    </button>` :
                                    `<a href="../uploads/supports/${support.fichier}" class="btn btn-sm btn-outline-primary" target="_blank">
                                        <i class="fas fa-download"></i> Télécharger
                                    </a>`
                                }
                            </div>
                        </div>
                    `;
                });
            } else {
                html += `<div class="list-group-item">Aucun support disponible</div>`;
            }
            
            html += `
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <h5>Chapitres</h5>
                        <div class="accordion" id="chaptersAccordion">
            `;
            
            if (data.chapters && data.chapters.length > 0) {
                data.chapters.forEach((chapter, index) => {
                    html += `
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading${chapter.idpartie}">
                                <button class="accordion-button ${index > 0 ? 'collapsed' : ''}" type="button" 
                                        data-bs-toggle="collapse" data-bs-target="#collapse${chapter.idpartie}" 
                                        aria-expanded="${index === 0 ? 'true' : 'false'}" 
                                        aria-controls="collapse${chapter.idpartie}">
                                    ${chapter.titre}
                                    <span class="ms-auto badge bg-secondary">Ordre: ${chapter.ordre}</span>
                                </button>
                            </h2>
                            <div id="collapse${chapter.idpartie}" class="accordion-collapse collapse ${index === 0 ? 'show' : ''}" 
                                 aria-labelledby="heading${chapter.idpartie}" data-bs-parent="#chaptersAccordion">
                                <div class="accordion-body">
                                    <div class="chapter-content mb-3">
                                        ${chapter.description || 'Aucune description disponible'}
                                    </div>
                                    
                                    <h6>Ressources</h6>
                                    <div class="list-group">
                    `;
                    
                    if (chapter.ressources && chapter.ressources.length > 0) {
                        chapter.ressources.forEach(res => {
                            html += `
                                <div class="list-group-item">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">
                                                                                        <i class="${getResourceIcon(res.type_ressource)} me-2"></i>
                                            ${res.titre}
                                        </h6>
                                        <span class="badge bg-${
                                            res.est_payant ?
                                            (res.access_granted ? 'success' : 'warning') :
                                            'info'
                                        }">
                                            ${
                                                res.est_payant ?
                                                (res.access_granted ? 'Accès autorisé' : 'Accès payant') :
                                                'Gratuit'
                                            }
                                        </span>
                                    </div>
                                    <p class="mb-1">${res.description || ''}</p>
                                    <div class="d-flex justify-content-end mt-2">
                                        ${
                                            res.est_payant && !res.access_granted ?
                                            `<button class="btn btn-sm btn-warning" onclick="accessPayment(${res.idressource}, 'ressource')">
                                                <i class="fas fa-lock"></i> Obtenir l'accès
                                            </button>` :
                                            (res.fichier ?
                                                `<a href="../uploads/ressources/${res.fichier}" class="btn btn-sm btn-outline-primary" target="_blank">
                                                    <i class="fas fa-download"></i> Télécharger
                                                </a>` :
                                                (res.lien_externe ?
                                                    `<a href="${res.lien_externe}" class="btn btn-sm btn-outline-primary" target="_blank">
                                                        <i class="fas fa-external-link-alt"></i> Accéder
                                                    </a>` :
                                                    ''
                                                )
                                            )
                                        }
                                    </div>
                                </div>
                            `;
                        });
                    } else {
                        html += `<div class="list-group-item">Aucune ressource disponible pour ce chapitre</div>`;
                    }
                    
                    html += `
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
            } else {
                html += `<p class="text-muted">Aucun chapitre disponible pour ce cours</p>`;
            }
            
            html += `
                        </div>
                    </div>
                    
                    <!-- Devoirs -->
                    <div class="mb-3">
                        <h5>Devoirs</h5>
                        <div class="list-group">
            `;
            
            if (data.assignments && data.assignments.length > 0) {
                data.assignments.forEach(assignment => {
                    const today = new Date();
                    const deadline = new Date(assignment.date_limite);
                    const isExpired = today > deadline;
                    
                    html += `
                        <div class="list-group-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">${assignment.titre}</h6>
                                <span class="badge bg-${isExpired ? 'danger' : 'info'}">
                                    ${isExpired ? 'Expiré' : 'Date limite: ' + formatDate(assignment.date_limite)}
                                </span>
                            </div>
                            <p class="mb-1">${assignment.description || ''}</p>
                            
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <a href="${assignment.est_payant && !assignment.access_granted ? 
                                    '#' : '../uploads/devoirs/' + assignment.fichier}" 
                                   class="btn btn-sm btn-outline-primary ${assignment.est_payant && !assignment.access_granted ? 'disabled' : ''}"
                                   ${assignment.est_payant && !assignment.access_granted ? '' : 'target="_blank"'}>
                                    <i class="fas fa-download me-1"></i> Télécharger le devoir
                                </a>
                                
                                ${assignment.est_payant && !assignment.access_granted ? 
                                    `<button class="btn btn-sm btn-warning" onclick="accessPayment(${assignment.iddevoir}, 'devoir')">
                                        <i class="fas fa-lock me-1"></i> Obtenir l'accès
                                    </button>` : 
                                    (isExpired ? '' : 
                                        `<button class="btn btn-sm btn-success" onclick="showSubmissionForm(${assignment.iddevoir})">
                                            <i class="fas fa-paper-plane me-1"></i> Soumettre
                                        </button>`
                                    )
                                }
                            </div>
                            
                            ${assignment.reponse ? 
                                `<div class="mt-3 p-2 bg-light rounded">
                                    <div class="d-flex justify-content-between">
                                        <strong>Votre soumission</strong>
                                        <small class="text-muted">${formatDate(assignment.reponse.date_soumission)}</small>
                                    </div>
                                    <p class="small mb-1">${assignment.reponse.commentaire || 'Aucun commentaire'}</p>
                                    <a href="../uploads/reponses/${assignment.reponse.fichier}" class="btn btn-sm btn-outline-secondary" target="_blank">
                                        <i class="fas fa-file me-1"></i> Voir votre fichier
                                    </a>
                                    
                                    ${assignment.reponse.note ? 
                                        `<div class="mt-2">
                                            <strong class="text-${assignment.reponse.note >= 10 ? 'success' : 'danger'}">
                                                Note: ${assignment.reponse.note}/20
                                            </strong>
                                            ${assignment.reponse.feedback_enseignant ? 
                                                `<p class="small mt-1">
                                                    <strong>Feedback:</strong> ${assignment.reponse.feedback_enseignant}
                                                </p>` : ''
                                            }
                                        </div>` : ''
                                    }
                                </div>` : ''
                            }
                        </div>
                    `;
                });
            } else {
                html += '<p class="text-muted">Aucun devoir disponible pour ce cours</p>';
            }
            
            html += `
                        </div>
                    </div>
                </div>
            `;
            
            courseContent.innerHTML = html;
        })
        .catch(error => {
            courseContent.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Erreur: ${error.message}
                </div>
            `;
        });
}

// Fonction pour obtenir l'icône en fonction du type de ressource
function getResourceIcon(type) {
    switch(type) {
        case 'PDF': return 'fas fa-file-pdf';
        case 'Vidéo': return 'fas fa-video';
        case 'Audio': return 'fas fa-headphones';
        case 'Présentation': return 'fas fa-file-powerpoint';
        case 'Lien': return 'fas fa-link';
        default: return 'fas fa-file';
    }
}

// Fonction pour formater une date
function formatDate(dateString) {
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}

// Fonction pour afficher le formulaire de soumission
function showSubmissionForm(assignmentId) {
    document.getElementById('submission_iddevoir').value = assignmentId;
    document.getElementById('submission_commentaire').value = '';
    document.getElementById('submission_fichier').value = '';
    
    const modal = new bootstrap.Modal(document.getElementById('submitAssignmentModal'));
    modal.show();
}

// Fonction pour obtenir l'accès à une ressource payante
function accessPayment(id, type) {
    Swal.fire({
        title: 'Accès payant',
        text: 'Pour accéder à cette ressource, vous devez effectuer un paiement. Voulez-vous être redirigé vers la page de paiement?',
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Oui, procéder au paiement',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `../controller/payment.php?type=${type}&id=${id}`;
        }
    });
}



// Fonction pour obtenir l'icône en fonction du type de ressource
function getResourceIcon(type) {
    switch(type) {
        case 'PDF': return 'fas fa-file-pdf';
        case 'Vidéo': return 'fas fa-video';
        case 'Audio': return 'fas fa-headphones';
        case 'Présentation': return 'fas fa-file-powerpoint';
        case 'Lien': return 'fas fa-link';
        default: return 'fas fa-file';
    }
}

// Fonction pour formater une date
function formatDate(dateString) {
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}


// Fonction pour obtenir l'accès à une ressource payante
function accessPayment(id, type) {
    // Implémenter la logique de paiement pour les ressources payantes
}










    </script>
</body>
</html>


