<?php
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Universite.php';

$universite = new Universite();

// Récupérer tous les filtres
$filters = [
    'titre' => isset($_GET['titre']) ? trim($_GET['titre']) : '',
    'auteur' => isset($_GET['auteur']) ? trim($_GET['auteur']) : '',
    'mots_cles' => isset($_GET['mots_cles']) ? trim($_GET['mots_cles']) : '',
    'type_document' => isset($_GET['type_document']) ? $_GET['type_document'] : '',
    'type_auteur' => isset($_GET['type_auteur']) ? $_GET['type_auteur'] : '',
    'departement_id' => isset($_GET['departement']) ? intval($_GET['departement']) : 0,
    'specialisation_id' => isset($_GET['specialisation']) ? intval($_GET['specialisation']) : 0,
    'annee_academique_id' => isset($_GET['annee']) ? intval($_GET['annee']) : 0,
    'date_debut' => isset($_GET['date_debut']) ? $_GET['date_debut'] : '',
    'date_fin' => isset($_GET['date_fin']) ? $_GET['date_fin'] : '',
    'est_public' => 1,
    'statut' => 'Validé'
];

// Récupérer les données pour les filtres
$departements = $universite->getAllDepartments();
$academicYears = $universite->getAcademicYears();
$specialisations = [];

if ($filters['departement_id']) {
    $specialisations = $universite->getSpecialisationsByDepartement($filters['departement_id']);
}

// Effectuer la recherche si des filtres sont appliqués
$resultats = [];
$isSearching = false;

if (isset($_GET['rechercher'])) {
    $isSearching = true;
    $resultats = $universite->getTravaux('', array_filter($filters));
}

include 'header2.php';
?>

<main class="py-5">
    <!-- Fil d'Ariane -->
    <div class="container mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index">Accueil</a></li>
                <li class="breadcrumb-item active">Recherche avancée</li>
            </ol>
        </nav>
    </div>

    <div class="container">
        <div class="row">
            <!-- Formulaire de recherche -->
            <div class="col-lg-4 mb-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-search me-2"></i>
                            Critères de recherche
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="GET" action="" id="searchForm">
                            <!-- Titre -->
                            <div class="mb-3">
                                <label class="form-label">Titre</label>
                                <input type="text" name="titre" class="form-control" value="<?= htmlspecialchars($filters['titre']) ?>" placeholder="Mots dans le titre...">
                            </div>

                            <!-- Auteur -->
                            <div class="mb-3">
                                <label class="form-label">Auteur</label>
                                <input type="text" name="auteur" class="form-control" value="<?= htmlspecialchars($filters['auteur']) ?>" placeholder="Nom de l'auteur...">
                            </div>

                            <!-- Mots-clés -->
                            <div class="mb-3">
                                <label class="form-label">Mots-clés</label>
                                <input type="text" name="mots_cles" class="form-control" value="<?= htmlspecialchars($filters['mots_cles']) ?>" placeholder="Mots-clés séparés par des virgules...">
                            </div>

                            <!-- Type de document -->
                            <div class="mb-3">
                                <label class="form-label">Type de document</label>
                                <select name="type_document" class="form-select">
                                    <option value="">Tous les types</option>
                                    <option value="Thèse" <?= $filters['type_document'] === 'Thèse' ? 'selected' : '' ?>>Thèse</option>
                                    <option value="Mémoire" <?= $filters['type_document'] === 'Mémoire' ? 'selected' : '' ?>>Mémoire</option>
                                    <option value="Article scientifique" <?= $filters['type_document'] === 'Article scientifique' ? 'selected' : '' ?>>Article scientifique</option>
                                    <option value="Projet tutoré" <?= $filters['type_document'] === 'Projet tutoré' ? 'selected' : '' ?>>Projet tutoré</option>
                                    <option value="Rapport de stage" <?= $filters['type_document'] === 'Rapport de stage' ? 'selected' : '' ?>>Rapport de stage</option>
                                </select>
                            </div>

                            <!-- Type d'auteur -->
                            <div class="mb-3">
                                <label class="form-label">Type d'auteur</label>
                                <select name="type_auteur" class="form-select">
                                    <option value="">Tous les types</option>
                                    <option value="Etudiant" <?= $filters['type_auteur'] === 'Etudiant' ? 'selected' : '' ?>>Étudiant</option>
                                    <option value="Enseignant" <?= $filters['type_auteur'] === 'Enseignant' ? 'selected' : '' ?>>Enseignant</option>
                                </select>
                            </div>

                            <!-- Département -->
                            <div class="mb-3">
                                <label class="form-label">Département</label>
                                <select name="departement" class="form-select" id="departement">
                                    <option value="">Tous les départements</option>
                                    <?php foreach ($departements as $dept): ?>
                                        <option value="<?= $dept['iddepartement'] ?>" <?= $filters['departement_id'] === $dept['iddepartement'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($dept['designationDepartement']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Spécialisation -->
                            <div class="mb-3">
                                <label class="form-label">Spécialisation</label>
                                <select name="specialisation" class="form-select" id="specialisation">
                                    <option value="">Toutes les spécialisations</option>
                                    <?php foreach ($specialisations as $spec): ?>
                                        <option value="<?= $spec['idSpecialisation'] ?>" <?= $filters['specialisation_id'] === $spec['idSpecialisation'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($spec['designation']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Année académique -->
                            <div class="mb-3">
                                <label class="form-label">Année académique</label>
                                <select name="annee" class="form-select">
                                    <option value="">Toutes les années</option>
                                    <?php foreach ($academicYears as $year): ?>
                                        <option value="<?= $year['idannee_acad'] ?>" <?= $filters['annee_academique_id'] === $year['idannee_acad'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($year['designation']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Période -->
                            <div class="mb-3">
                                <label class="form-label">Période</label>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <input type="date" name="date_debut" class="form-control" value="<?= $filters['date_debut'] ?>" placeholder="Date début">
                                    </div>
                                    <div class="col-6">
                                        <input type="date" name="date_fin" class="form-control" value="<?= $filters['date_fin'] ?>" placeholder="Date fin">
                                    </div>
                                </div>
                            </div>

                            <!-- Boutons -->
                            <div class="d-grid gap-2">
                                <button type="submit" name="rechercher" class="btn btn-primary">
                                    <i class="fas fa-search me-2"></i>
                                    Rechercher
                                </button>
                                <button type="reset" class="btn btn-outline-secondary" onclick="resetForm()">
                                    <i class="fas fa-undo me-2"></i>
                                    Réinitialiser
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Résultats de recherche -->
            <div class="col-lg-8">
                <?php if ($isSearching): ?>
                    <h4 class="mb-4">
                        <i class="fas fa-list me-2"></i>
                        <?= count($resultats) ?> résultat(s) trouvé(s)
                    </h4>

                    <?php if (!empty($resultats)): ?>
                        <div class="row g-4">
                            <?php foreach ($resultats as $travail): ?>
                                <div class="col-md-6">
                                    <div class="card h-100 shadow-sm">
                                        <div class="card-header <?= $travail['type_class'] ?> text-white">
                                            <i class="fas fa-file-alt me-2"></i>
                                            <?= $travail['type_document'] ?>
                                        </div>

                                        <div class="card-body">
                                            <h5 class="card-title mb-3">
                                                <a href="voir_travail?id=<?= $travail['id'] ?>" class="text-decoration-none text-dark">
                                                    <?= htmlspecialchars($travail['titre']) ?>
                                                </a>
                                            </h5>

                                            <div class="d-flex align-items-center mb-2">
                                                <i class="fas fa-user text-muted me-2"></i>
                                                <span><?= htmlspecialchars($travail['nom_auteur']) ?></span>
                                            </div>

                                            <?php if (!empty($travail['specialisation'])): ?>
                                                <div class="small text-muted mb-2">
                                                    <i class="fas fa-microscope me-2"></i>
                                                    <?= htmlspecialchars($travail['specialisation']) ?>
                                                </div>
                                            <?php endif; ?>

                                            <div class="small text-muted mb-3">
                                                <i class="fas fa-university me-2"></i>
                                                <?= htmlspecialchars($travail['designationDepartement']) ?>
                                                <br>
                                                <i class="fas fa-calendar-alt me-2"></i>
                                                <?= $travail['date_depot_formatee'] ?>
                                            </div>

                                            <?php if (!empty($travail['mots_cles'])): ?>
                                                <div class="mt-2">
                                                    <?php foreach (explode(',', $travail['mots_cles']) as $motCle): ?>
                                                        <span class="badge bg-light text-dark me-1">
                                                            <?= trim(htmlspecialchars($motCle)) ?>
                                                        </span>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                            <a href="voir_travail?id=<?= $travail['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i> Consulter
                                            </a>
                                            <div class="text-muted small">
                                                <i class="fas fa-chart-bar me-1"></i>
                                                <?= number_format($travail['nb_consultations']) ?> vues
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            Aucun résultat ne correspond à vos critères de recherche.
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <img src="../uploads/search.svg.svg" alt="Recherche" class="mb-4" style="max-width: 200px;">
                        <h4>Recherche avancée</h4>
                        <p class="text-muted">Utilisez les filtres pour affiner votre recherche</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<script>
// Charger les spécialisations quand le département change
document.getElementById('departement').addEventListener('change', function() {
    const departementId = this.value;
    const specialisationSelect = document.getElementById('specialisation');
    
    specialisationSelect.innerHTML = '<option value="">Toutes les spécialisations</option>';
    
    if (departementId) {
        fetch(`../controller/get_specialisations.php?departement_id=${departementId}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(spec => {
                    specialisationSelect.innerHTML += `
                        <option value="${spec.idSpecialisation}">
                            ${spec.designation}
                        </option>
                    `;
                });
            });
    }
});

// Réinitialiser le formulaire
function resetForm() {
    document.getElementById('searchForm').reset();
    document.getElementById('specialisation').innerHTML = '<option value="">Toutes les spécialisations</option>';
}
</script>

<style>
.card {
    transition: transform 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card-title {
    font-size: 1.1rem;
    line-height: 1.4;
    height: 3.1em;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
}
</style>

<?php include 'footer.php'; ?>