<?php
// Récupérer la configuration de l'université
$universite = new Universite();
$config = $universite->getConfigurationUniversite();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - ScienceHub Mobile</title>
    <?php if (!empty($config['logo'])): ?>
        <!-- Favicons --> 
	<link href="../<?= htmlspecialchars($config['logo']) ?>" rel="icon">
	<link href="../<?= htmlspecialchars($config['logo']) ?>" rel="apple-touch-icon">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #004494;
            --secondary-color: #f5f5f5;
        }

        body {
            background-color: var(--secondary-color);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .login-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
            max-width: 400px;
            width: 90%;
            margin: auto;
        }

        .logo {
            width: 80px;
            height: 100px;
            margin: 0 auto 20px;
            display: block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-card">
        <img src="../<?= htmlspecialchars($config['logo']) ?>" alt="<?= htmlspecialchars($config['sigle']) ?> Logo" class="logo">
            
            <h4 class="text-center mb-4">Connexion Étudiant</h4>
            
            <form id="loginForm" method="POST" action="../controller/login_student.php">
                <div class="mb-3">
                    <label for="matricule" class="form-label">Matricule</label>
                    <input type="text" class="form-control" id="matricule" name="matricule" required>
                </div>
                
                <div class="mb-3">
                    <label for="password" class="form-label">Mot de passe</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="remember">
                        <label class="form-check-label" for="remember">Se souvenir de moi</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100">Se connecter</button>
            </form>
             <!-- Ajout du lien de retour -->
            <div class="text-center mt-3">
                <a href="index" class="text-decoration-none text-muted">
                    <i class="fas fa-arrow-left me-1"></i> Retour au portail
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const password = document.getElementById('password');
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>