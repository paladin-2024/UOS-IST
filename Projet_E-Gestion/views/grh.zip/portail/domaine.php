<?php
require_once dirname(__DIR__) . '/../config/Connexion.php';
require_once dirname(__DIR__) . '/../models/Universite.php';

$universite = new Universite();

// Récupérer l'ID du département
$departementId = isset($_GET['departement']) ? intval($_GET['departement']) : 0;

// Récupérer les informations du département
$departement = $universite->getDepartementById($departementId);

if (!$departement) {
    header('Location: index');
    exit;
}

// Récupérer les travaux du département
$travaux = $universite->getTravaux('', [
    'departement_id' => $departementId,
    'est_public' => 1,
    'statut' => 'Validé'
]);


// Récupérer les statistiques du département
$stats = [
    'total_travaux' => count($travaux),
    'total_theses' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Thèse')),
    'total_memoires' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Mémoire' || $t['type_document'] === 'Mémoire Master Complémentaire')),
    'total_memoires_m2' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Mémoire')),
    'total_memoires_mc' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Mémoire Master Complémentaire')),
    'total_articles' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Article scientifique')),
    'total_projets' => count(array_filter($travaux, fn($t) => $t['type_document'] === 'Projet tutoré'))
];

include 'header2.php';
?>

<main class="py-5">
    <!-- Fil d'Ariane -->
    <div class="container mb-4">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index">Accueil</a></li>
                <li class="breadcrumb-item">Domaines de recherche</li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($departement['designationDepartement']) ?></li>
            </ol>
        </nav>
    </div>

    <!-- En-tête du département -->
    <div class="bg-primary text-white py-4 mb-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="h2 mb-2"><?= htmlspecialchars($departement['designationDepartement']) ?></h1>
                    <p class="lead mb-0">Explorez les travaux scientifiques de ce département</p>
                </div>
                <div class="col-md-4">
                    <div class="row text-center">
                        <div class="col-6 border-end">
                            <div class="h3 mb-0"><?= number_format($stats['total_travaux']) ?></div>
                            <small>Travaux</small>
                        </div>
                        <div class="col-6">
                            <div class="h3 mb-0"><?= number_format(array_sum(array_column($travaux, 'nb_consultations'))) ?></div>
                            <small>Consultations</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <!-- Filtres et statistiques -->
        <div class="row mb-4">
            <div class="col-md-8">
                <!-- Types de documents -->
                <div class="d-flex flex-wrap gap-2">
                    <a href="?departement=<?= $departementId ?>" class="btn btn-outline-primary">
                        Tous (<?= $stats['total_travaux'] ?>)
                    </a>
                    <a href="?departement=<?= $departementId ?>&type=these" class="btn btn-outline-primary">
                        Thèses (<?= $stats['total_theses'] ?>)
                    </a>
                    <a href="?departement=<?= $departementId ?>&type=memoire" class="btn btn-outline-primary">
                        Mémoires (<?= $stats['total_memoires'] ?>)
                    </a>
                    <a href="?departement=<?= $departementId ?>&type=article" class="btn btn-outline-primary">
                        Articles (<?= $stats['total_articles'] ?>)
                    </a>
                    <a href="?departement=<?= $departementId ?>&type=projet" class="btn btn-outline-primary">
                        Projets tutorés (<?= $stats['total_projets'] ?>)
                    </a>
                </div>
                
            </div>
            <div class="col-md-4">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Rechercher dans ce département...">
                    <button class="btn btn-primary">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- Liste des travaux -->
        <div class="row g-4">
            <?php if (!empty($travaux)): ?>
                <?php foreach ($travaux as $travail): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm">
                            <!-- En-tête avec type de document -->
                            <div class="card-header <?= $travail['type_class'] ?> text-white">
                                <i class="fas fa-file-alt me-2"></i>
                                <?php 
                                // Afficher le type de document approprié
                                if ($travail['type_document'] === 'Mémoire') {
                                    echo 'Mémoire M2';
                                } elseif ($travail['type_document'] === 'Mémoire Master Complémentaire') {
                                    echo 'Mémoire Master Complémentaire';
                                } else {
                                    echo $travail['type_document'];
                                }
                                ?>
                            </div>

                            <div class="card-body">
                                <!-- Titre -->
                                <h5 class="card-title mb-3">
                                    <a href="voir_travail&id=<?= $travail['id'] ?>" class="text-decoration-none text-dark">
                                        <?= htmlspecialchars($travail['titre']) ?>
                                    </a>
                                </h5>

                                <!-- Informations sur l'auteur -->
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-user-circle text-muted me-2"></i>
                                    <span>
                                        <?= htmlspecialchars($travail['nom_auteur']) ?>
                                        <span class="badge bg-secondary ms-1"><?= $travail['type_auteur'] ?></span>
                                    </span>
                                </div>

                                <?php if ($travail['type_document'] === 'Thèse'): ?>
                                    <!-- Informations spécifiques aux thèses -->
                                    <?php if (!empty($travail['universiteThese']) || 
                                             !empty($travail['faculteThese']) || 
                                             !empty($travail['anneeThese']) || 
                                             !empty($travail['specialisationThese'])): ?>
                                    <div class="these-info mb-3">
                                        <div class="row g-2">
                                            <?php if (!empty($travail['universiteThese'])): ?>
                                            <div class="col-12 d-flex align-items-center mb-1">
                                                <i class="fas fa-university text-primary me-2"></i>
                                                <span class="small"><?= htmlspecialchars($travail['universiteThese']) ?></span>
                                            </div>
                                            <?php endif; ?>
                                            
                                            <?php if (!empty($travail['faculteThese'])): ?>
                                            <div class="col-12 d-flex align-items-center mb-1">
                                                <i class="fas fa-building text-primary me-2"></i>
                                                <span class="small"><?= htmlspecialchars($travail['faculteThese']) ?></span>
                                            </div>
                                            <?php endif; ?>
                                            
                                            <div class="d-flex flex-wrap">
                                                <?php if (!empty($travail['anneeThese'])): ?>
                                                <div class="me-3 d-flex align-items-center mb-1">
                                                    <i class="fas fa-calendar-check text-primary me-1"></i>
                                                    <span class="small"><?= htmlspecialchars($travail['anneeThese']) ?></span>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <?php if (!empty($travail['specialisationThese'])): ?>
                                                <div class="d-flex align-items-center mb-1">
                                                    <i class="fas fa-microscope text-primary me-1"></i>
                                                    <span class="small"><?= htmlspecialchars($travail['specialisationThese']) ?></span>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <!-- Spécialisation pour les autres types de documents -->
                                    <div class="small text-muted mb-3">
                                        <i class="fas fa-bookmark me-2"></i>
                                        <?= htmlspecialchars($travail['specialisation']) ?>
                                    </div>
                                <?php endif; ?>

                                <!-- Date de dépôt -->
                                <div class="small text-muted mb-3">
                                    <i class="fas fa-calendar-alt me-2"></i>
                                    <?= $travail['date_depot_formatee'] ?>
                                </div>

                                <!-- Résumé court -->
                                <p class="card-text small">
                                    <?= htmlspecialchars(substr($travail['resume'], 0, 100)) ?>...
                                </p>
                            </div>

                            <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                <a href="voir_travail&id=<?= $travail['id'] ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-eye me-1"></i> Consulter
                                </a>
                                <div class="text-muted small">
                                    <i class="fas fa-chart-bar me-1"></i>
                                    <?= number_format($travail['nb_consultations']) ?> vues
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Aucun travail scientifique n'est disponible pour ce département.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
.card {
    transition: transform 0.2s ease-in-out;
}

.card:hover {
    transform: translateY(-5px);
}

.card-title {
    font-size: 1.1rem;
    line-height: 1.4;
    height: 3.1em;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
}

.bg-primary {
    background: linear-gradient(135deg, var(--bs-primary) 0%, #0056b3 100%);
}
</style>

<?php include 'footer.php'; ?>