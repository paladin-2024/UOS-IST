<?php
include "./views/include/header.php";
$universite = new Universite();
$uniteRecherche = new UniteRecherche();
$agentModel = new Agent();

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Récupérer toutes les sections
$sections = $universite->getSections();

// Récupérer toutes les unités de recherche
$researchUnits = $uniteRecherche->getResearchUnits($search);
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>UNITÉS DE RECHERCHE</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Unités de Recherche</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table research units -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Gestion des unités de recherche
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createResearchUnitModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter Unité de Recherche
                                        </a>
                                    </span>
                                </h5>

                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="hidden" name="view" value="ur/unite_recherche">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher par désignation...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Sections</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($researchUnits as $unit) {
                                            // Récupérer les sections associées à cette unité de recherche
                                            $unitSections = $uniteRecherche->getSectionsByResearchUnit($unit['idunite_recherche']);
                                            $sectionNames = [];
                                            foreach ($unitSections as $section) {
                                                $sectionNames[] = $section['designationSection'];
                                            }
                                            $sectionsList = implode(', ', $sectionNames);
                                            
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$unit['designation_UR']}</td>
                                                <td>{$unit['description']}</td>
                                                <td>{$sectionsList}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='openEditResearchUnitModal({$unit['idunite_recherche']}, \"{$unit['designation_UR']}\", \"{$unit['description']}\")'>
                                                        <i class='bi bi-pencil-square'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='confirmDeleteResearchUnit({$unit['idunite_recherche']})'>
                                                        <i class='bi bi-trash'></i>
                                                    </button>
                                                    <button class='btn btn-sm btn-info' data-bs-toggle='collapse' data-bs-target='#specialisationsList{$unit['idunite_recherche']}'>
                                                        <i class='bi bi-list'></i> Voir Spécialisations
                                                    </button>
                                                    <button class='btn btn-sm btn-success' onclick='openSpecialisationModal({$unit['idunite_recherche']})'>
                                                        <i class='bi bi-plus'></i> Ajouter Spécialisation
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='specialisationsList{$unit['idunite_recherche']}'>
                                                <td colspan='5'>
                                                    <div class='card card-body'>
                                                        <table class='table table-sm'>
                                                            <thead>
                                                                <tr>
                                                                    <th scope='col'>Section</th>
                                                                    <th scope='col'>Spécialisation</th>
                                                                    <th scope='col'>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>";
                                                            
                                                            // Pour chaque section associée, récupérer les spécialisations
                                                            foreach ($unitSections as $section) {
                                                                $specialisations = $uniteRecherche->getSpecialisationsByResearchUnitAndSection($unit['idunite_recherche'], $section['idsection']);
                                                                
                                                                if (count($specialisations) > 0) {
                                                                    foreach ($specialisations as $specialisation) {
                                                                        echo "<tr>
                                                                            <td>{$section['designationSection']}</td>
                                                                            <td>{$specialisation['designation']}</td>
                                                                            <td>
                                                                                <button class='btn btn-sm btn-warning' onclick='openEditSpecialisationModal({$specialisation['idSpecialisation']}, \"{$specialisation['designation']}\", {$unit['idunite_recherche']})'>
                                                                                    <i class='bi bi-pencil-square'></i>
                                                                                </button>
                                                                                <button class='btn btn-sm btn-danger' onclick='confirmDeleteSpecialisation({$specialisation['idSpecialisation']})'>
                                                                                    <i class='bi bi-trash'></i>
                                                                                </button>
                                                                                <button class='btn btn-sm btn-primary' onclick='viewTeachersBySpecialisation({$specialisation['idSpecialisation']}, \"{$specialisation['designation']}\")'>
                                                                                    <i class='bi bi-people'></i> Enseignants
                                                                                </button>
                                                                            </td>
                                                                        </tr>";
                                                                    }
                                                                } else {
                                                                    echo "<tr>
                                                                        <td>{$section['designationSection']}</td>
                                                                        <td colspan='2' class='text-center'>Aucune spécialisation pour cette section</td>
                                                                    </tr>";
                                                                }
                                                            }
                                                            
                                                            echo "</tbody>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->

<!-- Modal pour ajouter une unité de recherche -->
<div class="modal fade" id="createResearchUnitModal" tabindex="-1" role="dialog" aria-labelledby="createResearchUnitModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Unité de Recherche</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="researchUnitForm" method="POST" action="controller/create_unite_recherche.php" class="needs-validation" novalidate>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designationUR" class="form-label">Désignation</label>
                            <input type="text" name="designationUR" id="designationUR" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="idSection" class="form-label">Section(s)</label>
                            <select name="idSection[]" id="idSection" class="form-select" multiple required>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?= $section['idsection'] ?>"><?= $section['designationSection'] ?> / <?= $section['anneeDesignation'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small class="form-text text-muted">Maintenez la touche Ctrl (ou Cmd sur Mac) pour sélectionner plusieurs sections.</small>
                            <div class="invalid-feedback">Veuillez sélectionner au moins une section.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addResearchUnitBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une unité de recherche -->
<div class="modal fade" id="editResearchUnitModal" tabindex="-1" role="dialog" aria-labelledby="editResearchUnitModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Unité de Recherche</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editResearchUnitForm" method="POST" action="controller/edit_unite_recherche.php" class="needs-validation" novalidate>
                    <input type="hidden" name="editIdUniteRecherche" id="editIdUniteRecherche">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editDesignationUR" class="form-label">Désignation</label>
                            <input type="text" name="editDesignationUR" id="editDesignationUR" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="editDescription" class="form-label">Description</label>
                            <textarea name="editDescription" id="editDescription" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="editIdSection" class="form-label">Section(s)</label>
                            <select name="editIdSection[]" id="editIdSection" class="form-select" multiple required>
                                <?php foreach ($sections as $section): ?>
                                    <option value="<?= $section['idsection'] ?>"><?= $section['designationSection'] ?> / <?= $section['anneeDesignation'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small class="form-text text-muted">Maintenez la touche Ctrl (ou Cmd sur Mac) pour sélectionner plusieurs sections.</small>
                            <div class="invalid-feedback">Veuillez sélectionner au moins une section.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editResearchUnitBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour ajouter une spécialisation -->
<div class="modal fade" id="createSpecialisationModal" tabindex="-1" role="dialog" aria-labelledby="createSpecialisationModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une Spécialisation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="specialisationForm" method="POST" action="controller/create_specialisation.php" class="needs-validation" novalidate>
                    <input type="hidden" name="idUniteRecherche" id="idUniteRecherche">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="designation" class="form-label">Désignation</label>
                            <input type="text" name="designation" id="designation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idSection" class="form-label">Section</label>
                            <select name="idSection" id="sectionForSpecialisation" class="form-control" required>
                                <option value="">Sélectionner une section</option>
                                <!-- Les options seront chargées dynamiquement par JavaScript -->
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une section.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addSpecialisationBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une spécialisation -->
<div class="modal fade" id="editSpecialisationModal" tabindex="-1" role="dialog" aria-labelledby="editSpecialisationModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Spécialisation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editSpecialisationForm" method="POST" action="controller/edit_specialisation.php" class="needs-validation" novalidate>
                    <input type="hidden" name="editIdSpecialisation" id="editIdSpecialisation">
                    <input type="hidden" name="editIdUniteRecherche" id="editIdUniteRecherche3"> <!-- Hidden field for research unit ID -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editDesignation" class="form-label">Désignation</label>
                            <input type="text" name="editDesignation" id="editDesignation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editSpecialisationBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour voir les enseignants par spécialisation -->
<div class="modal fade" id="teachersBySpecialisationModal" tabindex="-1" role="dialog" aria-labelledby="teachersBySpecialisationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Enseignants par Spécialisation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6 id="specialisationTitle" class="mb-3"></h6>
                <div id="teachersList">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Chargement...</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>

<script>
    function openEditResearchUnitModal(id, designation, description) {
        document.getElementById('editIdUniteRecherche').value = id;
        document.getElementById('editDesignationUR').value = designation;
        document.getElementById('editDescription').value = description;
        
        // Charger les sections associées à cette unité de recherche
        fetch(`controller/get_sections_by_research_unit.php?idUniteRecherche=${id}`)
            .then(response => response.json())
            .then(data => {
                const sectionSelect = document.getElementById('editIdSection');
                
                // Désélectionner toutes les options
                Array.from(sectionSelect.options).forEach(option => {
                    option.selected = false;
                });
                
                // Sélectionner les sections associées
                data.forEach(section => {
                    Array.from(sectionSelect.options).forEach(option => {
                        if (option.value == section.idsection) {
                            option.selected = true;
                        }
                    });
                });
                
                new bootstrap.Modal(document.getElementById('editResearchUnitModal')).show();
            })
            .catch(error => {
                console.error('Erreur lors du chargement des sections:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Impossible de charger les sections associées à cette unité de recherche.'
                });
            });
    }

    function confirmDeleteResearchUnit(idUniteRecherche) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible ! Toutes les spécialisations associées seront également supprimées.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_unite_recherche.php?idunite_recherche=' + idUniteRecherche;
            }
        });
    }

    function openSpecialisationModal(idUniteRecherche) {
        document.getElementById('idUniteRecherche').value = idUniteRecherche;
        
        // Charger les sections associées à cette unité de recherche
        fetch(`controller/get_sections_by_research_unit.php?idUniteRecherche=${idUniteRecherche}`)
            .then(response => response.json())
            .then(data => {
                const sectionSelect = document.getElementById('sectionForSpecialisation');
                sectionSelect.innerHTML = '<option value="">Sélectionner une section</option>';
                
                data.forEach(section => {
                    const option = document.createElement('option');
                    option.value = section.idsection;
                    option.textContent = `${section.designationSection}`;
                    sectionSelect.appendChild(option);
                });
                
                new bootstrap.Modal(document.getElementById('createSpecialisationModal')).show();
            })
            .catch(error => {
                console.error('Erreur lors du chargement des sections:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Impossible de charger les sections associées à cette unité de recherche.'
                });
            });
    }

    function openEditSpecialisationModal(id, designation, idUniteRecherche) {
        document.getElementById('editIdSpecialisation').value = id;
        document.getElementById('editDesignation').value = designation;
        document.getElementById('editIdUniteRecherche3').value = idUniteRecherche; // Set the research unit ID
        new bootstrap.Modal(document.getElementById('editSpecialisationModal')).show();
    }

    function confirmDeleteSpecialisation(idSpecialisation) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Cette action est irréversible ! Les enseignants ne seront plus affectés à cette spécialisation.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'controller/delete_specialisation.php?idSpecialisation=' + idSpecialisation;
            }
        });
    }
    
    function viewTeachersBySpecialisation(idSpecialisation, designation) {
        document.getElementById('specialisationTitle').textContent = `Enseignants pour la spécialisation: ${designation}`;
        document.getElementById('teachersList').innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Chargement...</span>
                </div>
            </div>
        `;
        
        // Ouvrir le modal
        new bootstrap.Modal(document.getElementById('teachersBySpecialisationModal')).show();
        
        // Charger les enseignants pour cette spécialisation
        fetch(`controller/get_teachers_by_specialisation.php?idSpecialisation=${idSpecialisation}`)
            .then(response => response.json())
            .then(data => {
                let html = '';
                
                if (data.length === 0) {
                    html = `<div class="alert alert-info">Aucun enseignant n'est affecté à cette spécialisation.</div>`;
                } else {
                    html = `
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Grade</th>
                                    <th>Date d'affectation</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    
                    data.forEach(teacher => {
                        const dateAffectation = new Date(teacher.dateAffectation).toLocaleDateString('fr-FR');
                        html += `
                            <tr>
                                <td>${teacher.noms}</td>
                                <td>${teacher.gradeDesignation || ''}</td>
                                <td>${dateAffectation}</td>
                                <td>
                                    <button class="btn btn-sm btn-danger" onclick="confirmRemoveTeacher(${teacher.idAffectation})">
                                        <i class="bi bi-trash"></i> Retirer
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                    
                    html += `
                            </tbody>
                        </table>
                    `;
                }
                
                document.getElementById('teachersList').innerHTML = html;
            })
            .catch(error => {
                console.error('Erreur lors du chargement des enseignants:', error);
                document.getElementById('teachersList').innerHTML = `
                    <div class="alert alert-danger">
                        Une erreur est survenue lors du chargement des enseignants.
                    </div>
                `;
            });
    }
    
    function confirmRemoveTeacher(idAffectation) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous vraiment retirer cet enseignant de cette spécialisation ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, retirer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `controller/remove_teacher_from_specialisation.php?idAffectation=${idAffectation}`;
            }
        });
    }
</script>

<?php include "./views/include/footer.php"; ?>

