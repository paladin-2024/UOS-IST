<?php
include "./views/include/header.php";
$uniteRecherche = new UniteRecherche();
$agentModel = new Agent();

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Récupérer tous les enseignants (type_agent = 'Enseignant')
$enseignants = $agentModel->getAgentsByType('Enseignant', $search);

// Récupérer toutes les unités de recherche
$researchUnits = $uniteRecherche->getResearchUnits();
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>ENSEIGNANTS ET UNITÉS DE RECHERCHE</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Affectation des Enseignants</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- Section Dashboard -->
    <section class="section dashboard">
        <div class="row">
            <!-- Tableau de données -->
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table enseignants -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                            <h5 class="card-title">
                                Gestion des affectations des enseignants aux spécialisations
                                <span class="float-end">
                                    <button class="btn btn-sm btn-success" onclick="openExportModal()">
                                        <i class="bi bi-file-excel"></i> Exporter en Excel
                                    </button>
                                </span>
                            </h5>
                            
                            <!-- Reste du code existant -->


                                <form method="GET" action="" class="mb-3">
                                    <div class="input-group">
                                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher un enseignant...">
                                        <button type="submit" class="btn btn-primary">Rechercher</button>
                                    </div>
                                </form>

                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Grade</th>
                                            <th scope="col">Service</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        foreach ($enseignants as $enseignant) {
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td>{$enseignant['noms']}</td>
                                                <td>{$enseignant['gradeDesignation']}</td>
                                                <td>{$enseignant['serviceDesignation']}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-success' onclick='openAssignSpecialisationModal({$enseignant['idAgent']}, \"{$enseignant['noms']}\")'>
                                                        <i class='bi bi-plus-circle'></i> Affecter à une spécialisation
                                                    </button>
                                                    <button class='btn btn-sm btn-info' data-bs-toggle='collapse' data-bs-target='#specialisationsList{$enseignant['idAgent']}'>
                                                        <i class='bi bi-list'></i> Voir Spécialisations
                                                    </button>
                                                </td>
                                            </tr>
                                            <tr class='collapse' id='specialisationsList{$enseignant['idAgent']}'>
                                                <td colspan='5'>
                                                    <div class='card card-body'>
                                                        <table class='table table-sm'>
                                                            <thead>
                                                                <tr>
                                                                    <th scope='col'>Unité de Recherche</th>
                                                                    <th scope='col'>Section</th>
                                                                    <th scope='col'>Spécialisation</th>
                                                                    <th scope='col'>Actions</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>";
                                                            $specialisations = $uniteRecherche->getTeacherSpecialisations($enseignant['idAgent']);
                                                            if (count($specialisations) > 0) {
                                                                foreach ($specialisations as $specialisation) {
                                                                    echo "<tr>
                                                                        <td>{$specialisation['designation_UR']}</td>
                                                                        <td>{$specialisation['designationSection']}</td>
                                                                        <td>{$specialisation['designation']}</td>
                                                                        <td>
                                                                            <button class='btn btn-sm btn-danger' onclick='confirmRemoveSpecialisation({$specialisation['idAffectation']})'>
                                                                                <i class='bi bi-trash'></i> Retirer
                                                                            </button>
                                                                        </td>
                                                                    </tr>";
                                                                }
                                                            } else {
                                                                echo "<tr><td colspan='4' class='text-center'>Aucune spécialisation assignée</td></tr>";
                                                            }
                                                            echo "</tbody>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><!-- End Table -->
                </div>
            </div>
        </div>
    </section>

</main><!-- End #main -->


<!-- Modal pour l'exportation Excel -->
<div class="modal fade" id="exportModal" tabindex="-1" role="dialog" aria-labelledby="exportModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Exporter les enseignants par unité de recherche</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="exportForm" method="POST" action="controller/export_teachers_by_specialisation.php" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label for="exportUniteRecherche" class="form-label">Unité de Recherche</label>
                        <select name="idUniteRecherche" id="exportUniteRecherche" class="form-control" required onchange="loadExportSections()">
                            <option value="">Sélectionner une unité de recherche</option>
                            <option value="all">Toutes les unités de recherche</option>
                            <?php foreach ($researchUnits as $unit): ?>
                                <option value="<?= $unit['idunite_recherche'] ?>"><?= $unit['designation_UR'] ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Veuillez sélectionner une unité de recherche.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="exportSection" class="form-label">Section</label>
                        <select name="idSection" id="exportSection" class="form-control">
                            <option value="">Sélectionner d'abord une unité de recherche</option>
                        </select>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="includeDetails" name="includeDetails" checked>
                        <label class="form-check-label" for="includeDetails">
                            Inclure les détails des enseignants (grade, service, etc.)
                        </label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-file-excel"></i> Exporter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour affecter un enseignant à une spécialisation -->
<div class="modal fade" id="assignSpecialisationModal" tabindex="-1" role="dialog" aria-labelledby="assignSpecialisationModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Affecter un enseignant à une spécialisation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="assignSpecialisationForm" method="POST" action="controller/assign_teacher_to_specialisation.php" class="needs-validation" novalidate>
                    <input type="hidden" name="idAgent" id="idAgent">
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label class="form-label">Enseignant</label>
                            <input type="text" id="enseignantNom" class="form-control" readonly>
                        </div>
                        <div class="col-md-12">
                            <label for="idUniteRecherche" class="form-label">Unité de Recherche</label>
                            <select name="idUniteRecherche" id="idUniteRecherche" class="form-control" required onchange="loadSections()">
                                <option value="">Sélectionner une unité de recherche</option>
                                <?php foreach ($researchUnits as $unit): ?>
                                    <option value="<?= $unit['idunite_recherche'] ?>"><?= $unit['designation_UR'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une unité de recherche.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idSection" class="form-label">Section</label>
                            <select name="idSection" id="idSection" class="form-control" required onchange="loadSpecialisations()">
                                <option value="">Sélectionner d'abord une unité de recherche</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une section.</div>
                        </div>
                        <div class="col-md-12">
                            <label for="idSpecialisation" class="form-label">Spécialisation</label>
                            <select name="idSpecialisation" id="idSpecialisation" class="form-control" required>
                                <option value="">Sélectionner d'abord une section</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une spécialisation.</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save"></i> Affecter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function openAssignSpecialisationModal(idAgent, nom) {
        document.getElementById('idAgent').value = idAgent;
        document.getElementById('enseignantNom').value = nom;
        
        // Réinitialiser les sélecteurs
        document.getElementById('idSection').innerHTML = '<option value="">Sélectionner d\'abord une unité de recherche</option>';
        document.getElementById('idSpecialisation').innerHTML = '<option value="">Sélectionner d\'abord une section</option>';
        
        new bootstrap.Modal(document.getElementById('assignSpecialisationModal')).show();
    }
    
    function loadSections() {
        const idUniteRecherche = document.getElementById('idUniteRecherche').value;
        if (!idUniteRecherche) return;
        
        fetch(`controller/get_sections_by_research_unit.php?idUniteRecherche=${idUniteRecherche}`)
            .then(response => response.json())
            .then(data => {
                const sectionSelect = document.getElementById('idSection');
                sectionSelect.innerHTML = '<option value="">Sélectionner une section</option>';
                
                data.forEach(section => {
                    const option = document.createElement('option');
                    option.value = section.idsection;
                    option.textContent = `${section.designationSection}`;
                    sectionSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des sections:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Impossible de charger les sections.'
                });
            });
    }
    
    function loadSpecialisations() {
        const idUniteRecherche = document.getElementById('idUniteRecherche').value;
        const idSection = document.getElementById('idSection').value;
        if (!idUniteRecherche || !idSection) return;
        
        fetch(`controller/get_specialisations.php?idUniteRecherche=${idUniteRecherche}&idSection=${idSection}`)
            .then(response => response.json())
            .then(data => {
                const specialisationSelect = document.getElementById('idSpecialisation');
                specialisationSelect.innerHTML = '<option value="">Sélectionner une spécialisation</option>';
                
                data.forEach(specialisation => {
                    const option = document.createElement('option');
                    option.value = specialisation.idSpecialisation;
                    option.textContent = specialisation.designation;
                    specialisationSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des spécialisations:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Impossible de charger les spécialisations.'
                });
            });
    }
    
    function confirmRemoveSpecialisation(idAffectation) {
        Swal.fire({
            title: 'Êtes-vous sûr ?',
            text: "Voulez-vous vraiment retirer cette affectation ?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, retirer',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `controller/remove_teacher_from_specialisation.php?idAffectation=${idAffectation}`;
            }
        });
    }
</script>

<script>
    // Code JavaScript existant...
    
    function openExportModal() {
        // Réinitialiser le formulaire
        document.getElementById('exportForm').reset();
        document.getElementById('exportSection').innerHTML = '<option value="">Sélectionner d\'abord une unité de recherche</option>';
        
        // Afficher le modal
        new bootstrap.Modal(document.getElementById('exportModal')).show();
    }
    
    function loadExportSections() {
        const idUniteRecherche = document.getElementById('exportUniteRecherche').value;
        const sectionSelect = document.getElementById('exportSection');
        
        // Réinitialiser le sélecteur de sections
        sectionSelect.innerHTML = '';
        
        // Si "Toutes les unités" est sélectionné
        if (idUniteRecherche === 'all') {
            sectionSelect.innerHTML = '<option value="all" selected>Toutes les sections</option>';
            return;
        }
        
        // Si aucune unité n'est sélectionnée
        if (!idUniteRecherche) {
            sectionSelect.innerHTML = '<option value="">Sélectionner d\'abord une unité de recherche</option>';
            return;
        }
        
        // Ajouter l'option "Toutes les sections"
        const allOption = document.createElement('option');
        allOption.value = 'all';
        allOption.textContent = 'Toutes les sections';
        allOption.selected = true;
        sectionSelect.appendChild(allOption);
        
        // Charger les sections pour l'unité sélectionnée
        fetch(`controller/get_sections_by_research_unit.php?idUniteRecherche=${idUniteRecherche}`)
            .then(response => response.json())
            .then(data => {
                data.forEach(section => {
                    const option = document.createElement('option');
                    option.value = section.idsection;
                    option.textContent = `${section.designationSection}`;
                    sectionSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des sections:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Impossible de charger les sections.'
                });
            });
    }
</script>




<?php include "./views/include/footer_file.php"; ?>
