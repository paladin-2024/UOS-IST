<?php
include "./views/include/header.php";
$universite = new Universite();

$search = isset($_GET['search']) ? $_GET['search'] : '';
$selectedSection = isset($_GET['section']) ? intval($_GET['section']) : 0;

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Récupérer toutes les sections accessibles à l'utilisateur
$sections = [];
if ($_SESSION['idRole'] == 1) { // Si administrateur
    $sections = $universite->getSections();
} else {
    // Pour les autres utilisateurs, vérifier les sections associées
    $userSections = $universite->getUserSections($_SESSION['id']);
    foreach ($userSections as $sectionId) {
        $sectionData = $universite->getSectionById($sectionId);
        if ($sectionData) {
            $sections[] = $sectionData;
        }
    }
}

// Récupérer toutes les UEs pour l'année en cours
$ues = [];
if (!empty($sections)) {
    $sectionIds = array_column($sections, 'idsection');
    
    // Si c'est un administrateur et aucune section n'est sélectionnée, récupérer toutes les UEs
    if ($_SESSION['idRole'] == 1 && $selectedSection == 0) {
        $ues = $universite->getAllUEs($currentYear['idannee_acad'], $search);
    } 
    // Si une section spécifique est sélectionnée
    elseif ($selectedSection > 0 && in_array($selectedSection, $sectionIds)) {
        $ues = $universite->getAllUEsBySection($selectedSection, $currentYear['idannee_acad'], $search);
    } 
    // Sinon, utiliser la première section accessible
    else {
        $ues = $universite->getAllUEsBySection($sectionIds[0], $currentYear['idannee_acad'], $search);
    }
}
?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>GESTION DES UNITÉS D'ENSEIGNEMENT</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Accueil</a></li>
                <li class="breadcrumb-item active">Unités d'Enseignement</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <!-- Table des UEs -->
                    <div class="col-12">
                        <div class="card overflow-auto">
                            <div class="card-body">
                                <h5 class="card-title">
                                    Liste des Unités d'Enseignement
                                    <span>
                                        | <a data-bs-toggle="modal" data-bs-target="#createUEModal" class="btnPage">
                                            <i class="bi bi-plus-circle-fill"></i> Ajouter une UE
                                        </a>
                                        | <a data-bs-toggle="modal" data-bs-target="#importUEModal" class="btnPage">
                                            <i class="bi bi-upload"></i> Importer des UEs
                                        </a>
                                    </span>
                                </h5>

                                <form method="GET" action="" class="mb-3">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="input-group">
                                                <input type="hidden" name="view" value="enseignement/unites_enseignement">
                                                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" class="form-control" placeholder="Rechercher une UE...">
                                                <button type="submit" class="btn btn-primary">Rechercher</button>
                                            </div>
                                        </div>
                                        <?php if ($_SESSION['idRole'] == 1): ?>
                                        <div class="col-md-6">
                                            <select name="section" class="form-select" onchange="this.form.submit()">
                                                <option value="0">Toutes les sections</option>
                                                <?php foreach ($sections as $section): ?>
                                                    <option value="<?= $section['idsection'] ?>" <?= $selectedSection == $section['idsection'] ? 'selected' : '' ?>>
                                                        <?= htmlspecialchars($section['designationSection']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </form>

                                <!-- Remplacer la section du tableau des UE par celle-ci -->
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Code</th>
                                            <th scope="col">Désignation</th>
                                            <th scope="col">Semestres/Promotions</th>
                                            <th scope="col">Section</th>
                                            <th scope="col">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Récupérer les UE regroupées par code et désignation
                                        $uesGroupees = $universite->getUEsGroupees($currentYear['idannee_acad'], $search, $selectedSection);
                                        $i = 1;

                                        foreach ($uesGroupees as $ue) {
                                            // Récupérer toutes les instances de cette UE
                                            $instancesUE = $universite->getUEsByCodeDesignation($ue['codeUE'], $ue['designationUE'], $currentYear['idannee_acad'], $search, $selectedSection);
                                            
                                            // Construire la liste des semestres/promotions
                                            $semestresHtml = '';
                                            $idsUE = [];
                                            
                                            foreach ($instancesUE as $instance) {
                                                $semestresHtml .= "<span class='badge bg-info me-1 mb-1'>S{$instance['numeroSemestre']} - {$instance['designationPromotion']}</span> ";
                                                $idsUE[] = $instance['idUE'];
                                            }
                                            
                                            // Convertir le tableau d'IDs en chaîne JSON pour les actions
                                            $idsUEJson = json_encode($idsUE);
                                            
                                            echo "
                                            <tr>
                                                <td>{$i}</td>
                                                <td><strong>{$ue['codeUE']}</strong></td>
                                                <td>{$ue['designationUE']}</td>
                                                <td>{$semestresHtml}</td>
                                                <td>{$ue['designationSection']}</td>
                                                <td>
                                                    <button class='btn btn-sm btn-warning' onclick='editUEGroupe(\"{$ue['codeUE']}\", \"{$ue['designationUE']}\", {$idsUEJson})'>
                                                        <i class='bi bi-pencil-square'></i> Modifier
                                                    </button>
                                                    <button class='btn btn-sm btn-danger' onclick='deleteUEGroupe(\"{$ue['codeUE']}\", \"{$ue['designationUE']}\", {$idsUEJson})'>
                                                        <i class='bi bi-trash'></i> Supprimer
                                                    </button>
                                                    <button class='btn btn-sm btn-info' onclick='viewUEDetails(\"{$ue['codeUE']}\", \"{$ue['designationUE']}\", {$idsUEJson})'>
                                                        <i class='bi bi-eye'></i> Détails
                                                    </button>
                                                    <button class='btn btn-sm btn-primary' onclick='viewECUEs({$idsUEJson})'>
                                                        <i class='bi bi-book'></i> ECUEs
                                                    </button>
                                                </td>
                                            </tr>";
                                            $i++;
                                        }

                                        if (empty($uesGroupees)) {
                                            echo "<tr><td colspan='6' class='text-center'>Aucune unité d'enseignement trouvée</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>


<!-- Ajouter ce modal pour les détails de l'UE -->
<div class="modal fade" id="ueDetailsModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Détails de l'UE <span id="detailUECode"></span> - <span id="detailUEDesignation"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Semestre</th>
                                <th>Promotion</th>
                                <th>Section</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="detailUEBody">
                            <!-- Les détails seront chargés dynamiquement -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
            </div>
        </div>
    </div>
</div>


<!-- Ajouter ce modal pour modifier un groupe d'UE -->
<div class="modal fade" id="editUEGroupeModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier un Groupe d'UE</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="controller/edit_ue_groupe.php" class="needs-validation" novalidate>
                    <input type="hidden" name="ue_ids" id="editUEIds">
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="editUECode" class="form-label">Code UE <span class="text-danger">*</span></label>
                            <input type="text" name="codeUE" id="editUECode" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir un code UE.</div>
                        </div>
                        <div class="col-md-8">
                            <label for="editUEDesignation" class="form-label">Désignation <span class="text-danger">*</span></label>
                            <input type="text" name="designationUE" id="editUEDesignation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez saisir une désignation.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="editUEDescription" class="form-label">Description</label>
                            <textarea name="description" id="editUEDescription" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editUEGroupeBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour ajouter une UE -->
<div class="modal fade" id="createUEModal" tabindex="-1" aria-labelledby="addUEModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-xl"> <!-- Changé de modal-lg à modal-xl -->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUEModalLabel">Ajouter une Unité d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="ueForm" method="POST" action="controller/ue_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="create_multiple">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <!-- Placer Code UE, Désignation et Description sur la même ligne dans le modal d'ajout -->
                    <div class="row mb-3">
                        <div class="col-md-2">
                            <label for="code" class="form-label">Code UE</label>
                            <input type="text" class="form-control" id="code" name="code" required>
                            <div class="invalid-feedback">Veuillez entrer un code.</div>
                        </div>
                        <div class="col-md-4">
                            <label for="designation" class="form-label">Désignation</label>
                            <input type="text" class="form-control" id="designation" name="designation" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" name="description" id="description" class="form-control">
                        </div>
                    </div>
                    
                    <!-- Remplacer la section des semestres dans le modal d'ajout d'UE par ceci: -->
<div class="row mb-3">
    <div class="col-md-12">
        <label class="form-label">Sélection des semestres</label>
        <div class="alert alert-info">
            <i class="bi bi-info-circle me-2"></i>
            Sélectionnez les semestres dans lesquels vous souhaitez ajouter cette UE.
        </div>
        
        <div class="card">
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <div id="semestresContainer" class="border rounded p-3">
                    <?php 
                    foreach ($sections as $section) {
                        echo "<h6 class='mt-2'>{$section['designationSection']}</h6>";
                        $promotions = $universite->getPromotionsBySection($section['idsection'], $currentYear['idannee_acad']);
                        
                        if (!empty($promotions)) {
                            echo "<div class='ms-3 mb-3'>";
                            foreach ($promotions as $promotion) {
                                echo "<div class='mb-2'><strong>{$promotion['designationPromotion']} ({$promotion['cycle']})</strong></div>";
                                
                                // Récupérer les semestres pour cette promotion
                                $semestres = $universite->getSemestresByPromotion($promotion['idpromotion']);
                                
                                if (!empty($semestres)) {
                                    echo "<div class='ms-3 mb-3 row'>";
                                    foreach ($semestres as $semestre) {
                                        echo "
                                        <div class='form-check col-md-4 mb-2'>
                                            <input class='form-check-input' type='checkbox' name='semestres[]' value='{$semestre['idsemestre']}' id='semestre_{$semestre['idsemestre']}'>
                                            <label class='form-check-label' for='semestre_{$semestre['idsemestre']}'>
                                                Semestre {$semestre['numeroSemestre']}
                                            </label>
                                        </div>";
                                    }
                                    echo "</div>";
                                } else {
                                    echo "<div class='ms-3 text-muted'>Aucun semestre disponible</div>";
                                }
                            }
                            echo "</div>";
                        } else {
                            echo "<div class='ms-3 text-muted'>Aucune promotion disponible</div>";
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
        <div class="invalid-feedback">Veuillez sélectionner au moins un semestre.</div>
    </div>
</div>

                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="addUEBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour modifier une UE -->
<div class="modal fade" id="editUEModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une Unité d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editUEForm" method="POST" action="controller/ue_controller.php" class="needs-validation" novalidate>
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="idUE" id="edit_idUE">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <!-- Remplacer uniquement la partie des champs Code UE et Désignation dans le modal de modification d'UE -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="edit_code" class="form-label">Code UE</label>
                            <input type="text" name="code" id="edit_code" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer un code.</div>
                        </div>
                        <div class="col-md-8">
                            <label for="edit_designation" class="form-label">Désignation</label>
                            <input type="text" name="designation" id="edit_designation" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer une désignation.</div>
                        </div>
                    </div>


                    <!-- Ajouter uniquement le champ Description dans le modal de modification d'UE -->
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_description" class="form-label">Description</label>
                            <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="edit_semestre" class="form-label">Semestre</label>
                            <select name="semestre" id="edit_semestre" class="form-select" required>
                                <?php
                                $allSemestres = $universite->getAllSemestres();
                                foreach ($allSemestres as $sem) {
                                    echo "<option value='{$sem['idsemestre']}'>{$sem['numeroSemestre']} - {$sem['designationPromotion']} ({$sem['designationSection']})</option>";
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un semestre.</div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" name="editUEBtn" class="btn btn-primary">
                            <i class="bi bi-save"></i> Enregistrer les modifications
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal pour importer des UEs -->
<div class="modal fade" id="importUEModal" tabindex="-1" role="dialog" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des Unités d'Enseignement</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="importForm" method="POST" action="controller/ue_controller.php" class="needs-validation" enctype="multipart/form-data" novalidate>
                    <input type="hidden" name="action" value="import">
                    <input type="hidden" name="idAnneeAcad" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="promotion_import" class="form-label">Promotion</label>
                            <select name="promotion_import" id="promotion_import" class="form-select" required onchange="loadSemestresImport(this.value)">
                                <option value="">Sélectionnez une promotion</option>
                                <?php 
                                foreach ($sections as $section) {
                                    $promotions = $universite->getPromotionsBySection($section['idsection'], $currentYear['idannee_acad']);
                                    if (!empty($promotions)) {
                                        echo "<optgroup label='{$section['designationSection']}'>";
                                        foreach ($promotions as $promotion) {
                                            echo "<option value='{$promotion['idpromotion']}'>{$promotion['designationPromotion']} ({$promotion['cycle']})</option>";
                                        }
                                        echo "</optgroup>";
                                    }
                                }
                                ?>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner une promotion.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="semestre_import" class="form-label">Semestre</label>
                            <select name="semestre_import" id="semestre_import" class="form-select" required>
                                <option value="">Sélectionnez d'abord une promotion</option>
                            </select>
                            <div class="invalid-feedback">Veuillez sélectionner un semestre.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="fichier_import" class="form-label">Fichier Excel/CSV</label>
                            <input type="file" name="fichier_import" id="fichier_import" class="form-control" required accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel">
                            <div class="invalid-feedback">Veuillez sélectionner un fichier.</div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Le fichier doit contenir les colonnes suivantes: Code UE, Désignation, Description (optionnelle).
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="colonne_code" class="form-label">Colonne Code UE</label>
                            <input type="text" name="colonne_code" id="colonne_code" class="form-control" value="A" required>
                            <div class="invalid-feedback">Veuillez indiquer la colonne.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="colonne_designation" class="form-label">Colonne Désignation</label>
                            <input type="text" name="colonne_designation" id="colonne_designation" class="form-control" value="B" required>
                            <div class="invalid-feedback">Veuillez indiquer la colonne.</div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="colonne_description" class="form-label">Colonne Description (optionnelle)</label>
                            <input type="text" name="colonne_description" id="colonne_description" class="form-control" value="C">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="skip_header" name="skip_header" value="1" checked>
                                <label class="form-check-label" for="skip_header">
                                    Ignorer la première ligne (en-têtes)
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-upload"></i> Importer
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
// Fonction pour charger les semestres en fonction de la promotion
function loadSemestres(promotionId) {
    if (!promotionId) {
        document.getElementById('semestre').innerHTML = '<option value="">Sélectionnez d\'abord une promotion</option>';
        return;
    }
    
    fetch(`controller/get_semestres.php?promotion=${promotionId}`)
        .then(response => response.json())
        .then(data => {
            let options = '<option value="">Sélectionnez un semestre</option>';
            data.forEach(semestre => {
                options += `<option value="${semestre.idsemestre}">${semestre.numeroSemestre}</option>`;
            });
            document.getElementById('semestre').innerHTML = options;
        })
        .catch(error => console.error('Erreur:', error));
}

// Fonction pour charger les semestres pour l'importation
function loadSemestresImport(promotionId) {
    if (!promotionId) {
        document.getElementById('semestre_import').innerHTML = '<option value="">Sélectionnez d\'abord une promotion</option>';
        return;
    }
    
    fetch(`controller/get_semestres.php?promotion=${promotionId}`)
        .then(response => response.json())
        .then(data => {
            let options = '<option value="">Sélectionnez un semestre</option>';
            data.forEach(semestre => {
                options += `<option value="${semestre.idsemestre}">${semestre.numeroSemestre}</option>`;
            });
            document.getElementById('semestre_import').innerHTML = options;
        })
        .catch(error => console.error('Erreur:', error));
}

// Fonction pour ouvrir le modal de modification d'une UE
function openEditUEModal(idUE, code, designation, semestreId) {
    document.getElementById('edit_idUE').value = idUE;
    document.getElementById('edit_code').value = code;
    document.getElementById('edit_designation').value = designation;
    document.getElementById('edit_semestre').value = semestreId;
    
    // Récupérer la description de l'UE par une requête AJAX
    fetch(`controller/get_ue_details.php?id=${idUE}`)
        .then(response => response.json())
        .then(data => {
            if (data.description) {
                document.getElementById('edit_description').value = data.description;
            }
        })
        .catch(error => console.error('Erreur:', error));
    
    new bootstrap.Modal(document.getElementById('editUEModal')).show();
}

function deleteUE(idUE) {
    Swal.fire({
        title: 'Êtes-vous sûr?',
        text: "Cette action supprimera l'unité d'enseignement et ne peut pas être annulée!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Oui, supprimer!',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            // Utiliser une requête AJAX pour plus de fiabilité
            fetch(`controller/ue_controller.php?action=delete&id=${idUE}`)
                .then(response => {
                    if (response.ok) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Succès',
                            text: 'L\'unité d\'enseignement a été supprimée avec succès.'
                        }).then(() => {
                            window.location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erreur',
                            text: 'Une erreur est survenue lors de la suppression.'
                        });
                    }
                })
                .catch(error => {
                    console.error('Erreur:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur',
                        text: 'Une erreur est survenue lors de la communication avec le serveur.'
                    });
                });
        }
    });
}



// Validation des formulaires Bootstrap
(function () {
    'use strict'
    
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')
    
    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                
                form.classList.add('was-validated')
            }, false)
        })
})()


// Validation du formulaire d'ajout d'UE
document.getElementById('ueForm').addEventListener('submit', function(event) {
    // Vérifier si au moins un semestre est sélectionné
    const semestresChecked = document.querySelectorAll('input[name="semestres[]"]:checked');
    if (semestresChecked.length === 0) {
        event.preventDefault();
        event.stopPropagation();
        
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'Veuillez sélectionner au moins un semestre.'
        });
        
        return false;
    }
});

</script>

<script>
    // Fonction pour modifier un groupe d'UE
    function editUEGroupe(codeUE, designationUE, idsUE) {
        document.getElementById('editUECode').value = codeUE;
        document.getElementById('editUEDesignation').value = designationUE;
        document.getElementById('editUEIds').value = JSON.stringify(idsUE);
        
        // Récupérer la description (on prend celle de la première UE du groupe)
        if (idsUE.length > 0) {
            fetch(`controller/get_ue_details.php?id=${idsUE[0]}`)
                .then(response => response.json())
                .then(data => {
                    if (data.description) {
                        document.getElementById('editUEDescription').value = data.description;
                    }
                })
                .catch(error => console.error('Erreur:', error));
        }
        
        new bootstrap.Modal(document.getElementById('editUEGroupeModal')).show();
    }
    
    // Fonction pour confirmer la suppression d'un groupe d'UE
    function deleteUEGroupe(codeUE, designationUE, idsUE) {
        Swal.fire({
            title: 'Êtes-vous sûr?',
            html: `Cette action supprimera l'UE <strong>${codeUE} - ${designationUE}</strong> de tous les semestres associés.<br>Cette action est irréversible!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimer!',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `controller/delete_ue_groupe.php?ids=${JSON.stringify(idsUE)}`;
            }
        });
    }
    
    // Fonction pour afficher les détails d'une UE
    function viewUEDetails(codeUE, designationUE, idsUE) {
        document.getElementById('detailUECode').textContent = codeUE;
        document.getElementById('detailUEDesignation').textContent = designationUE;
        
        // Charger les détails via AJAX
        fetch(`controller/get_ue_groupe_details.php?ids=${JSON.stringify(idsUE)}`)
            .then(response => response.json())
            .then(data => {
                let html = '';
                data.forEach(ue => {
                    html += `
                    <tr>
                        <td>${ue.idUE}</td>
                        <td>Semestre ${ue.numeroSemestre}</td>
                        <td>${ue.designationPromotion}</td>
                        <td>${ue.designationSection}</td>
                        <td>
                            <button class='btn btn-sm btn-warning' onclick='openEditUEModal(${ue.idUE}, "${ue.codeUE}", "${ue.designationUE}", ${ue.semestre_idsemestre})'>
                                <i class='bi bi-pencil-square'></i>
                            </button>
                            <button class='btn btn-sm btn-danger' onclick='deleteUE(${ue.idUE})'>
                                <i class='bi bi-trash'></i>
                            </button>
                            <button class='btn btn-sm btn-primary' onclick='window.location.href="?view=enseignement/ecues&ue=${ue.idUE}"'>
                                <i class='bi bi-book'></i> ECUEs
                            </button>
                        </td>
                    </tr>`;
                });
                document.getElementById('detailUEBody').innerHTML = html;
            })
            .catch(error => {
                console.error('Erreur:', error);
                document.getElementById('detailUEBody').innerHTML = 
                    '<tr><td colspan="5" class="text-center text-danger">Erreur lors du chargement des détails</td></tr>';
            });
        
        new bootstrap.Modal(document.getElementById('ueDetailsModal')).show();
    }
    
    // Fonction pour rediriger vers la page des ECUEs avec plusieurs UE
    function viewECUEs(idsUE) {
        // Si une seule UE, rediriger directement
        if (idsUE.length === 1) {
            window.location.href = `?view=enseignement/ecues&ue=${idsUE[0]}`;
            return;
        }
        
        // Sinon, demander à l'utilisateur de choisir une UE spécifique
        Swal.fire({
            title: 'Choisir une UE',
            text: 'Veuillez sélectionner une UE spécifique pour voir ses ECUEs',
            icon: 'info',
            showCancelButton: true,
            confirmButtonText: 'Voir les détails',
            cancelButtonText: 'Annuler'
        }).then((result) => {
            if (result.isConfirmed) {
                viewUEDetails(document.getElementById('detailUECode').textContent, 
                              document.getElementById('detailUEDesignation').textContent, 
                              idsUE);
            }
        });
    }
</script>

<script src="assets/js/ue-manager.js"></script>


<?php include "./views/include/footer.php"; ?>
<div
