<?php
include "./views/include/header.php";
$universite = new Universite();
$ecue = new Ecue();
$agent = new Agent();
$enseignant = new Enseignant();

// Vérifier que l'utilisateur est connecté et est un enseignant
$userId = $_SESSION['id'] ?? 0;

// Vérifier si l'utilisateur est un enseignant
if (!$userId || !$enseignant->isUserEnseignant($userId)) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Accès refusé',
            text: 'Vous devez être connecté en tant qu\'enseignant pour accéder à cette page.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

// Récupérer l'ID de l'agent (enseignant)
$idEnseignant = $enseignant->getAgentIdByUserId($userId);
if (!$idEnseignant) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'Impossible de récupérer les informations de l\'enseignant.'
        }).then(() => {
            window.location.href = '?view=dashboard';
        });
    </script>";
    exit;
}

// Récupérer l'ID de l'ECUE depuis l'URL
$idEcue = isset($_GET['ecue']) ? intval($_GET['ecue']) : 0;
if ($idEcue <= 0) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'ECUE non spécifié ou invalide.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer l'année académique actuelle
$currentYear = $universite->getCurrentAcademicYear();

// Vérifier si l'enseignant est autorisé à accéder à cet ECUE
$isAuthorized = $enseignant->isEnseignantAssignedToEcue($idEnseignant, $idEcue, $currentYear['idannee_acad']);
if (!$isAuthorized) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Accès refusé',
            text: 'Vous n\'êtes pas autorisé à accéder aux évaluations de ce cours.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer les détails de l'ECUE
$ecueDetails = $ecue->getEcueById($idEcue);
if (!$ecueDetails) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Erreur',
            text: 'ECUE non trouvé.'
        }).then(() => {
            window.location.href = '?view=recherche/mes_cours';
        });
    </script>";
    exit;
}

// Récupérer les sessions (première, deuxième)
$sessions = $universite->getSessions();

$s1=$universite->getSessions("Première session");

$premiereSession=$s1[0]['idsession'];

// Récupérer les types d'évaluation (contrôle continu, examen, etc.)
$typesEvaluation = $ecue->getEvaluationTypes();

// Récupérer les évaluations existantes pour cet ECUE
$evaluations = $ecue->getEvaluationsByEcue($idEcue, $currentYear['idannee_acad']);

// Récupérer la liste des étudiants inscrits à ce cours
$etudiants = $ecue->getStudentsByEcue($idEcue, $currentYear['idannee_acad']);

// Récupérer la configuration des moyennes pour cet ECUE
$configMoyenne = $ecue->getConfigurationMoyenne($idEcue, $currentYear['idannee_acad'],$premiereSession);

// Récupérer l'état de verrouillage des sessions
$sessionsVerrouillees = $ecue->getSessionsVerrouillees($idEcue, $currentYear['idannee_acad']);


?>

<!-- Espace de travail -->
<main id="main" class="main">
    <div class="pagetitle">
        <h1>ÉVALUATIONS - <?= htmlspecialchars($ecueDetails['designationECUE']) ?></h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="?view=dashboard">Accueil</a></li>
                <li class="breadcrumb-item"><a href="?view=recherche/mes_cours">Mes Cours</a></li>
                <li class="breadcrumb-item active">Évaluations</li>
            </ol>
        </nav>
    </div>

    <section class="section dashboard">
        <div class="row">
            <!-- Informations du cours -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Informations générales</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Cours:</strong> <?= htmlspecialchars($ecueDetails['designationECUE']) ?></p>
                                <p><strong>UE:</strong> <?= htmlspecialchars($ecueDetails['designationUE']) ?></p>
                                <p><strong>Semestre:</strong> <?= htmlspecialchars($ecueDetails['numeroSemestre']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Promotion:</strong> <?= htmlspecialchars($ecueDetails['designationPromotion']) ?></p>
                                <p><strong>Année académique:</strong> <?= htmlspecialchars($currentYear['designation']) ?></p>
                                <p><strong>Volume horaire:</strong> CMI: <?= $ecueDetails['CMI'] ?>h | TD: <?= $ecueDetails['TD'] ?>h | TP: <?= $ecueDetails['TP'] ?>h</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Onglets de navigation -->
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs nav-tabs-bordered" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="evaluations-tab" data-bs-toggle="tab" data-bs-target="#evaluations-content" type="button" role="tab" aria-selected="true">
                                    <i class="bi bi-list-check me-1"></i> Liste des évaluations
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="notes-tab" data-bs-toggle="tab" data-bs-target="#notes-content" type="button" role="tab" aria-selected="false">
                                    <i class="bi bi-file-earmark-spreadsheet me-1"></i> Grille de notes
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="config-tab" data-bs-toggle="tab" data-bs-target="#config-content" type="button" role="tab" aria-selected="false">
                                    <i class="bi bi-gear me-1"></i> Configuration
                                </button>
                            </li>
                        </ul>
                        
                        <div class="tab-content pt-3">
                            <!-- Onglet Liste des évaluations -->
                            <div class="tab-pane fade show active" id="evaluations-content" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5>Liste des évaluations</h5>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEvaluationModal">
                                        <i class="bi bi-plus-circle"></i> Ajouter une évaluation
                                    </button>
                                </div>
                                
                                <?php if (empty($evaluations)): ?>
                                    <div class="alert alert-info">
                                        <i class="bi bi-info-circle me-1"></i> Aucune évaluation n'a encore été créée pour ce cours.
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Titre</th>
                                                    <th>Type</th>
                                                    <th>Date</th>
                                                    <th>Session</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($evaluations as $eval): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($eval['titre']) ?></td>
                                                        <td><?= htmlspecialchars($eval['designationT']) ?></td>
                                                        <td><?= date('d/m/Y', strtotime($eval['date_evaluation'])) ?></td>
                                                        <td><?= htmlspecialchars($eval['description']) ?></td>
                                                        <td>
                                                            <button class="btn btn-sm btn-primary" onclick="openEnterGradesModal(<?= $eval['idevaluation'] ?>, '<?= addslashes($eval['titre']) ?>')">
                                                                <i class="bi bi-pencil-square"></i> Saisir les notes
                                                            </button>
                                                            <button class="btn btn-sm btn-warning" onclick="openEditEvaluationModal(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-pencil"></i> Modifier
                                                            </button>
                                                            <button class="btn btn-sm btn-danger" onclick="confirmDeleteEvaluation(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-trash"></i>
                                                            </button>
                                                            <button class="btn btn-sm btn-success" onclick="exportNotesEvaluation(<?= $eval['idevaluation'] ?>)">
                                                                <i class="bi bi-file-excel"></i> Exporter
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                    <div class="mt-3">
                                        <button id="compileNotesBtn" class="btn btn-primary">
                                            <i class="bi bi-calculator"></i> Envoyer les cotes à la grille
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Onglet Grille de notes -->
                            <div class="tab-pane fade" id="notes-content" role="tabpanel">
                                <div class="card mb-4">
                                    <div class="card-header bg-light">
                                        <h6 class="mb-0">Synthèse des moyennes</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-end mb-3">
                                            <button class="btn btn-primary me-2" onclick="compileAllNotes()">
                                                <i class="bi bi-calculator"></i> Compiler les notes
                                            </button>
                                            <button class="btn btn-success" onclick="exportAllNotes()">
                                                <i class="bi bi-file-excel"></i> Exporter toutes les notes
                                            </button>
                                        </div>
                                        
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>N°</th>
                                                        <th>Matricule</th>
                                                        <th>Nom de l'étudiant</th>
                                                        <th class="text-center">CC (Première session)</th>
                                                        <th class="text-center">Examen (Première session)</th>
                                                        <th class="text-center bg-light">Moyenne (Première session)</th>
                                                        <th class="text-center">Examen (Deuxième session)</th>
                                                        <th class="text-center bg-light">Moyenne (Deuxième session)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    $i = 1;
                                                    // Récupérer les cotes compilées
                                                    $cotesGrille = $ecue->getCotesGrille($idEcue, $currentYear['idannee_acad']);
                                                    
                                                    foreach ($etudiants as $etudiant): 
                                                        // Filtrer les cotes pour cet étudiant
                                                        $cotesEtudiant = array_filter($cotesGrille, function($c) use ($etudiant) {
                                                            return $c['matricule'] === $etudiant['matricule'];
                                                        });

                                                        // Initialiser les variables pour stocker les notes de première et deuxième session
                                                        $ccPremiere = '-';
                                                        $examenPremiere = '-';
                                                        $moyennePremiere = '-';
                                                        $examenDeuxieme = '-';
                                                        $moyenneDeuxieme = '-';
                                                        
                                                        $ccPremiereClass = '';
                                                        $examenPremiereClass = '';
                                                        $moyennePremiereClass = '';
                                                        $examenDeuxiemeClass = '';
                                                        $moyenneDeuxiemeClass = '';
                                                        
                                                        // Parcourir les cotes de l'étudiant pour trouver celles des deux sessions
                                                        foreach ($cotesEtudiant as $cote) {
                                                            // Vérifier si c'est la première session en utilisant le texte de la session
                                                            $isPremiereSession = mb_strtolower($cote['designSession']) === mb_strtolower('première session');
                                                            if ($isPremiereSession) { // Première session
                                                                // CC
                                                                if ($cote['CC'] !== null) {
                                                                    $ccPremiere = number_format($cote['CC'], 2);
                                                                    $ccPremiereClass = $cote['CC'] < 10 ? 'text-danger' : ($cote['CC'] >= 16 ? 'text-success' : '');
                                                                }
                                                                
                                                                // Examen
                                                                if ($cote['EX'] !== null) {
                                                                    $examenPremiere = number_format($cote['EX'], 2);
                                                                    $examenPremiereClass = $cote['EX'] < 10 ? 'text-danger' : ($cote['EX'] >= 16 ? 'text-success' : '');
                                                                }
                                                                
                                                                // Moyenne
                                                                if ($cote['MF'] !== null) {
                                                                    $moyennePremiere = number_format($cote['MF'], 2);
                                                                    $moyennePremiereClass = $cote['MF'] < 10 ? 'text-danger fw-bold' : ($cote['MF'] >= 16 ? 'text-success fw-bold' : 'fw-bold');
                                                                }
                                                            } else { // Deuxième session
                                                                // Examen
                                                                if ($cote['EX'] !== null) {
                                                                    $examenDeuxieme = number_format($cote['EX'], 2);
                                                                    $examenDeuxiemeClass = $cote['EX'] < 10 ? 'text-danger' : ($cote['EX'] >= 16 ? 'text-success' : '');
                                                                }
                                                                
                                                                // Moyenne
                                                                if ($cote['MF'] !== null) {
                                                                    $moyenneDeuxieme = number_format($cote['MF'], 2);
                                                                    $moyenneDeuxiemeClass = $cote['MF'] < 10 ? 'text-danger fw-bold' : ($cote['MF'] >= 16 ? 'text-success fw-bold' : 'fw-bold');
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    <tr>
                                                        <td><?= $i++ ?></td>
                                                        <td><?= htmlspecialchars($etudiant['matricule']) ?></td>
                                                        <td><?= htmlspecialchars($etudiant['noms']) ?></td>
                                                        <td class="text-center <?= $ccPremiereClass ?>"><?= $ccPremiere ?></td>
                                                        <td class="text-center <?= $examenPremiereClass ?>"><?= $examenPremiere ?></td>
                                                        <td class="text-center bg-light <?= $moyennePremiereClass ?>"><?= $moyennePremiere ?></td>
                                                        <td class="text-center <?= $examenDeuxiemeClass ?>"><?= $examenDeuxieme ?></td>
                                                        <td class="text-center bg-light <?= $moyenneDeuxiemeClass ?>"><?= $moyenneDeuxieme ?></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Onglet Configuration -->
                            <div class="tab-pane fade" id="config-content" role="tabpanel">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Configuration des pondérations</h5>
                                        <form id="configForm" action="controller/evaluation_controller.php" method="POST">
                                            <input type="hidden" name="action" value="save_config">
                                            <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                                            <input type="hidden" name="annee_acad_id" value="<?= $currentYear['idannee_acad'] ?>">
                                            
                                            <div class="alert alert-info">
                                                <i class="bi bi-info-circle me-1"></i>
                                                <strong>Note:</strong> Cette configuration ne s'applique qu'à la première session. Pour la deuxième session, l'examen vaut automatiquement 100% de la note finale.
                                            </div>
                                            
                                            <div class="card mb-3">
                                                <div class="card-header bg-light">
                                                    <h5 class="mb-0">Première session</h5>
                                                </div>
                                                <div class="card-body">
                                                    <input type="hidden" name="session_ids[]" value="<?= $premiereSession ?>">
                                                    
                                                    <div class="row align-items-center mb-3">
                                                        <div class="col-md-6">
                                                            <label class="form-label">Pondération Contrôle Continu (%)</label>
                                                            <input type="range" class="form-range" id="ponderation_cc_range" min="0" max="100" step="5" 
                                                                   value="<?= $configMoyenne ? $configMoyenne['ponderation_cc'] * 100 : 40 ?>">
                                                            <!-- Remplacez ces lignes dans le formulaire de configuration -->
                                                            <input type="hidden" name="ponderation_cc[<?= $premiereSession ?>]" id="ponderation_cc_value">
                                                            <input type="hidden" name="ponderation_ex[<?= $premiereSession ?>]" id="ponderation_ex_value">

                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="d-flex justify-content-between">
                                                                <div id="cc_percent" class="h4"></div>
                                                                <div class="h4">+</div>
                                                                <div id="ex_percent" class="h4"></div>
                                                                <div class="h4">=</div>
                                                                <div class="h4">100%</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="alert alert-secondary">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <p><strong>Signification:</strong> Pour la première session, la note finale sera calculée comme suit:</p>
                                                                <ul>
                                                                    <li>La moyenne des Contrôles Continus comptera pour <span id="cc_weight"></span>% de la note finale</li>
                                                                    <li>La note d'Examen comptera pour <span id="ex_weight"></span>% de la note finale</li>
                                                                </ul>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <p><strong>Exemple:</strong> Avec cette configuration, si un étudiant a:</p>
                                                                <ul>
                                                                    <li>Une moyenne de 12/20 aux Contrôles Continus</li>
                                                                    <li>Une note de 14/20 à l'Examen</li>
                                                                    <li>Sa note finale sera: <span id="example_result"></span>/20</li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="bi bi-save"></i> Enregistrer la configuration
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Modal pour ajouter une évaluation -->
<div class="modal fade" id="addEvaluationModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ajouter une évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addEvaluationForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="add_evaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    <input type="hidden" name="idUser" value="<?= $userId ?>">
                    <input type="hidden" name="annee_acad_id" value="<?= $currentYear['idannee_acad'] ?>">
                    
                    <div class="mb-3">
                        <label for="titre" class="form-label">Titre de l'évaluation</label>
                        <input type="text" class="form-control" id="titre" name="titre" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description (optionnelle)</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="date_evaluation" class="form-label">Date de l'évaluation</label>
                            <input type="date" class="form-control" id="date_evaluation" name="date_evaluation" required>
                        </div>
                        <div class="col-md-6">
                            <label for="idType" class="form-label">Type d'évaluation</label>
                            <select class="form-select" id="idType" name="idType" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($typesEvaluation as $type): ?>
                                    <option value="<?= $type['idType'] ?>"><?= htmlspecialchars($type['designationT']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="session_idsession" class="form-label">Session</label>
                            <select class="form-select" id="session_idsession" name="session_idsession" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($sessions as $session): ?>
                                    <option value="<?= $session['idsession'] ?>"><?= htmlspecialchars($session['description']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6" id="ponderationContainer" style="display: none;">
                            <label for="ponderation" class="form-label">Pondération</label>
                            <input type="number" class="form-control" id="ponderation" name="ponderation" value="1" min="0.1" max="10" step="0.1" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="est_visible" name="est_visible" value="1">
                        <label class="form-check-label" for="est_visible">Rendre visible pour les étudiants</label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour modifier une évaluation -->
<div class="modal fade" id="editEvaluationModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier une évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editEvaluationForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="update_evaluation">
                    <input type="hidden" name="idevaluation" id="edit_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    
                    <div class="mb-3">
                        <label for="edit_titre" class="form-label">Titre de l'évaluation</label>
                        <input type="text" class="form-control" id="edit_titre" name="titre" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_description" class="form-label">Description (optionnelle)</label>
                        <textarea class="form-control" id="edit_description" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_date_evaluation" class="form-label">Date de l'évaluation</label>
                            <input type="date" class="form-control" id="edit_date_evaluation" name="date_evaluation" required>
                            </div>
                        <div class="col-md-6">
                            <label for="edit_idType" class="form-label">Type d'évaluation</label>
                            <select class="form-select" id="edit_idType" name="idType" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($typesEvaluation as $type): ?>
                                    <option value="<?= $type['idType'] ?>"><?= htmlspecialchars($type['designationT']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="edit_session_idsession" class="form-label">Session</label>
                            <select class="form-select" id="edit_session_idsession" name="session_idsession" required>
                                <option value="">Sélectionnez...</option>
                                <?php foreach ($sessions as $session): ?>
                                    <option value="<?= $session['idsession'] ?>"><?= htmlspecialchars($session['designSession']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6" id="editPonderationContainer" style="display: none;">
                            <label for="edit_ponderation" class="form-label">Pondération</label>
                            <input type="number" class="form-control" id="edit_ponderation" name="ponderation" min="0.1" max="10" step="0.1" required>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="edit_est_visible" name="est_visible" value="1">
                        <label class="form-check-label" for="edit_est_visible">Rendre visible pour les étudiants</label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Mettre à jour</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour saisir les notes -->
<div class="modal fade" id="enterGradesModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Saisie des notes - <span id="evaluation_title"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="gradesForm" action="controller/evaluation_controller.php" method="POST">
                    <input type="hidden" name="action" value="save_grades">
                    <input type="hidden" name="idevaluation" id="grades_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    <input type="hidden" name="session_idsession" id="grades_session_id">

                    <!-- Options d'exportation et d'importation -->
                    <div class="d-flex justify-content-end mb-3">
                        <button type="button" class="btn btn-info me-2" onclick="exportGradesTemplate()">
                            <i class="bi bi-file-earmark-excel"></i> Exporter modèle Excel
                        </button>
                        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#importGradesModal">
                            <i class="bi bi-file-earmark-arrow-up"></i> Importer depuis Excel
                        </button>
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>N°</th>
                                    <th>Matricule</th>
                                    <th>Nom de l'étudiant</th>
                                    <th>Note (/20)</th>
                                </tr>
                            </thead>
                            <tbody id="grades_table_body">
                                <!-- Les lignes seront générées dynamiquement par JavaScript -->
                            </tbody>
                        </table>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Enregistrer les notes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour importer des notes depuis Excel -->
<div class="modal fade" id="importGradesModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Importer des notes depuis Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="importGradesForm" action="controller/import_grades.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="idevaluation" id="import_idevaluation">
                    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-1"></i>
                        Veuillez d'abord exporter le modèle Excel, remplir les notes, puis le réimporter ici.
                        <br>
                        <strong>Important :</strong> Ne modifiez pas la structure du fichier Excel.
                    </div>
                    
                    <div class="mb-3">
                        <label for="excelFile" class="form-label">Fichier Excel (*.xlsx)</label>
                        <input type="file" class="form-control" id="excelFile" name="excelFile" accept=".xlsx" required>
                        <div class="form-text">Seuls les fichiers Excel (XLSX) sont acceptés.</div>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" id="confirmImport" name="confirmImport" required>
                        <label class="form-check-label" for="confirmImport">
                            Je confirme que les données importées sont correctes et correspondent à l'évaluation sélectionnée.
                        </label>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Importer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Formulaires cachés pour les exports -->
<form id="exportTemplateForm" action="controller/export_notes_template.php" method="POST" style="display: none;">
    <input type="hidden" name="idevaluation" id="export_template_idevaluation">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>

<form id="exportForm" action="controller/export_notes_evaluation.php" method="POST" style="display: none;">
    <input type="hidden" name="idevaluation" id="export_idevaluation">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>

<form id="exportAllForm" action="controller/export_notes_ecue.php" method="POST" style="display: none;">
    <input type="hidden" name="idECUE" value="<?= $idEcue ?>">
</form>

<script>
// Fonction pour ouvrir le modal de modification d'une évaluation
function openEditEvaluationModal(evaluationId) {
    // Récupérer les données de l'évaluation via AJAX
    fetch(`controller/get_evaluation.php?id=${evaluationId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                Swal.fire('Erreur', data.error, 'error');
                return;
            }
            
            // Remplir le formulaire avec les données
            document.getElementById('edit_idevaluation').value = data.idevaluation;
            document.getElementById('edit_titre').value = data.titre;
            document.getElementById('edit_description').value = data.description || '';
            document.getElementById('edit_date_evaluation').value = data.date_evaluation;
            document.getElementById('edit_idType').value = data.idType;
            document.getElementById('edit_session_idsession').value = data.session_idsession;
            document.getElementById('edit_ponderation').value = data.ponderation;
            document.getElementById('edit_est_visible').checked = data.est_visible == 1;
            
            // Vérifier et afficher/masquer le champ de pondération
            toggleEditPonderationField();
            
            // Afficher le modal
            new bootstrap.Modal(document.getElementById('editEvaluationModal')).show();
        })
        .catch(error => {
            console.error('Erreur:', error);
            Swal.fire('Erreur', 'Une erreur est survenue lors de la récupération des données.', 'error');
        });
}

// Fonction pour exporter le modèle Excel pour une évaluation
function exportGradesTemplate() {
    const evaluationId = document.getElementById('grades_idevaluation').value;
    document.getElementById('export_template_idevaluation').value = evaluationId;
    document.getElementById('exportTemplateForm').submit();
}

/**
 * Ouvre le modal de saisie des notes pour une évaluation donnée
 * Gère automatiquement les spécificités de la première ou deuxième session
 * 
 * @param {number} evaluationId - ID de l'évaluation
 * @param {string} evaluationTitle - Titre de l'évaluation
 */
function openEnterGradesModal(evaluationId, evaluationTitle) {
    // Mettre à jour les informations dans le modal
    document.getElementById('evaluation_title').textContent = evaluationTitle;
    document.getElementById('grades_idevaluation').value = evaluationId;
    document.getElementById('import_idevaluation').value = evaluationId;
    
    // Afficher un indicateur de chargement
    const tableBody = document.getElementById('grades_table_body');
    tableBody.innerHTML = `
        <tr>
            <td colspan="4" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Chargement...</span>
                </div>
                <p class="mt-2">Chargement des données...</p>
            </td>
        </tr>
    `;
    
    // Ouvrir le modal pendant le chargement
    const modal = new bootstrap.Modal(document.getElementById('enterGradesModal'));
    modal.show();
    
    // Récupérer les notes existantes et les étudiants via AJAX
    fetch(`controller/get_grades.php?evaluation=${evaluationId}&ecue=<?= $idEcue ?>`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erreur HTTP! Statut: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                // Si c'est une erreur concernant l'absence d'étudiants éligibles en 2e session
                if (data.error.includes('Aucun étudiant n\'est éligible')) {
                    Swal.fire({
                        icon: 'info',
                        title: 'Information',
                        text: data.error,
                        confirmButtonText: 'Compris'
                    });
                    // Fermer le modal
                    bootstrap.Modal.getInstance(document.getElementById('enterGradesModal')).hide();
                } else {
                    // Autres erreurs
                    Swal.fire('Erreur', data.error, 'error');
                }
                return;
            }

            console.log('Données reçues:', data); // Pour débogage
    
            
            // Stocker l'ID de session pour le formulaire
            document.getElementById('grades_session_id').value = data.session_id;
            
            // Vérifier si c'est un examen et si c'est une deuxième session
            const isExam = data.evaluation_category === 'EX';
            const isDeuxiemeSession = data.is_deuxieme_session;
            const maxNote = 20; // Note maximale toujours sur 20
            
            // Supprimer les alertes précédentes s'il y en a
            const existingAlerts = document.querySelectorAll('#enterGradesModal .alert');
            existingAlerts.forEach(alert => alert.remove());
            
            // Ajouter un bandeau informatif selon le contexte
            let infoHtml = '';
            
            if (isDeuxiemeSession) {
                // Message spécifique pour la deuxième session
                infoHtml = `
                    <div class="alert alert-warning mb-3">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Mode deuxième session</strong> - Seuls les étudiants n'ayant pas validé l'UE en première session (moyenne < 10) sont affichés.
                    </div>`;
                
                if (isExam) {
                    infoHtml += `
                        <div class="alert alert-info mb-3">
                            <i class="bi bi-info-circle me-2"></i>
                            En deuxième session, l'examen compte pour 100% de la note finale.
                        </div>`;
                }
            } else if (isExam) {
                // Message pour un examen en première session
                infoHtml = `
                    <div class="alert alert-info mb-3">
                        <i class="bi bi-info-circle me-2"></i>
                        Cet examen compte pour ${data.ponderation_examen}% de la note finale.
                    </div>`;
            } else {
                // Message pour un contrôle continu
                infoHtml = `
                    <div class="alert alert-info mb-3">
                        <i class="bi bi-info-circle me-2"></i>
                        Les contrôles continus comptent pour ${data.ponderation_cc}% de la note finale.
                    </div>`;
            }
            
            // Insérer le message d'info avant le tableau
            const modalBody = document.querySelector('#enterGradesModal .modal-body');
            if (modalBody) {
                // Retirer les alertes précédentes
                const existingMessages = modalBody.querySelectorAll('.alert-info, .alert-warning');
                existingMessages.forEach(el => el.remove());
                
                // Insérer le nouveau message au début
                const firstChild = modalBody.firstChild;
                if (firstChild) {
                    modalBody.insertBefore(document.createRange().createContextualFragment(infoHtml), firstChild);
                } else {
                    modalBody.innerHTML = infoHtml + modalBody.innerHTML;
                }
            }
            
            // Générer les lignes du tableau avec les étudiants et leurs notes
            tableBody.innerHTML = '';
            
            if (!data.students || data.students.length === 0) {
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center py-4">
                            <div class="alert alert-info mb-0">
                                <i class="bi bi-info-circle me-2"></i>
                                Aucun étudiant trouvé pour cette évaluation.
                                ${isDeuxiemeSession ? 'Tous les étudiants ont validé l\'UE en première session.' : ''}
                            </div>
                        </td>
                    </tr>`;
                return;
            }
            
            // Afficher les étudiants et leurs notes
            data.students.forEach((student, index) => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${student.matricule}</td>
                    <td>${student.noms}</td>
                    <td>
                        <input type="number" class="form-control" name="notes[${student.idetudiant}]" 
                               value="${student.note !== null ? student.note : ''}" 
                               min="0" max="${maxNote}" step="0.25">
                    </td>`;
                
                tableBody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Erreur:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center">
                        <div class="alert alert-danger mb-0">
                            <i class="bi bi-exclamation-circle me-2"></i>
                            Une erreur est survenue lors de la récupération des données.
                        </div>
                    </td>
                </tr>`;
        });
}


// Fonction pour confirmer la suppression d'une évaluation
function confirmDeleteEvaluation(evaluationId) {
    Swal.fire({
        title: 'Confirmation',
        text: "Êtes-vous sûr de vouloir supprimer cette évaluation ? Cette action est irréversible et supprimera toutes les notes associées.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Oui, supprimer',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `controller/evaluation_controller.php?action=delete_evaluation&id=${evaluationId}&ecue=<?= $idEcue ?>`;
        }
    });
}

// Fonction pour exporter les notes d'une évaluation
function exportNotesEvaluation(evaluationId) {
    document.getElementById('export_idevaluation').value = evaluationId;
    document.getElementById('exportForm').submit();
}

// Fonction pour exporter toutes les notes
function exportAllNotes() {
    document.getElementById('exportAllForm').submit();
}

// Fonction pour compiler les notes
function compilerNotes() {
    Swal.fire({
        title: 'Compilation des notes',
        text: 'Voulez-vous compiler les notes des étudiants? Cette action calculera les moyennes des contrôles continus et les moyennes finales.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Oui, compiler',
        cancelButtonText: 'Annuler'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'Compilation en cours...',
                text: 'Veuillez patienter, cette opération peut prendre quelques instants.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                    
                    // Appel AJAX pour compiler les notes
                    fetch('controller/compile_notes.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `idECUE=<?= $idEcue ?>&annee_acad_id=<?= $currentYear['idannee_acad'] ?>`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Compilation terminée',
                                text: data.message,
                                icon: 'success'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Erreur',
                                text: data.message || 'Une erreur est survenue lors de la compilation.',
                                icon: 'error'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Erreur:', error);
                        Swal.fire({
                            title: 'Erreur',
                            text: 'Une erreur est survenue lors de la compilation.',
                            icon: 'error'
                        });
                    });
                }
            });
        }
    });
}


// Modification de la fonction compileAllNotes() dans evaluations.php
function compileAllNotes() {
    // Récupérer les sessions disponibles
    const sessions = <?= json_encode($sessions) ?>;
    
    // Créer les options pour le select
    const sessionOptions = sessions.map(session => 
        `<option value="${session.idsession}">${session.description}</option>`
    ).join('');
    
    // Afficher un dialogue avec sélection de session
    Swal.fire({
        title: 'Compiler les notes',
        html: `
            <p>Veuillez sélectionner la session pour laquelle vous souhaitez compiler les notes :</p>
            <select id="session-select" class="form-select mb-3">
                <option value="all">Toutes les sessions</option>
                ${sessionOptions}
            </select>
        `,
        showCancelButton: true,
        confirmButtonText: 'Compiler',
        cancelButtonText: 'Annuler',
        preConfirm: () => {
            return document.getElementById('session-select').value;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const sessionId = result.value;
            
            // Afficher un indicateur de chargement
            Swal.fire({
                title: 'Traitement en cours...',
                html: 'Compilation des notes en cours. Veuillez patienter.',
                didOpen: () => {
                    Swal.showLoading();
                },
                allowOutsideClick: false,
                allowEscapeKey: false,
                allowEnterKey: false
            });

            // Faire la requête AJAX pour compiler les notes
            fetch('controller/compile_notes.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'idECUE': <?= $idEcue ?>,
                    'annee_acad_id': <?= $currentYear['idannee_acad'] ?>,
                    'session_id': sessionId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Succès',
                        text: data.message || 'Les notes ont été compilées et envoyées à la grille avec succès.'
                    }).then(() => {
                        // Recharger la page pour afficher les notes mises à jour
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erreur',
                        text: data.message || 'Une erreur est survenue lors de la compilation des notes.'
                    });
                }
            })
            .catch(error => {
                console.error('Erreur:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erreur',
                    text: 'Une erreur est survenue lors de la communication avec le serveur.'
                });
            });
        }
    });
}


// Fonctions pour gérer l'affichage du champ de pondération
function togglePonderationField() {
    const sessionSelect = document.getElementById('session_idsession');
    const typeSelect = document.getElementById('idType');
    const ponderationContainer = document.getElementById('ponderationContainer');
    
    // Vérifier si les deux champs sont sélectionnés
    if (sessionSelect.value && typeSelect.value) {
        // On cache toujours le champ de pondération comme demandé
        ponderationContainer.style.display = 'none';
        
        // Mais on doit quand même remplir une valeur pour le formulaire
        const sessionText = sessionSelect.options[sessionSelect.selectedIndex].text;
        const typeText = typeSelect.options[typeSelect.selectedIndex].text;
        
        // Si c'est une deuxième session ET un examen
        if (sessionText.toLowerCase().includes('deuxième') && typeText.toLowerCase().includes('examen')) {
            document.getElementById('ponderation').value = '20';
        } else {
            document.getElementById('ponderation').value = '1';
        }
    } else {
        ponderationContainer.style.display = 'none';
    }
}

function toggleEditPonderationField() {
    const sessionSelect = document.getElementById('edit_session_idsession');
    const typeSelect = document.getElementById('edit_idType');
    const ponderationContainer = document.getElementById('editPonderationContainer');
    
    // On cache toujours le champ de pondération comme demandé
    ponderationContainer.style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function() {
    // Références aux éléments du formulaire
    const sessionSelect = document.getElementById('session_idsession');
    const typeSelect = document.getElementById('idType');
    const editSessionSelect = document.getElementById('edit_session_idsession');
    const editTypeSelect = document.getElementById('edit_idType');
    const compileBtn = document.getElementById('compileNotesBtn');
    
    // Écouter les changements sur les sélecteurs pour l'ajout
    if (sessionSelect && typeSelect) {
        sessionSelect.addEventListener('change', togglePonderationField);
        typeSelect.addEventListener('change', togglePonderationField);
        
        // Exécuter au chargement
        togglePonderationField();
    }
    
    // Écouter les changements sur les sélecteurs pour la modification
    if (editSessionSelect && editTypeSelect) {
        editSessionSelect.addEventListener('change', toggleEditPonderationField);
        editTypeSelect.addEventListener('change', toggleEditPonderationField);
    }
    
    // Configurer le bouton de compilation
    if (compileBtn) {
        compileBtn.addEventListener('click', compileAllNotes);
    }
    
    // Configuration de la pondération
    const ccRange = document.getElementById('ponderation_cc_range');
    const ccValue = document.getElementById('ponderation_cc_value');
    const ccPercent = document.getElementById('cc_percent');
    const exPercent = document.getElementById('ex_percent');
    const ccWeight = document.getElementById('cc_weight');
    const exWeight = document.getElementById('ex_weight');
    const exampleResult = document.getElementById('example_result');
    
    function updateValues() {
        if (!ccRange) return;
        
        const ccVal = parseInt(ccRange.value);
        const exVal = 100 - ccVal;

        // Mettre à jour les champs cachés
        document.getElementById('ponderation_cc_value').value = ccVal;
        document.getElementById('ponderation_ex_value').value = exVal;
        
        
        ccValue.value = ccVal;
        ccPercent.textContent = `CC: ${ccVal}%`;
        exPercent.textContent = `Examen: ${exVal}%`;
        ccWeight.textContent = ccVal;
        exWeight.textContent = exVal;
        
        // Calcul de l'exemple
        const exampleCC = 12;
        const exampleEX = 14;
        const result = ((exampleCC * ccVal/100) + (exampleEX * exVal/100)).toFixed(2);
        exampleResult.textContent = result;
    }
    
    if (ccRange) {
        ccRange.addEventListener('input', updateValues);
        
        // Initialisation
        ccValue.value = ccRange.value;
        updateValues();
    }
    
    // Initialisation des tooltips Bootstrap
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });




    function validateEvaluationForm(form) {
        const sessionSelect = form.querySelector('[name="session_idsession"]');
        const typeSelect = form.querySelector('[name="idType"]');
        
        if (!sessionSelect || !typeSelect) return true;
        
        // Récupérer les valeurs sélectionnées
        const sessionId = sessionSelect.value;
        const typeId = typeSelect.value;
        const sessionText = sessionSelect.options[sessionSelect.selectedIndex].text.toLowerCase();
        const typeText = typeSelect.options[typeSelect.selectedIndex].text.toLowerCase();
        const typeCategorie = getTypeCategorie(typeText);
        
        // Vérifier si c'est la deuxième session
        const isDeuxiemeSession = sessionText.includes('deuxième') || sessionText.includes('deuxieme');
        
        // 1. Contrôle continu non autorisé en deuxième session
        if (isDeuxiemeSession && typeCategorie === 'cc') {
            Swal.fire({
                icon: 'error',
                title: 'Validation échouée',
                text: 'Les contrôles continus ne sont pas autorisés en deuxième session.'
            });
            return false;
        }
        
        // 2. Vérifier s'il existe déjà un examen pour cette session
        if (typeCategorie === 'examen') {
            // Récupérer toutes les évaluations existantes
            const evaluations = <?= json_encode($evaluations) ?>;
            const currentEvalId = form.querySelector('[name="idevaluation"]')?.value;
            
            // Filtrer pour trouver un examen existant pour cette session
            const existingExam = evaluations.find(eval => {
                // Exclure l'évaluation actuelle en cas de modification
                if (currentEvalId && eval.idevaluation == currentEvalId) return false;
                
                return eval.session_idsession == sessionId && 
                       eval.categorie?.toLowerCase() === 'examen';
            });
            
            if (existingExam) {
                Swal.fire({
                    icon: 'error',
                    title: 'Validation échouée',
                    text: 'Un examen existe déjà pour cette session dans ce cours.'
                });
                return false;
            }
        }
        
        return true;
    }
    
    // Fonction pour déterminer la catégorie d'un type d'évaluation
    function getTypeCategorie(typeText) {
        if (typeText.includes('contrôle') || typeText.includes('controle') || 
            typeText.includes('cc') || typeText.includes('devoir')) {
            return 'cc';
        } else if (typeText.includes('examen')) {
            return 'examen';
        }
        return '';
    }
    
    // Appliquer la validation aux formulaires
    const addForm = document.getElementById('addEvaluationForm');
    if (addForm) {
        addForm.addEventListener('submit', function(e) {
            if (!validateEvaluationForm(this)) {
                e.preventDefault();
            }
        });
    }
    
    const editForm = document.getElementById('editEvaluationForm');
    if (editForm) {
        editForm.addEventListener('submit', function(e) {
            if (!validateEvaluationForm(this)) {
                e.preventDefault();
            }
        });
    }







});
</script>

<?php include "./views/include/footer.php"; ?>

